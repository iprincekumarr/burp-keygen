#!/usr/bin/env python3
"""
uEWF - Unified Web Exploitation Framework
Standalone Launcher Script

Run this script to start the uEWF framework without pip installation.
Usage: python run_uewf.py [commands]

Example:
    python run_uewf.py --help
    python run_uewf.py init
    python run_uewf.py scan http://example.com
    python run_uewf.py web
"""

import sys
import os
import platform
import subprocess
from pathlib import Path


# ============================================================
# CONFIGURATION - Edit these paths if needed
# ============================================================

# Project root directory (auto-detected based on script location)
PROJECT_ROOT = Path(os.path.dirname(os.path.abspath(__file__)))

# Path to the uewf package
UEWF_PACKAGE_DIR = PROJECT_ROOT / "uewf"

# Python requirements file
REQUIREMENTS_FILE = PROJECT_ROOT / "requirements.txt"

# Virtual environment directory (optional)
VENV_DIR = PROJECT_ROOT / ".venv"


# ============================================================
# BANNER
# ============================================================

BANNER = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║   ██╗   ██╗███████╗██╗    ██╗███████╗                           ║
║   ██║   ██║██╔════╝██║    ██║██╔════╝                           ║
║   ██║   ██║█████╗  ██║ █╗ ██║█████╗                             ║
║   ██║   ██║██╔══╝  ██║███╗██║██╔══╝                             ║
║   ╚██████╔╝██║     ╚███╔███╔╝██║                                ║
║    ╚═════╝ ╚═╝      ╚══╝╚══╝ ╚═╝                                ║
║                                                                  ║
║   Unified Web Exploitation Framework v1.0.0                      ║
║                                                                  ║
║   Author:  Prince Kumarr  (github.com/iprincekumarr)            ║
║                                                                  ║
║   ⚠️  FOR AUTHORIZED SECURITY TESTING ONLY                       ║
║   Unauthorized use is ILLEGAL                                    ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def print_banner():
    """Display the uEWF banner."""
    print(BANNER)


def print_info(message: str):
    """Print info message."""
    print(f"  [ℹ] {message}")


def print_success(message: str):
    """Print success message."""
    print(f"  [✓] {message}")


def print_error(message: str):
    """Print error message."""
    print(f"  [✗] {message}")


def print_warning(message: str):
    """Print warning message."""
    print(f"  [⚠] {message}")


def check_python_version() -> bool:
    """Check if Python version is sufficient."""
    if sys.version_info < (3, 8):
        print_error(f"Python 3.8+ required (current: {sys.version_info[0]}.{sys.version_info[1]})")
        return False
    return True


def check_dependencies() -> tuple:
    """Check which dependencies are installed."""
    missing = []
    installed = []
    
    core_packages = [
        "click", "requests", "bs4", "yaml", "colorama", 
        "rich", "tqdm", "flask", "sqlalchemy", "jinja2",
        "markdown", "matplotlib"
    ]
    
    for package in core_packages:
        try:
            if package == "bs4":
                import bs4
            elif package == "yaml":
                import yaml
            else:
                __import__(package)
            installed.append(package)
        except ImportError:
            missing.append(package)
    
    return installed, missing


def install_dependencies(packages: list) -> bool:
    """Install missing dependencies."""
    if not packages:
        return True
    
    print_info(f"Installing missing dependencies: {', '.join(packages)}")
    
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--quiet"] + packages,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return True
    except subprocess.CalledProcessError:
        # Fallback: install from requirements file
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "--quiet", "-r", str(REQUIREMENTS_FILE)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return True
        except subprocess.CalledProcessError:
            return False


def setup_virtualenv() -> bool:
    """Create and setup virtual environment."""
    if VENV_DIR.exists():
        return True
    
    print_info("Creating virtual environment...")
    
    try:
        subprocess.check_call(
            [sys.executable, "-m", "venv", str(VENV_DIR)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        # Get pip from venv
        if platform.system() == "Windows":
            pip_path = VENV_DIR / "Scripts" / "pip"
            python_path = VENV_DIR / "Scripts" / "python"
        else:
            pip_path = VENV_DIR / "bin" / "pip"
            python_path = VENV_DIR / "bin" / "python"
        
        # Install requirements
        print_info("Installing dependencies in virtual environment...")
        subprocess.check_call(
            [str(pip_path), "install", "--quiet", "-r", str(REQUIREMENTS_FILE)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        print_success(f"Virtual environment created at {VENV_DIR}")
        print_info(f"Activate with: source {VENV_DIR}/bin/activate")
        return True
        
    except (subprocess.CalledProcessError, Exception) as e:
        print_error(f"Failed to setup virtual environment: {e}")
        return False


def ensure_uewf_package() -> bool:
    """Ensure the uewf package is accessible."""
    uewf_init = UEWF_PACKAGE_DIR / "__init__.py"
    if not uewf_init.exists():
        print_error(f"uEWF package not found at {UEWF_PACKAGE_DIR}")
        return False
    return True


# ============================================================
# MAIN LAUNCHER
# ============================================================

def main():
    """Main entry point for the uEWF launcher."""
    
    # Display banner
    print_banner()
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Ensure uewf package exists
    if not ensure_uewf_package():
        sys.exit(1)
    
    # Add project root to Python path
    sys.path.insert(0, str(PROJECT_ROOT))
    
    # Check for virtual environment flag
    use_venv = "--venv" in sys.argv
    check_deps = "--check-deps" in sys.argv
    auto_install = "--install" in sys.argv
    
    if use_venv:
        # Setup and use virtual environment
        print_info("Using virtual environment mode")
        if not setup_virtualenv():
            print_error("Failed to setup virtual environment")
            sys.exit(1)
        
        # Re-run with venv python
        if platform.system() == "Windows":
            python_path = VENV_DIR / "Scripts" / "python"
        else:
            python_path = VENV_DIR / "bin" / "python"
        
        # Remove launcher-specific args
        args = [arg for arg in sys.argv if arg not in ("--venv",)]
        
        # Re-execute with venv Python
        os.execv(str(python_path), [str(python_path), __file__] + args)
        return
    
    if check_deps:
        # Check and optionally install dependencies
        installed, missing = check_dependencies()
        
        if installed:
            print_success(f"Installed packages: {', '.join(installed)}")
        
        if missing:
            print_warning(f"Missing packages: {', '.join(missing)}")
            
            if auto_install:
                if install_dependencies(missing):
                    print_success("Dependencies installed successfully")
                else:
                    print_error("Failed to install dependencies")
                    print_info(f"Try: pip install -r {REQUIREMENTS_FILE}")
                    sys.exit(1)
            else:
                print_info(f"Run with --install flag to auto-install, or use: pip install -r {REQUIREMENTS_FILE}")
                if not auto_install:
                    # Try to install anyway for convenience
                    print_info("Attempting to install missing dependencies...")
                    if install_dependencies(missing):
                        print_success("Dependencies installed successfully")
                    else:
                        print_error("Failed to install all dependencies. Some features may be limited.")
    
    # Print separator
    print("=" * 60)
    print()
    
    try:
        # Import and run uEWF CLI
        from uewf.cli import cli
        
        # Remove launcher-specific flags before passing to CLI
        launcher_flags = {"--venv", "--check-deps", "--install"}
        filtered_args = [arg for arg in sys.argv[1:] if arg not in launcher_flags]
        
        # Run the CLI
        cli(args=filtered_args, standalone_mode=False)
        
    except KeyboardInterrupt:
        print("\n\n  [!] Interrupted by user")
        sys.exit(0)
        
    except Exception as e:
        print_error(f"Fatal error: {e}")
        
        if "--debug" in sys.argv:
            import traceback
            traceback.print_exc()
        
        print_info("Try running: pip install -r requirements.txt")
        sys.exit(1)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()

