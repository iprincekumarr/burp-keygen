from setuptools import setup, find_packages
import os

# Read README.md
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith('#')]

setup(
    name="uewf",
    version="1.0.0",
    author="Prince Kumarr",
    author_email="iprincekumarr@github.com",
    description="Unified Web Exploitation Framework - Educational Security Testing Tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/iprincekumarr/uewf",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "uewf=uewf.__main__:main",
        ],
    },
    include_package_data=True,
    package_data={
        "uewf": ["data/payloads/*.json", "data/wordlists/*.txt"],
    },
)

