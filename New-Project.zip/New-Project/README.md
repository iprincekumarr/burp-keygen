# uEWF - Unified Web Exploitation Framework

![Security Testing](https://img.shields.io/badge/Security-Testing-red)
![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Version](https://img.shields.io/badge/Version-1.0.0-brightgreen)

> **⚠️ LEGAL DISCLAIMER: This tool is for authorized security testing and educational purposes ONLY.**
> 
> You must have explicit written permission before testing any system you do not own.
> Unauthorized use of this tool is illegal and can result in criminal prosecution.

## Overview

uEWF is a comprehensive, modular web application security testing framework designed for:
- Authorized penetration testing
- Bug bounty hunting
- Security education and training
- CTF (Capture The Flag) competitions

### Key Features

- **🔍 Vulnerability Scanning** - Automated detection of common web vulnerabilities
- **🎯 SQL Injection Testing** - Error-based, boolean blind, time-based, and UNION-based detection
- **💉 XSS Detection** - Reflected, stored, DOM-based, and blind XSS testing
- **🔎 Reconnaissance** - Information gathering, technology fingerprinting, endpoint discovery
- **🔄 Intercepting Proxy** - Traffic inspection and modification
- **📊 Comprehensive Reporting** - HTML, JSON, Markdown, CSV, and SARIF formats
- **🌐 Web Dashboard** - Flask-based web interface for managing scans
- **🔒 Safety Features** - Target authorization, payload validation, rate limiting
- **🧩 Modular Architecture** - Easily extensible with custom modules

## Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Install from source

```bash
# Clone the repository
git clone https://github.com/iprincekumarr/uewf.git
cd uewf

# Install dependencies
pip install -r requirements.txt

# Install the package
pip install -e .
```

### Quick Install

```bash
pip install uewf
```

## Quick Start

### Initialize uEWF

```bash
# Initialize configuration and data directories
uewf init
```

### Run a Scan

```bash
# Basic scan
uewf scan http://example.com

# Scan with specific modules
uewf scan http://example.com -m sqli -m xss -m recon

# Scan with options
uewf scan http://example.com -t 20 --timeout 30 --depth 5 -o results.json
```

### SQL Injection Testing

```bash
# Test specific parameter
uewf sqli http://example.com/page?id=1 -p id

# Test with specific techniques
uewf sqli http://example.com/page?id=1 -t error -t boolean -t time

# POST data testing
uewf sqli http://example.com/login -d "username=admin&password=test"
```

### XSS Testing

```bash
# Basic XSS scan
uewf xss http://example.com/search?q=test

# Test specific parameter
uewf xss http://example.com/search?q=test -p q

# Test all XSS types
uewf xss http://example.com/search -t all
```

### Reconnaissance

```bash
# Basic recon
uewf recon http://example.com

# Passive recon only
uewf recon http://example.com --passive

# With custom depth
uewf recon http://example.com --depth 5
```

### Generate Reports

```bash
# Generate HTML report
uewf report scan_results.json -f html -o report.html

# Generate PDF report
uewf report scan_results.json -f pdf -o report.pdf

# Generate SARIF report
uewf report scan_results.json -f sarif -o results.sarif
```

### Web Dashboard

```bash
# Start web dashboard
uewf web --host 127.0.0.1 --port 8080
```

### Intercepting Proxy

```bash
# Start proxy
uewf proxy start --port 8080
```

### Configuration

```bash
# Show current configuration
uewf config show

# Authorize a target
uewf config authorize http://example.com --scope "Full testing" --duration 30

# List authorized targets
uewf config list
```

## Module Reference

| Module | Description | Techniques |
|--------|-------------|------------|
| `sqli` | SQL Injection detection | Error-based, Boolean blind, Time-based, UNION-based |
| `xss` | Cross-Site Scripting detection | Reflected, Stored, DOM-based, Blind |
| `recon` | Information gathering | DNS enumeration, Technology fingerprinting, Endpoint discovery |
| `proxy` | Intercepting proxy | Traffic inspection, Request modification |
| `reporting` | Report generation | HTML, JSON, Markdown, PDF, SARIF |
| `chaining` | Attack chaining | Vulnerability correlation, Impact analysis |

## Safety Features

uEWF includes multiple safety mechanisms:

1. **Target Authorization** - Only scan targets you've explicitly authorized
2. **Payload Validation** - Blocks destructive payloads
3. **Rate Limiting** - Prevents overwhelming target servers
4. **Safe Mode** - Detection-only mode (no exploitation)
5. **Domain Blocking** - Prevents scanning of known production domains
6. **Internal IP Protection** - Blocks scanning of internal networks

## Architecture

```
uewf/
├── core/           # Core framework components
├── modules/        # Security testing modules
├── web/            # Web dashboard
├── utils/          # Utility functions
├── data/           # Payloads and wordlists
└── tests/          # Test suite
```

## Development

### Running Tests

```bash
# Run all tests
python -m pytest uewf/tests/

# Run specific test file
python -m pytest uewf/tests/test_modules.py -v

# Run with coverage
python -m pytest --cov=uewf uewf/tests/
```

### Creating Custom Modules

```python
from uewf.core.modules import BaseModule, ModuleManager

class CustomModule(BaseModule):
    name = "custom"
    description = "Custom security module"
    
    def test(self, url, parameters=None, method='GET', session=None):
        # Your testing logic here
        return [{
            'type': 'Custom Vulnerability',
            'severity': 'medium',
            'url': url,
            'description': 'Found something interesting'
        }]

# Register your module
ModuleManager.register_module('custom', CustomModule)
```

## Legal & Ethical Use

This tool is provided for **educational purposes** and **authorized security testing** only.

### Before Using:

1. ✅ Obtain **explicit written permission** from the system owner
2. ✅ Define the **scope** of testing in writing
3. ✅ Use **safe mode** for initial reconnaissance
4. ✅ Follow **responsible disclosure** practices
5. ✅ Comply with all **applicable laws and regulations**

### You MUST NOT:

- ❌ Test systems without authorization
- ❌ Exceed the scope of authorized testing
- ❌ Cause damage or denial of service
- ❌ Access or exfiltrate unauthorized data
- ❌ Use for illegal or unethical purposes

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Disclaimer

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

## Developer

**Prince Kumarr** - Security Researcher & Developer
- GitHub: [@iprincekumarr](https://github.com/iprincekumarr)

## Support

- **Documentation**: See the [Wiki](https://github.com/iprincekumarr/uewf/wiki)
- **Issues**: Report bugs via [GitHub Issues](https://github.com/iprincekumarr/uewf/issues)
- **Security**: Report security concerns to [iprincekumarr](https://github.com/iprincekumarr)

---

**Remember: With great power comes great responsibility. Use ethically.**

---

*Built with ❤️ by [Prince Kumarr](https://github.com/iprincekumarr)*

