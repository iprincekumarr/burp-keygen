"""
Unified Web Exploitation Framework (uEWF)
Educational Security Testing Framework

WARNING: This tool must only be used on systems you own or have
explicit written permission to test. Unauthorized use is illegal.
"""

__version__ = "1.0.0"
__author__ = "Prince Kumarr"
__license__ = "MIT"

import sys
import os

# Add package root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from .core.config import Config
from .core.logger import setup_logger

# Initialize logger
logger = setup_logger("uewf")

