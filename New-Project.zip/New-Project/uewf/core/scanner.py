"""
Core scanner engine for uEWF.
Orchestrates vulnerability scanning across multiple modules.
Integrates external tools, WAF detection, and advanced discovery.
Supports PwnXSS and XSStrike integration for enhanced XSS detection.
"""

import asyncio
import json
import time
import re
from typing import List, Dict, Optional, Callable, Set
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

from .config import Config
from .database import Database
from .logger import get_logger
from .modules import ModuleManager
from .safeties import SafetyManager
from ..utils.discovery import DiscoveryEngine
from ..utils.subdomain import SubdomainEngine
from ..utils.external import get_tool_manager
from urllib.parse import urlparse
from ..utils.waf_detector import WAFDetector

logger = get_logger(__name__)

# File extensions that are worth scanning for web vulnerabilities
TESTABLE_EXTENSIONS = {
    '.php', '.asp', '.aspx', '.jsp', '.jspx', '.do', '.action',
    '.cfm', '.shtml', '.pl', '.py', '.cgi', '.rb', '.erb',
    '.html', '.htm', '.xhtml', '.phtml', '.php3', '.php4', '.php5',
    '.dhtml', '.sht', '.stm',
}

# Static asset extensions to ALWAYS skip during vulnerability scanning
STATIC_EXTENSIONS = {
    '.css', '.js', '.json', '.xml', '.svg', '.ico', '.png', '.jpg',
    '.jpeg', '.gif', '.webp', '.bmp', '.tiff', '.woff', '.woff2',
    '.ttf', '.eot', '.otf', '.pdf', '.doc', '.docx', '.xls', '.xlsx',
    '.ppt', '.pptx', '.zip', '.tar', '.gz', '.rar', '.7z', '.mp3',
    '.mp4', '.avi', '.mov', '.wmv', '.flv', '.swf',
}


def _is_static_asset(url: str) -> bool:
    """Check if URL points to a static asset that shouldn't be vulnerability-scanned."""
    path = url.split('?')[0].lower()
    for ext in STATIC_EXTENSIONS:
        if path.endswith(ext):
            return True
    return False


def _is_testable_url(url: str) -> bool:
    """Check if URL is worth scanning for web vulnerabilities like SQLi/XSS."""
    path = url.split('?')[0].lower()
    for ext in TESTABLE_EXTENSIONS:
        if path.endswith(ext):
            return True
    if '?' in url:
        return True
    if not path.rpartition('/')[-1] or '.' not in path.rpartition('/')[-1]:
        return True
    return False


def _deduplicate_vulnerabilities(vulns: List[Dict]) -> List[Dict]:
    """
    Remove duplicate vulnerabilities based on type + normalized URL + parameter + payload.
    Normalizes URL variations (www vs non-www, http vs https, trailing slashes, ports).
    """
    seen: Set[str] = set()
    unique = []

    for vuln in vulns:
        vuln_type = vuln.get('type', '')
        vuln_param = vuln.get('parameter', '')
        vuln_payload = vuln.get('payload', '')[:100]

        raw_url = vuln.get('url', '')
        url = re.sub(r'^http://', 'https://', raw_url)
        url = re.sub(r'://www\.', '://', url)
        url = re.sub(r':80(?=/|$)', '', url)
        url = re.sub(r':443(?=/|$)', '', url)
        url = url.rstrip('/')

        key = f"{vuln_type}|{url}|{vuln_param}|{vuln_payload}"

        if key not in seen:
            seen.add(key)
            unique.append(vuln)

    return unique



class Scanner:
    """Main scanner engine that orchestrates vulnerability detection."""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        raw_target = self.config.get('target', '')
        if raw_target and not raw_target.startswith(('http://', 'https://')):
            raw_target = 'https://' + raw_target
            self.config['target'] = raw_target
        self.target = raw_target
        self.modules_list = self.config.get('modules', ['all'])
        self.safe_mode = self.config.get('safe_mode', True)
        self.threads = self.config.get('threads', 10)
        self.timeout = self.config.get('timeout', 30)
        self.depth = self.config.get('depth', 3)
        self.proxy = self.config.get('proxy')
        self.cookie = self.config.get('cookie')
        self.headers = self.config.get('headers', {})
        self.use_external = self.config.get('use_external', True)
        self.deep_crawl = self.config.get('deep_crawl', False)
        self.discover_subdomains = self.config.get('discover_subdomains', True)
        self.subdomain_sources = self.config.get('subdomain_sources', ['crt.sh', 'securitytrails', 'subfinder', 'bruteforce'])
        self.subdomain_wordlist = self.config.get('subdomain_wordlist')
        
        self.session = self._create_session()
        self.module_manager = ModuleManager()
        self.safety = SafetyManager()
        self.waf_detector = WAFDetector()
        self.tool_manager = get_tool_manager()
        self.results = {
            'target': self.target,
            'start_time': datetime.now().isoformat(),
            'end_time': None,
            'modules_used': [],
            'vulnerabilities': [],
            'scan_summary': {
                'total_requests': 0,
                'successful_requests': 0,
                'failed_requests': 0,
                'duration_seconds': 0
            }
        }
        
        self.db = Database()
        self.scan_id = None
    
    def _create_session(self) -> requests.Session:
        """Create configured requests session."""
        session = requests.Session()
        
        session.headers.update({
            'User-Agent': Config.get('user_agent', 'uEWF-Security-Scanner/1.0'),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        })
        
        session.headers.update(self.headers)
        
        proxy_url = self.proxy or Config.get('proxy')
        if proxy_url:
            session.proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
        
        if self.cookie:
            session.cookies.update(self._parse_cookies(self.cookie))
        
        session.verify = Config.get('verify_ssl', True)
        session.allow_redirects = Config.get('follow_redirects', True)
        session.max_redirects = Config.get('max_redirects', 5)
        
        return session
    
    def _parse_cookies(self, cookie_str: str) -> Dict:
        """Parse cookie string into dictionary."""
        cookies = {}
        if cookie_str:
            for item in cookie_str.split(';'):
                if '=' in item:
                    key, value = item.strip().split('=', 1)
                    cookies[key] = value
        return cookies
    
    def _filter_scan_targets(self, endpoints: List[Dict]) -> List[Dict]:
        """
        Filter endpoints to only include testable URLs.
        Excludes static assets like CSS, JS, images, fonts, etc.
        """
        filtered = []
        skipped_static = 0
        skipped_untestable = 0
        
        for ep in endpoints:
            url = ep.get('url', '')
            if not url:
                continue
            
            if _is_static_asset(url):
                skipped_static += 1
                continue
            
            if not ep.get('parameters') and not _is_testable_url(url):
                skipped_untestable += 1
                continue
            
            filtered.append(ep)
        
        if skipped_static > 0:
            logger.debug(f"Skipped {skipped_static} static asset endpoints")
        if skipped_untestable > 0:
            logger.debug(f"Skipped {skipped_untestable} non-testable endpoints")
        
        logger.info(f"Filtered {len(endpoints)} -> {len(filtered)} testable endpoints for vulnerability scanning")
        return filtered
    
    def run(self, callback: Optional[Callable] = None) -> Dict:
        """Run the scan with configured modules."""
        logger.info(f"Starting scan on {self.target}")
        
        self.scan_id = Database.create_scan(
            self.target,
            self.modules_list,
            self.config
        )
        
        total_steps = len(self._get_active_modules()) + 4
        current_step = 0
        
        tech_info = self._detect_technologies()
        self.results['technology_stack'] = tech_info
        
        waf_info = self._detect_waf()
        self.results['waf_detected'] = waf_info
        
        # ===== STEP 1: Subdomain discovery (runs FIRST before endpoint discovery) =====
        subdomains = []
        domain = None
        if self.discover_subdomains and self.scan_id:
            parsed = urlparse(self.target)
            domain = parsed.netloc
            if ':' in domain:
                domain = domain.split(':')[0]
            
            if domain:
                logger.info(f"Starting subdomain discovery for {domain}")
                try:
                    subdomain_engine = SubdomainEngine(domain)
                    subdomains = subdomain_engine.discover_all(
                        sources=self.subdomain_sources,
                        wordlist=self.subdomain_wordlist
                    )
                    if subdomains:
                        count = Database.add_subdomains(self.scan_id, domain, subdomains)
                        logger.info(f"Saved {count} subdomain records to database")
                        # Log active subdomains
                        active = [s for s in subdomains if s.get('alive')]
                        if active:
                            logger.info(f"Found {len(active)} active subdomains")
                            for s in active[:10]:
                                logger.info(f"  - {s['subdomain']} ({s.get('ip', 'N/A')})")
                except Exception as e:
                    logger.warning(f"Subdomain discovery failed: {e}")
        
        self.results['subdomains'] = subdomains
        
        # ===== STEP 2: Build target URLs from main target + active subdomains =====
        scan_targets = [self.target]
        if subdomains:
            active_subs = [s for s in subdomains if s.get('alive')]
            for s in active_subs:
                sub_url = f"https://{s['subdomain']}"
                if sub_url != self.target and sub_url not in scan_targets:
                    scan_targets.append(sub_url)
                    # Also try http:// as fallback
                    http_url = f"http://{s['subdomain']}"
                    if http_url not in scan_targets:
                        scan_targets.append(http_url)
            logger.info(f"Will discover endpoints on {len(scan_targets)} targets (1 main + {len(scan_targets)-1} subdomains)")
        
        current_step += 1
        
        # ===== STEP 3: Endpoint discovery on ALL targets (main + subdomains) =====
        all_endpoints = {}
        endpoint_seen = set()
        
        for target_url in scan_targets:
            try:
                logger.info(f"Discovering endpoints on {target_url}")
                discovery_engine = DiscoveryEngine(target_url, self.session)
                target_endpoints = discovery_engine.discover_all(
                    depth=self.depth,
                    use_external=self.use_external,
                    use_deep_crawl=self.deep_crawl
                )
                
                for ep in target_endpoints:
                    key = f"{ep['url']}|{ep.get('method', 'GET')}"
                    if key not in endpoint_seen:
                        endpoint_seen.add(key)
                        all_endpoints[key] = ep
                        
            except Exception as e:
                logger.warning(f"Endpoint discovery failed for {target_url}: {e}")
        
        endpoints = list(all_endpoints.values())
        self.results['endpoints'] = endpoints
        logger.info(f"Total unique endpoints across all targets: {len(endpoints)}")
        
        installed_tools = self.tool_manager.get_installed_tools()
        if installed_tools:
            logger.info(f"External tools available: {', '.join(installed_tools)}")
        
        pwnxss_available = self.tool_manager.is_tool_installed('pwnxss') or bool(
            Config.get('pwnxss_path')
        )
        xsstrike_available = self.tool_manager.is_tool_installed('xsstrike') or bool(
            Config.get('xsstrike_path')
        )
        if pwnxss_available:
            logger.info("PwnXSS detected - will be used for deep XSS scanning")
        if xsstrike_available:
            logger.info("XSStrike detected - will be used for advanced XSS detection")
        
        self.results['external_tools'] = installed_tools
        
        modules = self._get_active_modules()
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {}
            
            for module_name in modules:
                if module_name == 'proxy':
                    continue
                    
                module = self.module_manager.get_module(module_name)
                if module:
                    if module_name in ('sqli', 'xss'):
                        filtered = self._filter_scan_targets(endpoints)
                    else:
                        filtered = endpoints if module_name != 'recon' else [self.target]
                    
                    future = executor.submit(
                        self._run_module,
                        module,
                        filtered if isinstance(filtered, list) else [filtered]
                    )
                    futures[future] = module_name
            
            for future in as_completed(futures):
                module_name = futures[future]
                current_step += 1
                
                try:
                    module_results = future.result()
                    if module_results:
                        self.results['vulnerabilities'].extend(module_results)
                        self.results['modules_used'].append(module_name)
                        
                        for vuln in module_results:
                            Database.add_vulnerability(self.scan_id, vuln)
                    
                except Exception as e:
                    logger.error(f"Module {module_name} failed: {e}")
                
                if callback:
                    callback(int((current_step / total_steps) * 100))
        
        self.results['vulnerabilities'] = _deduplicate_vulnerabilities(
            self.results['vulnerabilities']
        )
        
        self.results['end_time'] = datetime.now().isoformat()
        self.results['scan_summary']['duration_seconds'] = (
            datetime.fromisoformat(self.results['end_time']) - 
            datetime.fromisoformat(self.results['start_time'])
        ).total_seconds()
        self.results['scan_summary']['total_endpoints_discovered'] = len(endpoints)
        
        Database.update_scan(
            self.scan_id,
            status='completed',
            end_time=self.results['end_time'],
            summary=json.dumps(self.results['scan_summary'])
        )
        
        logger.info(f"Scan completed. Found {len(self.results['vulnerabilities'])} vulnerabilities")
        
        return self.results
    
    def _get_active_modules(self) -> List[str]:
        """Get list of active modules to run."""
        if 'all' in self.modules_list:
            return self.module_manager.get_module_names()
        return self.modules_list
    
    def _detect_technologies(self) -> Dict:
        """Detect technologies used by the target."""
        technologies = {
            'server': None,
            'framework': None,
            'database': None,
            'cms': None,
            'javascript_libraries': [],
            'analytics': [],
        }
        
        try:
            response = self.session.get(self.target, timeout=self.timeout)
            
            server = response.headers.get('Server')
            if server:
                technologies['server'] = server
            
            powered_by = response.headers.get('X-Powered-By')
            if powered_by:
                technologies['framework'] = powered_by
            
            set_cookie = response.headers.get('Set-Cookie', '')
            if 'PHPSESSID' in set_cookie:
                technologies['framework'] = 'PHP'
            elif 'JSESSIONID' in set_cookie:
                technologies['framework'] = 'Java (J2EE)'
            
            soup = BeautifulSoup(response.text, 'lxml')
            
            js_patterns = {
                'jQuery': ['jquery', '$('],
                'React': ['react', 'reactdom'],
                'Vue.js': ['vue', 'vuejs'],
                'Angular': ['angular', 'ng-'],
                'Bootstrap': ['bootstrap'],
            }
            
            scripts = soup.find_all('script')
            for script in scripts:
                src = script.get('src', '')
                content = script.string or ''
                for lib, patterns in js_patterns.items():
                    if any(p in src.lower() or p in content.lower() for p in patterns):
                        if lib not in technologies['javascript_libraries']:
                            technologies['javascript_libraries'].append(lib)
            
        except Exception as e:
            logger.warning(f"Technology detection failed: {e}")
        
        return technologies
    
    def _detect_waf(self) -> Dict:
        """Detect WAF protecting the target."""
        logger.info("Checking for WAF protection...")
        try:
            waf_info = self.waf_detector.detect(self.target)
            if waf_info.get('detected'):
                waf_name = waf_info.get('waf_name', 'Unknown')
                logger.warning(f"WAF detected: {waf_name} (confidence: {waf_info.get('confidence', 0):.0%})")
            else:
                logger.info("No WAF detected")
            return waf_info
        except Exception as e:
            logger.debug(f"WAF detection failed: {e}")
            return {'detected': False, 'waf_name': None, 'error': str(e)}
    
    def _run_module(self, module, targets: List[Dict]) -> List[Dict]:
        """Run a single module against targets."""
        if not module:
            return []
        
        results = []
        module_name = module.__class__.__name__
        logger.info(f"Running module: {module_name}")
        
        for target in targets:
            try:
                if isinstance(target, dict):
                    url = target.get('url', self.target)
                    params = target.get('parameters', [])
                    method = target.get('method', 'GET')
                else:
                    url = target
                    params = []
                    method = 'GET'
                
                module_result = module.test(
                    url=url,
                    parameters=params if params else None,
                    method=method,
                    session=self.session
                )
                
                if module_result:
                    for vuln in module_result:
                        vuln['full_url'] = url
                        # Build full URL with param for display
                        if isinstance(target, dict) and target.get('parameters'):
                            p = target['parameters']
                            if p and isinstance(p, list) and len(p) > 0:
                                pname = p[0] if isinstance(p[0], str) else p[0].get('name', '')
                                if pname:
                                    vuln['full_url_with_params'] = f"{url}?{pname}=1"
                        results.append(vuln)
                    
            except Exception as e:
                logger.debug(f"Module {module_name} failed on {target.get('url', target) if isinstance(target, dict) else target}: {e}")
        
        return results
    
    def stop(self):
        """Stop the scan."""
        logger.info("Scan stopping...")
        Database.update_scan(self.scan_id, status='stopped')
