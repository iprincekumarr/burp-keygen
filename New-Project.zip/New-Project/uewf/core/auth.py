"""
Authorization and scope management module.
Ensures testing is only performed on authorized targets.
"""

import json
import hashlib
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from .config import Config
from .logger import get_logger

logger = get_logger(__name__)


class AuthorizationManager:
    """Manages target authorization and scope validation."""
    
    def __init__(self):
        self.auth_file = Config.get_config_dir() / 'authorizations.json'
        self.authorizations = self._load()
    
    def _load(self) -> Dict:
        """Load authorizations from file."""
        if self.auth_file.exists():
            with open(self.auth_file) as f:
                return json.load(f)
        return {'targets': [], 'version': '1.0'}
    
    def _save(self):
        """Save authorizations to file."""
        with open(self.auth_file, 'w') as f:
            json.dump(self.authorizations, f, indent=2)
    
    def add_authorization(self, url: str, scope: str = "Full scope", duration_days: int = 30):
        """Add new authorized target."""
        
        # Normalize URL
        url = url.rstrip('/')
        
        authorization = {
            'id': hashlib.md5(url.encode()).hexdigest()[:8],
            'url': url,
            'scope': scope,
            'added': datetime.now().isoformat(),
            'expires': (datetime.now() + timedelta(days=duration_days)).isoformat(),
            'active': True
        }
        
        # Check for duplicates
        for existing in self.authorizations['targets']:
            if existing['url'] == url:
                logger.warning(f"Authorization already exists for {url}")
                return False
        
        self.authorizations['targets'].append(authorization)
        self._save()
        
        logger.info(f"Added authorization for {url} (expires: {authorization['expires']})")
        return True
    
    def remove_authorization(self, url: str):
        """Remove authorization for target."""
        self.authorizations['targets'] = [
            t for t in self.authorizations['targets'] 
            if t['url'] != url
        ]
        self._save()
    
    def validate_target(self, url: str) -> bool:
        """
        Validate if target is authorized for testing.
        
        Checks:
        1. URL matches an authorized target
        2. Authorization hasn't expired
        """
        
        if not url:
            return False
        
        # Normalize URL
        url = url.rstrip('/')
        
        for auth in self.authorizations['targets']:
            if not auth.get('active', False):
                continue
            
            # Check if URL matches authorized target
            if url.startswith(auth['url']) or auth['url'] in url:
                # Check expiration
                expires = datetime.fromisoformat(auth['expires'])
                if expires > datetime.now():
                    return True
                else:
                    # Mark as inactive
                    auth['active'] = False
                    self._save()
        
        return False
    
    def get_authorizations(self) -> List[Dict]:
        """Get all authorizations."""
        # Update active status
        now = datetime.now()
        for auth in self.authorizations['targets']:
            expires = datetime.fromisoformat(auth['expires'])
            auth['active'] = expires > now
        
        return self.authorizations['targets']
    
    def check_scope(self, url: str, action: str) -> bool:
        """
        Check if action is within authorized scope.
        """
        for auth in self.authorizations['targets']:
            if url.startswith(auth['url']):
                scope = auth.get('scope', 'Full scope')
                
                if 'exclude' in scope.lower():
                    exclusions = self._parse_exclusions(scope)
                    for exclusion in exclusions:
                        if exclusion in url:
                            return False
                
                return True
        
        return False
    
    def _parse_exclusions(self, scope: str) -> List[str]:
        """Parse exclusion patterns from scope."""
        exclusions = []
        if 'exclude:' in scope.lower():
            parts = scope.lower().split('exclude:')
            if len(parts) > 1:
                exclusions = [e.strip() for e in parts[1].split(',')]
        return exclusions
    
    def is_authorized(self, url: str) -> bool:
        """Check if testing is authorized (alias for validate_target)."""
        return self.validate_target(url)

