"""
Database module for uEWF.
Stores scan results, configurations, session data, and subdomains.
"""

import os
import json
import sqlite3
from pathlib import Path
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
from contextlib import contextmanager

from .config import Config
from .logger import get_logger

logger = get_logger(__name__)


class Database:
    """SQLite database manager for uEWF."""
    
    _instance = None
    _connection = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def initialize(cls):
        """Initialize the database."""
        db_path = Config.get('database_path', str(Config.get_config_dir() / 'uewf.db'))
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        
        cls._connection = sqlite3.connect(db_path, check_same_thread=False)
        cls._connection.row_factory = sqlite3.Row
        cls._connection.execute("PRAGMA journal_mode=WAL")
        cls._connection.execute("PRAGMA foreign_keys=ON")
        
        cls._create_tables()
        logger.info(f"Database initialized at {db_path}")
    
    @classmethod
    def _create_tables(cls):
        """Create database tables if they don't exist."""
        queries = [
            """
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT,
                status TEXT DEFAULT 'running',
                modules TEXT,
                config TEXT,
                summary TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                severity TEXT NOT NULL,
                url TEXT NOT NULL,
                parameter TEXT,
                payload TEXT,
                description TEXT,
                evidence TEXT,
                remediation TEXT,
                confidence REAL DEFAULT 0.0,
                cve_id TEXT,
                cvss_score REAL,
                discovered_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS targets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT UNIQUE NOT NULL,
                domain TEXT,
                ip_address TEXT,
                technologies TEXT,
                status TEXT DEFAULT 'pending',
                first_seen TEXT DEFAULT (datetime('now')),
                last_scanned TEXT,
                notes TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                target TEXT,
                state TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now')),
                data TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS payloads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                payload TEXT NOT NULL,
                category TEXT,
                effectiveness REAL DEFAULT 0.0,
                source TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS scan_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                level TEXT NOT NULL,
                message TEXT NOT NULL,
                timestamp TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS subdomains (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                domain TEXT NOT NULL,
                subdomain TEXT NOT NULL,
                url TEXT,
                ip_address TEXT,
                status_code INTEGER DEFAULT 0,
                title TEXT,
                content_length INTEGER DEFAULT 0,
                technologies TEXT,
                webserver TEXT,
                alive INTEGER DEFAULT 0,
                source TEXT DEFAULT 'unknown',
                discovered_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE,
                UNIQUE(scan_id, subdomain)
            )
            """,
        ]
        
        for query in queries:
            cls._connection.execute(query)
        
        cls._connection.commit()
    
    @classmethod
    @contextmanager
    def get_connection(cls):
        """Get database connection."""
        if cls._connection is None:
            cls.initialize()
        
        try:
            yield cls._connection
        except sqlite3.Error as e:
            logger.error(f"Database error: {e}")
            raise
    
    # ===== Scan Operations =====
    
    @classmethod
    def create_scan(cls, target: str, modules: List[str], config: Dict = None) -> int:
        """Create new scan record."""
        with cls.get_connection() as conn:
            cursor = conn.execute(
                """INSERT INTO scans (target, start_time, modules, config) 
                   VALUES (?, ?, ?, ?)""",
                (target, datetime.now().isoformat(), json.dumps(modules), 
                 json.dumps(config or {}))
            )
            conn.commit()
            return cursor.lastrowid
    
    @classmethod
    def update_scan(cls, scan_id: int, **kwargs):
        """Update scan record."""
        allowed_fields = {'end_time', 'status', 'summary'}
        updates = {k: v for k, v in kwargs.items() if k in allowed_fields}
        
        if updates:
            set_clause = ', '.join(f"{k}=?" for k in updates.keys())
            values = list(updates.values())
            values.append(scan_id)
            
            with cls.get_connection() as conn:
                conn.execute(
                    f"UPDATE scans SET {set_clause} WHERE id=?",
                    values
                )
                conn.commit()
    
    @classmethod
    def get_scan(cls, scan_id: int) -> Optional[Dict]:
        """Get scan by ID."""
        with cls.get_connection() as conn:
            cursor = conn.execute("SELECT * FROM scans WHERE id=?", (scan_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                if result.get('modules'):
                    result['modules'] = json.loads(result['modules'])
                if result.get('config'):
                    result['config'] = json.loads(result['config'])
                if result.get('summary'):
                    result['summary'] = json.loads(result['summary'])
                return result
        return None
    
    @classmethod
    def get_scans(cls, limit: int = 50, offset: int = 0) -> List[Dict]:
        """Get recent scans."""
        with cls.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM scans ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset)
            )
            return [dict(row) for row in cursor.fetchall()]
    
    # ===== Vulnerability Operations =====
    
    @classmethod
    def add_vulnerability(cls, scan_id: int, vuln: Dict) -> int:
        """Add vulnerability to scan."""
        with cls.get_connection() as conn:
            cursor = conn.execute(
                """INSERT INTO vulnerabilities 
                   (scan_id, type, severity, url, parameter, payload, 
                    description, evidence, remediation, confidence)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (scan_id, vuln.get('type'), vuln.get('severity', 'info'),
                 vuln.get('url'), vuln.get('parameter'), vuln.get('payload'),
                 vuln.get('description'), vuln.get('evidence'),
                 vuln.get('remediation'), vuln.get('confidence', 0.0))
            )
            conn.commit()
            return cursor.lastrowid
    
    @classmethod
    def get_vulnerabilities(cls, scan_id: int = None, severity: str = None) -> List[Dict]:
        """Get vulnerabilities with optional filters."""
        query = "SELECT * FROM vulnerabilities WHERE 1=1"
        params = []
        
        if scan_id:
            query += " AND scan_id=?"
            params.append(scan_id)
        if severity:
            query += " AND severity=?"
            params.append(severity)
        
        query += " ORDER BY discovered_at DESC"
        
        with cls.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    @classmethod
    def get_vulnerability_stats(cls) -> Dict:
        """Get vulnerability statistics."""
        with cls.get_connection() as conn:
            cursor = conn.execute(
                """SELECT severity, COUNT(*) as count 
                   FROM vulnerabilities 
                   GROUP BY severity"""
            )
            stats = {row['severity']: row['count'] for row in cursor.fetchall()}
            
            cursor = conn.execute("SELECT COUNT(*) as total FROM vulnerabilities")
            total = cursor.fetchone()['total']
            
            return {
                'total': total,
                'by_severity': stats,
                'critical': stats.get('critical', 0),
                'high': stats.get('high', 0),
                'medium': stats.get('medium', 0),
                'low': stats.get('low', 0),
                'info': stats.get('info', 0)
            }
    
    # ===== Target Operations =====
    
    @classmethod
    def add_target(cls, url: str, **kwargs) -> int:
        """Add or update target."""
        with cls.get_connection() as conn:
            existing = conn.execute(
                "SELECT id FROM targets WHERE url=?", (url,)
            ).fetchone()
            
            if existing:
                update_fields = ['last_scanned=datetime(\'now\')']
                update_values = []
                
                for k, v in kwargs.items():
                    if k in ['domain', 'ip_address', 'technologies', 'status', 'notes']:
                        update_fields.append(f"{k}=?")
                        update_values.append(json.dumps(v) if isinstance(v, (dict, list)) else v)
                
                if update_values:
                    update_values.append(existing['id'])
                    conn.execute(
                        f"UPDATE targets SET {', '.join(update_fields)} WHERE id=?",
                        update_values
                    )
                return existing['id']
            else:
                cursor = conn.execute(
                    """INSERT INTO targets (url, domain, ip_address, technologies, status, notes)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (url, kwargs.get('domain'), kwargs.get('ip_address'),
                     json.dumps(kwargs.get('technologies', {})),
                     kwargs.get('status', 'pending'), kwargs.get('notes'))
                )
                conn.commit()
                return cursor.lastrowid
    
    # ===== Session Operations =====
    
    @classmethod
    def save_session(cls, name: str, target: str, state: Dict, data: Dict = None):
        """Save scan session."""
        with cls.get_connection() as conn:
            existing = conn.execute(
                "SELECT id FROM sessions WHERE name=?", (name,)
            ).fetchone()
            
            if existing:
                conn.execute(
                    """UPDATE sessions SET target=?, state=?, updated_at=datetime('now'), data=?
                       WHERE id=?""",
                    (target, json.dumps(state), json.dumps(data or {}), existing['id'])
                )
            else:
                conn.execute(
                    """INSERT INTO sessions (name, target, state, data)
                       VALUES (?, ?, ?, ?)""",
                    (name, target, json.dumps(state), json.dumps(data or {}))
                )
            conn.commit()
    
    @classmethod
    def load_session(cls, name: str) -> Optional[Dict]:
        """Load scan session."""
        with cls.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM sessions WHERE name=?", (name,)
            )
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['state'] = json.loads(result['state'])
                result['data'] = json.loads(result['data']) if result.get('data') else {}
                return result
        return None
    
    # ===== Logging Operations =====
    
    @classmethod
    def add_log(cls, scan_id: int, level: str, message: str):
        """Add scan log entry."""
        with cls.get_connection() as conn:
            conn.execute(
                "INSERT INTO scan_logs (scan_id, level, message) VALUES (?, ?, ?)",
                (scan_id, level, message)
            )
            conn.commit()
    
    @classmethod
    def get_logs(cls, scan_id: int, limit: int = 100) -> List[Dict]:
        """Get scan logs."""
        with cls.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM scan_logs WHERE scan_id=? ORDER BY timestamp DESC LIMIT ?",
                (scan_id, limit)
            )
            return [dict(row) for row in cursor.fetchall()]
    
    # ===== Subdomain Operations =====
    
    @classmethod
    def add_subdomains(cls, scan_id: int, domain: str, subdomains: List[Dict]) -> int:
        """Add discovered subdomains for a scan. Returns count added."""
        count = 0
        with cls.get_connection() as conn:
            for sub in subdomains:
                try:
                    conn.execute(
                        """INSERT OR IGNORE INTO subdomains 
                           (scan_id, domain, subdomain, url, ip_address, status_code,
                            title, content_length, technologies, webserver, alive, source)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (scan_id, domain,
                         sub.get('subdomain', ''),
                         sub.get('url', ''),
                         sub.get('ip', ''),
                         sub.get('status_code', 0),
                         sub.get('title', ''),
                         sub.get('content_length', 0),
                         json.dumps(sub.get('technologies', [])),
                         sub.get('webserver', ''),
                         1 if sub.get('alive') else 0,
                         sub.get('verified_by', 'discovery'))
                    )
                    count += 1
                except Exception as e:
                    logger.debug(f"Failed to insert subdomain {sub.get('subdomain')}: {e}")
            conn.commit()
        return count
    
    @classmethod
    def get_subdomains(cls, scan_id: int = None, domain: str = None, alive_only: bool = False) -> List[Dict]:
        """Get discovered subdomains with optional filters."""
        query = "SELECT * FROM subdomains WHERE 1=1"
        params = []
        
        if scan_id:
            query += " AND scan_id=?"
            params.append(scan_id)
        if domain:
            query += " AND domain=?"
            params.append(domain)
        if alive_only:
            query += " AND alive=1"
        
        query += " ORDER BY status_code ASC, subdomain ASC"
        
        with cls.get_connection() as conn:
            cursor = conn.execute(query, params)
            results = []
            for row in cursor.fetchall():
                result = dict(row)
                if result.get('technologies'):
                    try:
                        result['technologies'] = json.loads(result['technologies'])
                    except (json.JSONDecodeError, TypeError):
                        result['technologies'] = []
                results.append(result)
            return results
    
    @classmethod
    def get_subdomain_stats(cls, scan_id: int = None) -> Dict:
        """Get subdomain statistics."""
        with cls.get_connection() as conn:
            if scan_id:
                cursor = conn.execute(
                    "SELECT COUNT(*) as total, SUM(alive) as alive FROM subdomains WHERE scan_id=?",
                    (scan_id,)
                )
            else:
                cursor = conn.execute(
                    "SELECT COUNT(*) as total, SUM(alive) as alive FROM subdomains"
                )
            row = cursor.fetchone()
            
            # Get status code distribution
            if scan_id:
                cursor = conn.execute(
                    """SELECT status_code, COUNT(*) as count 
                       FROM subdomains WHERE scan_id=? AND status_code > 0
                       GROUP BY status_code ORDER BY count DESC""",
                    (scan_id,)
                )
            else:
                cursor = conn.execute(
                    """SELECT status_code, COUNT(*) as count 
                       FROM subdomains WHERE status_code > 0
                       GROUP BY status_code ORDER BY count DESC"""
                )
            status_dist = {str(r['status_code']): r['count'] for r in cursor.fetchall()}
            
            return {
                'total': row['total'] or 0,
                'alive': row['alive'] or 0,
                'status_code_distribution': status_dist,
            }
    
    # ===== Utility Operations =====
    
    @classmethod
    def get_stats(cls) -> Dict:
        """Get database statistics."""
        stats = {}
        tables = ['scans', 'vulnerabilities', 'targets', 'sessions', 'subdomains']
        
        with cls.get_connection() as conn:
            for table in tables:
                cursor = conn.execute(f"SELECT COUNT(*) as count FROM {table}")
                stats[table] = cursor.fetchone()['count']
        
        # Vulnerability breakdown
        vuln_stats = cls.get_vulnerability_stats()
        stats['vulnerability_breakdown'] = vuln_stats['by_severity']
        
        return stats
    
    @classmethod
    def export_all(cls) -> Dict:
        """Export all database contents."""
        data = {}
        
        with cls.get_connection() as conn:
            for table in ['scans', 'vulnerabilities', 'targets', 'sessions', 'payloads', 'subdomains']:
                cursor = conn.execute(f"SELECT * FROM {table}")
                data[table] = [dict(row) for row in cursor.fetchall()]
        
        return data
    
    @classmethod
    def cleanup(cls, days: int = 30):
        """Clean up old records."""
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        
        with cls.get_connection() as conn:
            conn.execute("DELETE FROM scans WHERE created_at < ?", (cutoff,))
            conn.execute("DELETE FROM scan_logs WHERE timestamp < ?", (cutoff,))
            conn.commit()
        
        logger.info(f"Cleaned up records older than {days} days")
    
    @classmethod
    def close(cls):
        """Close database connection."""
        if cls._connection:
            cls._connection.close()
            cls._connection = None
