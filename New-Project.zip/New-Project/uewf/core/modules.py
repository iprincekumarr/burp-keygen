"""
Module management system for uEWF.
"""

from typing import List, Dict, Optional, Type
from importlib import import_module
from pathlib import Path

from .logger import get_logger

logger = get_logger(__name__)


class BaseModule:
    """Base class for all uEWF modules."""
    
    name = "base"
    description = "Base module"
    version = "1.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = []
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def test(self, url: str, parameters: List = None, method: str = 'GET', session=None) -> List[Dict]:
        """Run module tests. Override in subclasses."""
        raise NotImplementedError
    
    def cleanup(self):
        """Cleanup module resources."""
        pass


class ModuleManager:
    """Manages uEWF modules."""
    
    _modules = {}
    _module_registry = {}
    
    @classmethod
    def register_module(cls, name: str, module_class: Type[BaseModule]):
        """Register a module."""
        cls._module_registry[name] = module_class
        logger.debug(f"Registered module: {name}")
    
    @classmethod
    def get_module(cls, name: str) -> Optional[BaseModule]:
        """Get module instance by name."""
        if name in cls._modules:
            return cls._modules[name]
        
        if name in cls._module_registry:
            module_class = cls._module_registry[name]
            cls._modules[name] = module_class()
            return cls._modules[name]
        
        # Try to lazy load
        try:
            module_path = f"uewf.modules.{name}"
            module = import_module(module_path)
            
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if isinstance(attr, type) and issubclass(attr, BaseModule) and attr != BaseModule:
                    cls._module_registry[name] = attr
                    cls._modules[name] = attr()
                    return cls._modules[name]
        except ImportError as e:
            logger.error(f"Failed to load module {name}: {e}")
        
        return None
    
    @classmethod
    def get_module_names(cls) -> List[str]:
        """Get list of available module names."""
        # Pre-defined module names
        module_names = ['sqli', 'xss', 'recon', 'proxy', 'reporting', 'chaining']
        
        # Add registered modules
        module_names.extend(cls._module_registry.keys())
        
        # Remove duplicates while preserving order
        seen = set()
        unique_names = []
        for name in module_names:
            if name not in seen:
                seen.add(name)
                unique_names.append(name)
        
        return unique_names
    
    @classmethod
    def get_modules(cls) -> List[Dict]:
        """Get list of all available modules with metadata."""
        modules = []
        
        for name in cls.get_module_names():
            module = cls.get_module(name)
            if module:
                modules.append({
                    'name': name,
                    'description': module.description,
                    'version': module.version,
                    'author': module.author,
                    'enabled': module.enabled,
                    'techniques': module.techniques
                })
        
        return modules
    
    @classmethod
    def get_module_info(cls, name: str) -> Optional[Dict]:
        """Get module information."""
        module = cls.get_module(name)
        if module:
            return {
                'name': name,
                'description': module.description,
                'version': module.version,
                'author': module.author,
                'enabled': module.enabled,
                'techniques': module.techniques
            }
        return None
    
    @classmethod
    def reload_modules(cls):
        """Reload all modules."""
        cls._modules = {}
        logger.info("Modules reloaded")

