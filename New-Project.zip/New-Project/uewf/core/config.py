"""
Configuration management module.
"""

import os
import json
import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from datetime import datetime
import copy


class Config:
    """Configuration manager singleton."""
    
    _instance = None
    _config = {}
    _config_dir = Path.home() / '.uewf'
    _config_file = _config_dir / 'config.yaml'
    
    DEFAULT_CONFIG = {
        'version': '1.0.0',
        'disclaimer_accepted': False,
        'disclaimer_accepted_date': None,
        'safe_mode': True,
        'rate_limit': 10,
        'timeout': 30,
        'max_threads': 10,
        'user_agent': 'uEWF-Security-Scanner/1.0 (Authorized Testing)',
        'output_dir': str(_config_dir / 'output'),
        'data_dir': str(_config_dir / 'data'),
        'log_dir': str(_config_dir / 'logs'),
        'database_path': str(_config_dir / 'uewf.db'),
        'proxy': None,
        'verify_ssl': True,
        'follow_redirects': True,
        'max_redirects': 5,
        'enable_colors': True,
        'auto_save': True,
        'report_template': 'default',
        'notification': {
            'enabled': False,
            'webhook_url': None,
            'email': None,
        },
        'modules': {
            'sqli': True,
            'xss': True,
            'ssrf': True,
            'xxe': True,
            'lfi': True,
            'command_injection': True,
        }
    }
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def initialize(cls):
        """Initialize configuration."""
        cls._config_dir.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        for subdir in ['data', 'output', 'logs', 'sessions', 'payloads', 'templates', 'plugins']:
            (cls._config_dir / subdir).mkdir(exist_ok=True)
        
        # Create default config if not exists
        if not cls._config_file.exists():
            cls._config = copy.deepcopy(cls.DEFAULT_CONFIG)
            cls._save()
        else:
            cls._load()
    
    @classmethod
    def load_file(cls, path: str):
        """Load configuration from file."""
        with open(path) as f:
            if path.endswith('.yaml') or path.endswith('.yml'):
                cls._config = yaml.safe_load(f) or {}
            elif path.endswith('.json'):
                cls._config = json.load(f)
            else:
                raise ValueError("Unsupported config format. Use .yaml or .json")
    
    @classmethod
    def _load(cls):
        """Load configuration from default file."""
        if cls._config_file.exists():
            with open(cls._config_file) as f:
                cls._config = yaml.safe_load(f) or {}
        else:
            cls._config = copy.deepcopy(cls.DEFAULT_CONFIG)
    
    @classmethod
    def _save(cls):
        """Save configuration to file."""
        with open(cls._config_file, 'w') as f:
            yaml.dump(cls._config, f, default_flow_style=False)
    
    @classmethod
    def get(cls, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        keys = key.split('.')
        value = cls._config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
        
        return value if value is not None else default
    
    @classmethod
    def set(cls, key: str, value: Any):
        """Set configuration value."""
        keys = key.split('.')
        config = cls._config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
        cls._save()
    
    @classmethod
    def get_all(cls) -> Dict:
        """Get all configuration."""
        return copy.deepcopy(cls._config)
    
    @classmethod
    def reset(cls):
        """Reset to default configuration."""
        cls._config = copy.deepcopy(cls.DEFAULT_CONFIG)
        cls._save()
    
    @classmethod
    def get_config_dir(cls) -> Path:
        """Get configuration directory."""
        return cls._config_dir
    
    @classmethod
    def get_data_dir(cls) -> Path:
        """Get data directory."""
        return cls._config_dir / 'data'
    
    @classmethod
    def get_output_dir(cls) -> Path:
        """Get output directory."""
        return cls._config_dir / 'output'

