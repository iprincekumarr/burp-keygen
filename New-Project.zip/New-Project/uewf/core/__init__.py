"""Core framework modules."""

