"""
Logging configuration for uEWF.
"""

import os
import sys
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional

from .config import Config


class LoggerManager:
    """Manages uEWF logging."""
    
    _instances = {}
    
    @classmethod
    def get_logger(cls, name: str, level: str = 'INFO') -> logging.Logger:
        """Get or create a logger instance."""
        if name in cls._instances:
            return cls._instances[name]
        
        logger = logging.getLogger(name)
        
        # Prevent propagation to root logger to avoid duplicate output
        logger.propagate = False
        
        # Set level
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        logger.setLevel(level_map.get(level.upper(), logging.INFO))
        
        # Only add handlers if none exist yet (prevents duplicate lines)
        if not logger.handlers:
            # Create formatters
            console_format = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(message)s',
                datefmt='%H:%M:%S'
            )
            file_format = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            
            # Console handler to stderr (doesn't interfere with stdout output)
            console_handler = logging.StreamHandler(sys.stderr)
            console_handler.setFormatter(console_format)
            console_handler.setLevel(logging.INFO)
            logger.addHandler(console_handler)
            
            # File handler
            try:
                log_dir = Config.get('log_dir', str(Path.home() / '.uewf' / 'logs'))
                Path(log_dir).mkdir(parents=True, exist_ok=True)
                
                log_file = Path(log_dir) / f"uewf_{datetime.now().strftime('%Y%m%d')}.log"
                file_handler = logging.FileHandler(log_file)
                file_handler.setFormatter(file_format)
                logger.addHandler(file_handler)
            except Exception:
                pass  # File logging is optional
        
        cls._instances[name] = logger
        return logger
    
    @classmethod
    def setup_logger(cls, name: str = 'uewf') -> logging.Logger:
        """Setup logger (alias for get_logger)."""
        return cls.get_logger(name)


def get_logger(name: str, level: str = 'INFO') -> logging.Logger:
    """Convenience function to get a logger."""
    return LoggerManager.get_logger(name, level)


def setup_logger(name: str = 'uewf') -> logging.Logger:
    """Convenience function to setup logger."""
    return LoggerManager.setup_logger(name)
