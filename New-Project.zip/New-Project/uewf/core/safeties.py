"""
Safety and validation module for uEWF.
Ensures responsible usage and prevents accidental damage.
"""

import re
import ipaddress
from urllib.parse import urlparse
from typing import List, Optional, Tuple
from pathlib import Path

from .logger import get_logger
from .config import Config
from .auth import AuthorizationManager

logger = get_logger(__name__)


class SafetyManager:
    """Manages safety checks and prevents harmful actions."""
    
    # Blocked internal IP ranges
    INTERNAL_RANGES = [
        '127.0.0.0/8',
        '10.0.0.0/8',
        '172.16.0.0/12',
        '192.168.0.0/16',
        '169.254.0.0/16',
        'fc00::/7',
        'fe80::/10',
    ]
    
    # Domains that should never be scanned without explicit permission
    BLOCKED_DOMAINS = [
        '.gov',
        '.mil',
        'google.com',
        'facebook.com',
        'microsoft.com',
        'apple.com',
        'amazon.com',
        'github.com',
        'gitlab.com',
        'bitbucket.org',
        'cloudflare.com',
        'akamai.com',
    ]
    
    # Dangerous payloads that could cause damage
    DESTRUCTIVE_PATTERNS = [
        r'drop\s+table',
        r'drop\s+database',
        r'truncate\s+table',
        r'delete\s+from.*',
        r'update.*set.*',
        r'insert\s+into.*',
        r'shutdown',
        r'restart',
        r'format',
        r'mkfs',
        r'dd\s+if=',
        r'>\s+/dev/',
        r'rm\s+-rf\s+/',
        r':\(\)\s*\{',
    ]
    
    def __init__(self):
        self.auth_manager = AuthorizationManager()
    
    def validate_target(self, target: str) -> bool:
        """
        Comprehensive target validation.
        
        Returns:
            bool: True if target is valid and authorized
        """
        if not target:
            logger.warning("Empty target URL")
            return False
        
        # Parse URL
        try:
            parsed = urlparse(target)
            if not parsed.netloc:
                parsed = urlparse(f"https://{target}")
        except Exception:
            logger.warning(f"Invalid URL format: {target}")
            return False
        
        domain = parsed.netloc.lower()
        
        # Remove port if present
        if ':' in domain:
            domain = domain.split(':')[0]
        
        # Check for blocked domains
        if self._is_blocked_domain(domain):
            logger.warning(f"Domain {domain} is blocked by default safety settings")
            return False
        
        # Check for internal IP addresses
        try:
            ip = ipaddress.ip_address(domain)
            if self._is_internal_ip(ip) and not Config.get('allow_internal', False):
                logger.warning(f"Internal IP {domain} requires explicit configuration")
                return False
        except ValueError:
            pass  # Not an IP address
        
        # Check authorization
        if not self.auth_manager.validate_target(target):
            logger.warning(f"Target {target} is not authorized")
            return False
        
        return True
    
    def validate_payload(self, payload: str, module: str) -> Tuple[bool, str]:
        """
        Validate payload for safety.
        
        Returns:
            Tuple[bool, str]: (is_safe, reason)
        """
        if not payload:
            return True, "Empty payload"
        
        payload_lower = payload.lower()
        
        # Check for destructive patterns
        for pattern in self.DESTRUCTIVE_PATTERNS:
            if re.search(pattern, payload_lower):
                return False, f"Potentially destructive pattern detected: {pattern}"
        
        # Module-specific checks
        if module == 'sqli':
            # SQL injection specific safety
            destructive_sql = [
                'xp_cmdshell',
                'sp_configure',
                'exec master..',
                'exec xp_',
                'bulk insert',
                'bulk column',
                'openrowset',
                'opendatasource',
            ]
            for pattern in destructive_sql:
                if pattern in payload_lower:
                    return False, f"Dangerous SQL command: {pattern}"
        
        elif module == 'command_injection':
            # Command injection specific safety
            dangerous_cmds = [
                'sudo', 'su', 'passwd', 'chmod', 'chown',
                'mount', 'umount', 'fdisk',
            ]
            for cmd in dangerous_cmds:
                if re.search(rf'\b{cmd}\b', payload_lower):
                    return False, f"Dangerous command: {cmd}"
        
        return True, "Payload is safe"
    
    def validate_parameter(self, parameter: str) -> bool:
        """
        Validate parameter name for testing.
        """
        if not parameter:
            return False
        
        # Skip authentication parameters
        auth_params = ['password', 'passwd', 'pass', 'secret', 'token', 'csrf', 'nonce']
        if parameter.lower() in auth_params:
            logger.warning(f"Skipping authentication parameter: {parameter}")
            return False
        
        return True
    
    def check_rate_limit(self, target: str) -> bool:
        """
        Check if we should rate limit requests to target.
        """
        max_rate = Config.get('rate_limit', 10)
        # Simple rate limiting logic
        return True
    
    def get_safe_payloads(self, module: str, level: int = 1) -> List[str]:
        """
        Get safe payloads that won't cause damage.
        
        Args:
            module: Module name (sqli, xss, etc.)
            level: 1-5, higher = more aggressive tests
        """
        from uewf.utils.payloads import PayloadManager
        pm = PayloadManager()
        
        all_payloads = pm.get_payloads(module)
        safe_payloads = []
        
        for payload in all_payloads:
            is_safe, _ = self.validate_payload(payload, module)
            if is_safe:
                safe_payloads.append(payload)
        
        # If level is low, return fewer payloads
        if level <= 2:
            return safe_payloads[:50]
        elif level <= 3:
            return safe_payloads[:200]
        else:
            return safe_payloads
    
    def _is_blocked_domain(self, domain: str) -> bool:
        """Check if domain is in blocked list."""
        for blocked in self.BLOCKED_DOMAINS:
            if domain.endswith(blocked) or domain == blocked:
                return True
        return False
    
    def _is_internal_ip(self, ip) -> bool:
        """Check if IP address is internal/rfc1918."""
        for internal_range in self.INTERNAL_RANGES:
            if isinstance(ip, (ipaddress.IPv4Address, ipaddress.IPv6Address)):
                if ip in ipaddress.ip_network(internal_range, strict=False):
                    return True
        return False
    
    def is_safe_request(self, method: str, url: str, data: dict = None) -> bool:
        """
        Check if a request is safe to make.
        """
        # Always safe for GET and HEAD
        if method.upper() in ['GET', 'HEAD', 'OPTIONS']:
            return True
        
        # Check for destructive methods
        if method.upper() in ['DELETE', 'PUT', 'PATCH']:
            if not Config.get('allow_write_methods', False):
                logger.warning(f"Write method {method} blocked by safety settings")
                return False
        
        return True
    
    def get_safe_threads(self, requested: int) -> int:
        """Get safe number of threads."""
        max_threads = Config.get('max_threads', 10)
        return min(requested, max_threads)

