"""Web dashboard for uEWF."""

