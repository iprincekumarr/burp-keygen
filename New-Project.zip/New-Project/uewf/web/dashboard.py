"""
Web dashboard for uEWF.
Provides a web interface for managing scans and viewing results.
"""

import json
import os
from pathlib import Path
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, jsonify, request, redirect, url_for, session, flash

from ..core.config import Config
from ..core.database import Database
from ..core.logger import get_logger
from ..utils.export import save_results

logger = get_logger(__name__)


def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.secret_key = os.urandom(24).hex()
    
    # Ensure templates exist
    template_dir = Path(__file__).parent / 'static' / 'templates'
    template_dir.mkdir(parents=True, exist_ok=True)
    app.template_folder = str(template_dir)
    
    # Initialize database
    try:
        Database.initialize()
    except Exception as e:
        logger.warning(f"Database initialization failed: {e}")
    
    # ===== Routes =====
    
    @app.route('/')
    def index():
        """Dashboard home page."""
        try:
            stats = Database.get_stats()
            recent_scans = Database.get_scans(limit=10)
        except Exception as e:
            stats = {'scans': 0, 'vulnerabilities': 0, 'targets': 0}
            recent_scans = []
        
        return render_template_string('''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>uEWF Dashboard</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                       background: #0f0f23; color: #e0e0e0; }
                .sidebar { position: fixed; left: 0; top: 0; width: 250px; height: 100vh;
                          background: #1a1a3e; padding: 20px; }
                .sidebar h2 { color: #667eea; margin-bottom: 30px; }
                .sidebar nav a { display: block; padding: 12px 15px; color: #b0b0d0;
                               text-decoration: none; border-radius: 8px; margin-bottom: 5px;
                               transition: all 0.3s; }
                .sidebar nav a:hover, .sidebar nav a.active { background: #2a2a5e; color: #667eea; }
                .main { margin-left: 250px; padding: 30px; }
                .header { margin-bottom: 30px; }
                .header h1 { font-size: 2em; color: #fff; }
                .header p { color: #8888aa; }
                .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                            gap: 20px; margin-bottom: 30px; }
                .stat-card { background: #1a1a3e; border-radius: 12px; padding: 25px;
                           border: 1px solid #2a2a5e; }
                .stat-card h3 { color: #8888aa; font-size: 0.9em; margin-bottom: 10px; }
                .stat-card .number { font-size: 2.5em; font-weight: bold; color: #667eea; }
                .stat-card .number.critical { color: #e53e3e; }
                .stat-card .number.high { color: #dd6b20; }
                .stat-card .number.medium { color: #d69e2e; }
                .stat-card .number.low { color: #38a169; }
                .section { background: #1a1a3e; border-radius: 12px; padding: 25px;
                          border: 1px solid #2a2a5e; margin-bottom: 20px; }
                .section h2 { color: #fff; margin-bottom: 20px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { padding: 12px; text-align: left; border-bottom: 1px solid #2a2a5e; }
                th { color: #8888aa; font-weight: 600; }
                td { color: #c0c0e0; }
                .badge { padding: 4px 10px; border-radius: 4px; font-size: 0.8em; font-weight: bold; }
                .badge.critical { background: #e53e3e; color: white; }
                .badge.high { background: #dd6b20; color: white; }
                .badge.medium { background: #d69e2e; color: black; }
                .badge.low { background: #38a169; color: white; }
                .badge.info { background: #3182ce; color: white; }
                .btn { display: inline-block; padding: 10px 20px; background: #667eea;
                     color: white; text-decoration: none; border-radius: 8px; border: none;
                     cursor: pointer; transition: background 0.3s; }
                .btn:hover { background: #5a6fd6; }
                .btn.danger { background: #e53e3e; }
                .btn.danger:hover { background: #c53030; }
                .empty-state { text-align: center; padding: 40px; color: #666; }
                @media (max-width: 768px) {
                    .sidebar { width: 100%; height: auto; position: relative; }
                    .main { margin-left: 0; }
                }
            </style>
        </head>
        <body>
            <div class="sidebar">
                <h2>🔒 uEWF</h2>
                <nav>
                    <a href="/" class="active">📊 Dashboard</a>
                    <a href="/scans">🔍 Scans</a>
                    <a href="/vulnerabilities">⚠️ Vulnerabilities</a>
                    <a href="/targets">🎯 Targets</a>
                    <a href="/reports">📄 Reports</a>
                    <a href="/config">⚙️ Settings</a>
                </nav>
            </div>
            
            <div class="main">
                <div class="header">
                    <h1>Dashboard</h1>
                    <p>uEWF Security Testing Framework - Overview</p>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3>Total Scans</h3>
                        <div class="number">{{ stats.scans }}</div>
                    </div>
                    <div class="stat-card">
                        <h3>Vulnerabilities</h3>
                        <div class="number">{{ stats.vulnerabilities }}</div>
                    </div>
                    <div class="stat-card">
                        <h3>Targets</h3>
                        <div class="number">{{ stats.targets }}</div>
                    </div>
                    <div class="stat-card">
                        <h3>Critical</h3>
                        <div class="number critical">{{ stats.get('vulnerability_breakdown', {}).get('critical', 0) }}</div>
                    </div>
                </div>
                
                <div class="section">
                    <h2>Recent Scans</h2>
                    {% if recent_scans %}
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Target</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for scan in recent_scans %}
                            <tr>
                                <td>#{{ scan.id }}</td>
                                <td>{{ scan.target }}</td>
                                <td><span class="badge {{ scan.status }}">{{ scan.status }}</span></td>
                                <td>{{ scan.created_at[:10] }}</td>
                                <td><a href="/scans/{{ scan.id }}" class="btn">View</a></td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                    {% else %}
                    <div class="empty-state">
                        <p>No scans yet. Start your first scan!</p>
                        <br>
                        <a href="/scans/new" class="btn">New Scan</a>
                    </div>
                    {% endif %}
                </div>
            </div>
        </body>
        </html>
        ''', stats=stats, recent_scans=recent_scans)
    
    @app.route('/scans')
    def scans():
        """List all scans."""
        try:
            scan_list = Database.get_scans(limit=50)
        except Exception:
            scan_list = []
        
        return render_template_string('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Scans - uEWF</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, sans-serif; background: #0f0f23; color: #e0e0e0; }
                .container { max-width: 1200px; margin: 0 auto; padding: 30px; }
                h1 { color: #fff; margin-bottom: 10px; }
                p { color: #8888aa; margin-bottom: 30px; }
                table { width: 100%; border-collapse: collapse; background: #1a1a3e; border-radius: 12px; overflow: hidden; }
                th, td { padding: 15px; text-align: left; border-bottom: 1px solid #2a2a5e; }
                th { background: #2a2a5e; color: #8888aa; }
                td { color: #c0c0e0; }
                .badge { padding: 4px 10px; border-radius: 4px; font-size: 0.8em; }
                .badge.completed { background: #38a169; color: white; }
                .badge.running { background: #3182ce; color: white; }
                .badge.failed { background: #e53e3e; color: white; }
                .btn { display: inline-block; padding: 8px 16px; background: #667eea; color: white;
                     text-decoration: none; border-radius: 6px; }
                .btn:hover { background: #5a6fd6; }
                .btn.primary { background: #667eea; }
                .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
                .empty { text-align: center; padding: 60px; color: #666; }
                .empty a { color: #667eea; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div>
                        <h1>🔍 Scan History</h1>
                        <p>View and manage security scans</p>
                    </div>
                    <a href="/" class="btn">← Dashboard</a>
                </div>
                
                {% if scans %}
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Target</th>
                            <th>Status</th>
                            <th>Started</th>
                            <th>Duration</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for scan in scans %}
                        <tr>
                            <td>#{{ scan.id }}</td>
                            <td>{{ scan.target[:60] }}...</td>
                            <td><span class="badge {{ scan.status }}">{{ scan.status }}</span></td>
                            <td>{{ scan.start_time[:19] }}</td>
                            <td>{% if scan.end_time %}{{ scan.end_time[:19] }}{% else %}In progress{% endif %}</td>
                            <td><a href="/scans/{{ scan.id }}" class="btn">Details</a></td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
                {% else %}
                <div class="empty">
                    <h2>No scans yet</h2>
                    <p>Run a scan from the command line using <code>uewf scan <target></code></p>
                </div>
                {% endif %}
            </div>
        </body>
        </html>
        ''', scans=scan_list)
    
    @app.route('/vulnerabilities')
    def vulnerabilities():
        """List all vulnerabilities."""
        try:
            vulns = Database.get_vulnerabilities()
        except Exception:
            vulns = []
        
        return render_template_string('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Vulnerabilities - uEWF</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, sans-serif; background: #0f0f23; color: #e0e0e0; }
                .container { max-width: 1200px; margin: 0 auto; padding: 30px; }
                h1 { color: #fff; margin-bottom: 10px; }
                p { color: #8888aa; margin-bottom: 30px; }
                table { width: 100%; border-collapse: collapse; background: #1a1a3e; border-radius: 12px; overflow: hidden; }
                th, td { padding: 15px; text-align: left; border-bottom: 1px solid #2a2a5e; }
                th { background: #2a2a5e; color: #8888aa; }
                td { color: #c0c0e0; }
                .severity-critical { color: #e53e3e; font-weight: bold; }
                .severity-high { color: #dd6b20; font-weight: bold; }
                .severity-medium { color: #d69e2e; }
                .severity-low { color: #38a169; }
                .severity-info { color: #3182ce; }
                .btn { display: inline-block; padding: 8px 16px; background: #667eea; color: white;
                     text-decoration: none; border-radius: 6px; }
                .btn:hover { background: #5a6fd6; }
                .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
                .empty { text-align: center; padding: 60px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div>
                        <h1>⚠️ Vulnerabilities</h1>
                        <p>Discovered security vulnerabilities</p>
                    </div>
                    <a href="/" class="btn">← Dashboard</a>
                </div>
                
                {% if vulns %}
                <table>
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Severity</th>
                            <th>URL</th>
                            <th>Parameter</th>
                            <th>Discovered</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for vuln in vulns %}
                        <tr>
                            <td>{{ vuln.type }}</td>
                            <td class="severity-{{ vuln.severity }}">{{ vuln.severity }}</td>
                            <td>{{ vuln.url[:50] }}...</td>
                            <td>{{ vuln.parameter or '-' }}</td>
                            <td>{{ vuln.discovered_at[:19] }}</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
                {% else %}
                <div class="empty">
                    <h2>No vulnerabilities found</h2>
                    <p>Run a scan to discover vulnerabilities.</p>
                </div>
                {% endif %}
            </div>
        </body>
        </html>
        ''', vulns=vulns)
    
    @app.route('/api/stats')
    def api_stats():
        """API endpoint for dashboard statistics."""
        try:
            stats = Database.get_stats()
            return jsonify(stats)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/scans')
    def api_scans():
        """API endpoint for scans list."""
        try:
            scans = Database.get_scans(limit=100)
            return jsonify({'scans': scans})
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/scans/<int:scan_id>')
    def api_scan_detail(scan_id: int):
        """API endpoint for scan details."""
        try:
            scan = Database.get_scan(scan_id)
            if not scan:
                return jsonify({'error': 'Scan not found'}), 404
            
            vulns = Database.get_vulnerabilities(scan_id=scan_id)
            scan['vulnerabilities'] = vulns
            
            return jsonify(scan)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/vulnerabilities')
    def api_vulnerabilities():
        """API endpoint for vulnerabilities list."""
        try:
            severity = request.args.get('severity')
            vulns = Database.get_vulnerabilities(severity=severity)
            return jsonify({'vulnerabilities': vulns})
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    return app


def render_template_string(template_string: str, **context):
    """Render a template string with Jinja2."""
    from jinja2 import Template
    template = Template(template_string)
    return template.render(**context)


def run_dashboard(host: str = '127.0.0.1', port: int = 8080, debug: bool = False):
    """Run the web dashboard."""
    app = create_app()
    logger.info(f"Starting uEWF dashboard on http://{host}:{port}")
    app.run(host=host, port=port, debug=debug)

