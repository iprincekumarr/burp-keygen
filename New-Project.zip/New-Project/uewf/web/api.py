"""
REST API module for uEWF.
Provides programmatic access to uEWF functionality.
"""

from flask import Blueprint, jsonify, request
from ..core.database import Database
from ..core.logger import get_logger

logger = get_logger(__name__)

# Create API blueprint
api = Blueprint('api', __name__, url_prefix='/api/v1')


@api.route('/health')
def health():
    """Health check endpoint."""
    return jsonify({
        'status': 'ok',
        'version': '1.0.0',
        'name': 'uEWF API'
    })


@api.route('/stats')
def get_stats():
    """Get framework statistics."""
    try:
        stats = Database.get_stats()
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/scans')
def get_scans():
    """Get list of scans."""
    try:
        limit = request.args.get('limit', 50, type=int)
        scans = Database.get_scans(limit=limit)
        return jsonify({'scans': scans, 'count': len(scans)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/scans/<int:scan_id>')
def get_scan(scan_id):
    """Get scan details."""
    try:
        scan = Database.get_scan(scan_id)
        if not scan:
            return jsonify({'error': 'Scan not found'}), 404
        
        vulns = Database.get_vulnerabilities(scan_id=scan_id)
        scan['vulnerabilities'] = vulns
        
        return jsonify(scan)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/vulnerabilities')
def get_vulnerabilities():
    """Get vulnerabilities with optional filters."""
    try:
        scan_id = request.args.get('scan_id', type=int)
        severity = request.args.get('severity')
        
        vulns = Database.get_vulnerabilities(scan_id=scan_id, severity=severity)
        return jsonify({'vulnerabilities': vulns, 'count': len(vulns)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/targets')
def get_targets():
    """Get list of targets."""
    try:
        from .core.database import Database
        targets = Database.export_all().get('targets', [])
        return jsonify({'targets': targets, 'count': len(targets)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/modules')
def get_modules():
    """Get list of available modules."""
    try:
        from ..core.modules import ModuleManager
        modules = ModuleManager.get_modules()
        return jsonify({'modules': modules, 'count': len(modules)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

