"""
Unified endpoint discovery engine for uEWF.
Combines multiple discovery techniques:
- Wayback Machine (waybackurls / Archive.org API)
- GAU (Get All URLs)
- Katana crawler
- Traditional crawling (links, forms, sitemap, robots.txt)
- Common path probing
- JS file parsing
"""

import re
import json
from typing import List, Dict, Set, Optional
from urllib.parse import urlparse, parse_qs, urljoin, urlencode
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

import requests
from bs4 import BeautifulSoup

from ..core.logger import get_logger
from ..core.config import Config
from .external import get_tool_manager

logger = get_logger(__name__)


class DiscoveryEngine:
    """
    Comprehensive endpoint discovery engine.
    Aggregates results from multiple sources.
    """
    
    # Common directories to probe for additional endpoints
    COMMON_DIRS = [
        '/php/', '/admin/', '/includes/', '/assets/', '/pages/',
        '/uploads/', '/images/', '/css/', '/js/', '/lib/',
        '/api/', '/v1/', '/v2/', '/rest/', '/ajax/',
        '/student/', '/teacher/', '/staff/', '/management/',
        '/portal/', '/user/', '/account/', '/profile/',
        '/search/', '/download/', '/view/', '/details/',
        '/app/', '/static/', '/public/', '/private/',
        '/tmp/', '/backup/', '/old/', '/test/', '/dev/',
        '/staging/', '/beta/', '/demo/', '/docs/',
    ]
    
    # Common PHP file paths to probe directly
    COMMON_PHP_PATHS = [
        '/php/gallary.php', '/php/gallery.php', '/php/index.php',
        '/php/login.php', '/php/config.php', '/php/db.php',
        '/php/view.php', '/php/details.php', '/php/profile.php',
        '/php/search.php', '/php/display.php', '/php/show.php',
        '/php/page.php', '/php/item.php', '/php/product.php',
        '/php/download.php', '/php/upload.php', '/php/export.php',
        '/php/import.php', '/php/delete.php', '/php/edit.php',
        '/php/add.php', '/php/update.php', '/php/save.php',
        '/admin/index.php', '/admin/login.php', '/admin/dashboard.php',
        '/pages/index.php', '/includes/config.php', '/api/index.php',
        '/ajax.php', '/load.php', '/include.php', '/require.php',
        '/config.php', '/functions.php', '/db_config.php',
        '/connection.php', '/database.php', '/global.php',
    ]
    
    def __init__(self, target: str, session: requests.Session = None):
        self.target = target.rstrip('/')
        parsed = urlparse(target)
        self.base_url = f"{parsed.scheme}://{parsed.netloc}"
        self.domain = parsed.netloc
        if ':' in self.domain:
            self.domain = self.domain.split(':')[0]
        
        self.session = session or requests.Session()
        self.tool_manager = get_tool_manager()
        self.results = []  # List of {url, parameters, method, source}
        self.seen_urls: Set[str] = set()
    
    def discover_all(self, depth: int = 3, use_external: bool = True, use_deep_crawl: bool = False) -> List[Dict]:
        """
        Run all discovery methods and return aggregated results.
        
        Args:
            depth: Crawl depth for traditional crawling
            use_external: Whether to use external tools (waybackurls, gau, katana)
            use_deep_crawl: Whether to use katana for deep JS/SPA crawling
            
        Returns:
            List of {url, parameters, method, source} dicts
        """
        logger.info(f"Starting comprehensive endpoint discovery for {self.target}")
        start_time = time.time()
        
        discovery_methods = []
        
        # 1. Traditional crawling
        discovery_methods.append(self._crawl_endpoints)
        
        # 2. Robots.txt and sitemap.xml parsing
        discovery_methods.append(self._parse_known_files)
        
        # 3. Common path probing
        discovery_methods.append(self._probe_common_paths)
        
        # 4. Wayback Machine / GAU (external tools)
        if use_external:
            discovery_methods.append(self._discover_wayback_gau)
        
        # 5. Katana deep crawl
        if use_deep_crawl and self.tool_manager.is_tool_installed('katana'):
            discovery_methods.append(self._discover_katana)
        
        # Run all discovery methods
        for method in discovery_methods:
            try:
                method()
            except Exception as e:
                logger.debug(f"Discovery method {method.__name__} failed: {e}")
        
        elapsed = time.time() - start_time
        logger.info(f"Discovery completed in {elapsed:.1f}s - found {len(self.results)} unique endpoints")
        
        # Sort: endpoints with parameters first, then by URL
        self.results.sort(key=lambda x: (-len(x.get('parameters', [])), x['url']))
        
        return self.results
    
    def _crawl_endpoints(self):
        """Traditional crawling from the target URL."""
        logger.info("Phase 1: Traditional crawling")
        visited = set()
        to_visit = [self.target]
        seen_urls_before = len(self.seen_urls)
        
        while to_visit and len(visited) < 100:
            url = to_visit.pop(0)
            if url in visited:
                continue
            visited.add(url)
            
            try:
                response = self.session.get(url, timeout=self.timeout())
                
                if 'text/html' in response.headers.get('Content-Type', ''):
                    soup = BeautifulSoup(response.text, 'lxml')
                    
                    # Find all links
                    for link in soup.find_all('a', href=True):
                        href = link['href']
                        full_url = self._resolve_url(href)
                        if full_url and (full_url.startswith(self.target) or full_url.startswith(self.base_url)):
                            if full_url not in visited and full_url not in to_visit and len(to_visit) < 200:
                                to_visit.append(full_url)
                            self._add_endpoint(full_url, source='crawl')
                    
                    # Find all forms
                    for form in soup.find_all('form'):
                        form_action = form.get('action', url)
                        form_url = self._resolve_url(form_action)
                        form_method = form.get('method', 'GET').upper()
                        
                        form_params = []
                        for input_tag in form.find_all(['input', 'textarea', 'select']):
                            name = input_tag.get('name')
                            if name:
                                form_params.append({
                                    'name': name,
                                    'type': input_tag.get('type', 'text'),
                                    'value': input_tag.get('value', '')
                                })
                        
                        if form_url:
                            self._add_endpoint(form_url, method=form_method, parameters=form_params, source='crawl_form')
                    
                    # Find scripts (potential JS endpoints)
                    for script in soup.find_all('script', src=True):
                        src = script['src']
                        full_url = self._resolve_url(src)
                        if full_url and (full_url.startswith(self.target) or full_url.startswith(self.base_url)):
                            # Try to fetch and parse JS for endpoints
                            self._parse_js_for_endpoints(full_url)
                    
                    # Probe common subdirectories
                    parsed = urlparse(url)
                    base = f"{parsed.scheme}://{parsed.netloc}"
                    for subdir in self.COMMON_DIRS:
                        probe_url = f"{base}{subdir}"
                        if probe_url not in visited and probe_url not in to_visit and len(to_visit) < 200:
                            to_visit.append(probe_url)
            
            except Exception as e:
                logger.debug(f"Crawl failed for {url}: {e}")
        
        new_found = len(self.seen_urls) - seen_urls_before
        logger.info(f"Crawling discovered {new_found} endpoints")
    
    def _parse_known_files(self):
        """Parse robots.txt and sitemap.xml for endpoints."""
        logger.info("Phase 2: Parsing robots.txt and sitemap.xml")
        seen_before = len(self.seen_urls)
        
        # robots.txt
        try:
            robots_url = f"{self.base_url}/robots.txt"
            resp = self.session.get(robots_url, timeout=10)
            if resp.status_code == 200:
                for line in resp.text.split('\n'):
                    line = line.strip()
                    if line.lower().startswith('disallow:'):
                        path = line.split(':', 1)[1].strip() if ':' in line else ''
                        if path:
                            full_url = f"{self.base_url}{path}"
                            self._add_endpoint(full_url, source='robots.txt')
                    elif line.lower().startswith('allow:'):
                        path = line.split(':', 1)[1].strip() if ':' in line else ''
                        if path:
                            full_url = f"{self.base_url}{path}"
                            self._add_endpoint(full_url, source='robots.txt')
                    elif line.lower().startswith('sitemap:'):
                        sitemap_url = line.split(':', 1)[1].strip() if ':' in line else ''
                        if sitemap_url:
                            self._parse_sitemap(sitemap_url)
        except Exception as e:
            logger.debug(f"robots.txt parse failed: {e}")
        
        # sitemap.xml
        try:
            sitemap_url = f"{self.base_url}/sitemap.xml"
            self._parse_sitemap(sitemap_url)
        except Exception as e:
            logger.debug(f"sitemap.xml parse failed: {e}")
        
        new_found = len(self.seen_urls) - seen_before
        logger.info(f"Known files discovered {new_found} endpoints")
    
    def _parse_sitemap(self, sitemap_url: str):
        """Parse a sitemap XML file."""
        try:
            resp = self.session.get(sitemap_url, timeout=10)
            if resp.status_code == 200:
                urls = re.findall(r'<loc>(.*?)</loc>', resp.text, re.IGNORECASE)
                for url in urls:
                    self._add_endpoint(url.strip(), source='sitemap')
                nested = re.findall(r'<sitemap>\s*<loc>(.*?)</loc>', resp.text, re.IGNORECASE)
                for nested_url in nested:
                    self._parse_sitemap(nested_url.strip())
        except Exception as e:
            logger.debug(f"Sitemap parse failed: {e}")
    
    def _probe_common_paths(self):
        """Probe common PHP file paths and directories."""
        logger.info("Phase 3: Probing common paths")
        seen_before = len(self.seen_urls)
        
        def probe_path(path: str) -> Optional[str]:
            url = f"{self.base_url}/{path.lstrip('/')}"
            if url in self.seen_urls:
                return None
            try:
                resp = self.session.get(url, timeout=5, allow_redirects=False)
                if resp.status_code in [200, 301, 302]:
                    return url
            except Exception:
                pass
            return None
        
        with ThreadPoolExecutor(max_workers=15) as executor:
            futures_php = {executor.submit(probe_path, p): p for p in self.COMMON_PHP_PATHS}
            for future in as_completed(futures_php):
                result = future.result()
                if result:
                    self._add_endpoint(result, source='probe')
            
            futures_dir = {executor.submit(probe_path, d): d for d in self.COMMON_DIRS}
            for future in as_completed(futures_dir):
                result = future.result()
                if result:
                    self._add_endpoint(result, source='probe')
        
        new_found = len(self.seen_urls) - seen_before
        logger.info(f"Path probing discovered {new_found} endpoints")
    
    def _discover_wayback_gau(self):
        """Discover URLs using Wayback Machine and GAU."""
        logger.info("Phase 4: Wayback Machine / GAU discovery")
        seen_before = len(self.seen_urls)
        
        endpoints = self.tool_manager.discover_wayback_gau(self.domain)
        for ep in endpoints:
            self._add_endpoint(ep.get('full_url', ep['url']), 
                               parameters=ep.get('parameters', []), 
                               source='wayback_gau')
        
        new_found = len(self.seen_urls) - seen_before
        logger.info(f"Wayback/GAU discovered {new_found} new endpoints")
    
    def _discover_katana(self):
        """Discover endpoints using katana crawler."""
        logger.info("Phase 5: Katana deep crawl")
        seen_before = len(self.seen_urls)
        
        endpoints = self.tool_manager.discover_katana(self.target, depth=3)
        for ep in endpoints:
            self._add_endpoint(ep.get('full_url', ep['url']),
                               parameters=ep.get('parameters', []),
                               source='katana')
        
        new_found = len(self.seen_urls) - seen_before
        logger.info(f"Katana discovered {new_found} new endpoints")
    
    def _parse_js_for_endpoints(self, js_url: str):
        """Parse a JavaScript file for potential endpoints."""
        try:
            resp = self.session.get(js_url, timeout=10)
            if resp.status_code == 200 and resp.headers.get('Content-Type', '').startswith(('text/javascript', 'application/javascript', 'text/plain')):
                content = resp.text
                patterns = [
                    r'["\'](https?://[^"\'\s]+)["\']',
                    r'url\s*[:=]\s*["\']([^"\'\s]+)["\']',
                    r'fetch\(["\']([^"\'\s]+)["\']',
                    r'axios\.(?:get|post|put|delete)\(["\']([^"\'\s]+)["\']',
                    r'\$\s*\.\s*(?:get|post|ajax)\(["\']([^"\'\s]+)["\']',
                    r'XMLHttpRequest\(\)[\s\S]{0,100}open\(["\'][A-Z]*["\'],\s*["\']([^"\'\s]+)["\']',
                ]
                for pattern in patterns:
                    matches = re.findall(pattern, content)
                    for match in matches:
                        if match.startswith('/'):
                            full_url = urljoin(self.base_url, match)
                            self._add_endpoint(full_url, source='js_parse')
                        elif match.startswith(('http://', 'https://')):
                            self._add_endpoint(match, source='js_parse')
        except Exception as e:
            logger.debug(f"JS parse failed for {js_url}: {e}")
    
    # ========== ENDPOINT REGISTRATION (FIXED) ==========
    
    def _add_endpoint(self, url: str, method: str = 'GET', parameters: list = None, source: str = 'unknown'):
        """
        Register an endpoint for vulnerability scanning.
        
        This method properly extracts parameters from:
        - Query strings in URLs (e.g., ?id=1&page=2 → ['id', 'page'])
        - External parameter lists from forms/wayback/gau/katana
        """
        if not url:
            return
        
        # Step 1: Always initialize param_names to empty list
        param_names = []
        
        # Step 2: Extract parameters from URL query string
        if '?' in url:
            base = url.split('?')[0]
            query = url.split('?')[1]
            parsed_params = parse_qs(query)
            param_names = list(parsed_params.keys())
        else:
            base = url
        
        # Step 3: Merge with parameters passed from external sources
        if parameters and isinstance(parameters, list):
            if parameters and isinstance(parameters[0], dict):
                ext_params = [p['name'] for p in parameters if 'name' in p]
                # Use dict.fromkeys to preserve order and remove duplicates
                param_names = list(dict.fromkeys(param_names + ext_params))
            elif parameters and isinstance(parameters[0], str):
                param_names = list(dict.fromkeys(param_names + list(parameters)))
        
        # Step 4: Skip non-HTTP(S) and anchor-only URLs
        if not base.startswith(('http://', 'https://')):
            return
        
        # Step 5: Register if unique (base URL + method combination)
        key = f"{base}|{method}"
        if key not in self.seen_urls:
            self.seen_urls.add(key)
            self.results.append({
                'url': base,
                'method': method,
                'parameters': param_names,
                'source': source,
            })
    
    def _resolve_url(self, href: str) -> Optional[str]:
        """Resolve relative URL to absolute."""
        if not href or href.startswith('#') or href.startswith('javascript:'):
            return None
        if href.startswith(('http://', 'https://')):
            return href
        return urljoin(self.target, href)
    
    def timeout(self) -> int:
        """Get request timeout."""
        return Config.get('timeout', 30)
