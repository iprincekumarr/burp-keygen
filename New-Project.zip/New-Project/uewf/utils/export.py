"""
Data export utilities for uEWF.
Handles saving results in various formats.
"""

import json
import csv
import os
from typing import Dict, List, Any
from pathlib import Path
from datetime import datetime

from ..core.logger import get_logger
from ..core.config import Config

logger = get_logger(__name__)


def save_results(data: Any, output_path: str, format: str = 'json') -> str:
    """Save scan results to file in specified format."""
    
    # Ensure output directory exists
    output_dir = Path(output_path).parent
    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)
    
    # Add .csv if missing
    if not output_path.endswith(f'.{format}'):
        output_path = f"{output_path}.{format}"
    
    if format == 'json':
        return _save_json(data, output_path)
    elif format == 'csv':
        return _save_csv(data, output_path)
    elif format == 'html':
        return _save_html(data, output_path)
    elif format == 'markdown':
        return _save_markdown(data, output_path)
    else:
        raise ValueError(f"Unsupported format: {format}")


def _save_json(data: Any, path: str) -> str:
    """Save data as JSON file."""
    with open(path, 'w') as f:
        json.dump(data, f, indent=2, default=str)
    logger.info(f"Results saved to {path}")
    return path


def _save_csv(data: Dict, path: str) -> str:
    """Save vulnerabilities as CSV file."""
    vulns = data.get('vulnerabilities', data if isinstance(data, list) else [])
    
    if not isinstance(vulns, list):
        vulns = [vulns]
    
    if not vulns:
        # Save empty CSV with headers
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Type', 'Severity', 'URL', 'Parameter', 'Description'])
        return path
    
    # Get all possible field names
    fieldnames = set()
    for vuln in vulns:
        if isinstance(vuln, dict):
            fieldnames.update(vuln.keys())
    
    # Ensure standard fields are first
    standard_fields = ['type', 'severity', 'url', 'parameter', 'description', 'payload', 'evidence', 'remediation', 'confidence']
    ordered_fields = [f for f in standard_fields if f in fieldnames]
    ordered_fields.extend([f for f in fieldnames if f not in standard_fields])
    
    with open(path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=ordered_fields)
        writer.writeheader()
        for vuln in vulns:
            if isinstance(vuln, dict):
                writer.writerow(vuln)
    
    logger.info(f"Results saved to {path}")
    return path


def _save_html(data: Dict, path: str) -> str:
    """Save data as HTML file (simple table format)."""
    vulns = data.get('vulnerabilities', [data] if isinstance(data, dict) else data or [])
    
    html = [
        '<!DOCTYPE html>',
        '<html><head><meta charset="UTF-8">',
        '<title>uEWF Scan Results</title>',
        '<style>',
        'body { font-family: Arial, sans-serif; margin: 20px; }',
        'table { border-collapse: collapse; width: 100%; }',
        'th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }',
        'th { background-color: #667eea; color: white; }',
        'tr:nth-child(even) { background-color: #f2f2f2; }',
        '.critical { color: #e53e3e; font-weight: bold; }',
        '.high { color: #dd6b20; font-weight: bold; }',
        '.medium { color: #d69e2e; }',
        '.low { color: #38a169; }',
        '.info { color: #3182ce; }',
        '</style></head><body>',
        '<h1>uEWF Scan Results</h1>',
        f'<p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>',
        f'<p>Total vulnerabilities: {len(vulns)}</p>',
    ]
    
    if vulns:
        # Get field names
        fieldnames = set()
        for v in vulns:
            if isinstance(v, dict):
                fieldnames.update(v.keys())
        
        standard_fields = ['type', 'severity', 'url', 'parameter', 'description', 'payload', 'evidence', 'confidence']
        ordered_fields = [f for f in standard_fields if f in fieldnames]
        ordered_fields.extend([f for f in fieldnames if f not in standard_fields])
        
        html.append('<table><thead><tr>')
        for field in ordered_fields:
            html.append(f'<th>{field.title()}</th>')
        html.append('</tr></thead><tbody>')
        
        for vuln in vulns:
            if isinstance(vuln, dict):
                severity = vuln.get('severity', 'info')
                html.append(f'<tr class="{severity}">')
                for field in ordered_fields:
                    value = vuln.get(field, '')
                    if field == 'severity':
                        html.append(f'<td><span class="{value}">{value}</span></td>')
                    else:
                        html.append(f'<td>{value}</td>')
                html.append('</tr>')
        
        html.append('</tbody></table>')
    else:
        html.append('<p>No vulnerabilities found.</p>')
    
    html.extend([
        '</body></html>'
    ])
    
    with open(path, 'w') as f:
        f.write('\n'.join(html))
    
    logger.info(f"Results saved to {path}")
    return path


def _save_markdown(data: Dict, path: str) -> str:
    """Save data as Markdown file."""
    vulns = data.get('vulnerabilities', [data] if isinstance(data, dict) else data or [])
    
    md = [
        '# uEWF Scan Results',
        f'*Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}*',
        '',
        f'**Total Vulnerabilities:** {len(vulns)}',
        '',
    ]
    
    if vulns:
        md.append('## Vulnerabilities')
        md.append('')
        md.append('| Severity | Type | URL | Parameter |')
        md.append('|----------|------|-----|-----------|')
        
        for vuln in vulns:
            if isinstance(vuln, dict):
                md.append(f"| {vuln.get('severity', 'info')} | {vuln.get('type', '')} | {vuln.get('url', '')} | {vuln.get('parameter', '')} |")
        
        md.append('')
        md.append('## Details')
        md.append('')
        
        for i, vuln in enumerate(vulns, 1):
            if isinstance(vuln, dict):
                md.append(f'### {i}. {vuln.get("type", "Unknown")}')
                md.append('')
                for key, value in vuln.items():
                    if value:
                        md.append(f'- **{key.title()}:** {value}')
                md.append('')
    
    with open(path, 'w') as f:
        f.write('\n'.join(md))
    
    logger.info(f"Results saved to {path}")
    return path

