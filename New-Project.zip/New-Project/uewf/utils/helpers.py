"""
Helper utility functions for uEWF.
"""

import re
import hashlib
import random
import string
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse, urljoin, parse_qs
from datetime import datetime


def normalize_url(url: str) -> str:
    """Normalize URL to standard format."""
    url = url.strip()
    
    if not url.startswith(('http://', 'https://')):
        url = f'https://{url}'
    
    # Remove default ports
    parsed = urlparse(url)
    netloc = parsed.netloc
    
    if parsed.port == 80 or parsed.port == 443:
        netloc = parsed.hostname
    
    from urllib.parse import ParseResult
    normalized = ParseResult(
        scheme=parsed.scheme,
        netloc=netloc,
        path=parsed.path.rstrip('/') if parsed.path else '/',
        params=parsed.params,
        query=parsed.query,
        fragment=parsed.fragment
    )
    
    return normalized.geturl()


def is_valid_url(url: str) -> bool:
    """Check if URL is valid."""
    try:
        parsed = urlparse(url)
        return bool(parsed.netloc) and bool(parsed.scheme)
    except Exception:
        return False


def extract_domain(url: str) -> str:
    """Extract domain from URL."""
    parsed = urlparse(url)
    domain = parsed.netloc.lower()
    
    # Remove port if present
    if ':' in domain:
        domain = domain.split(':')[0]
    
    return domain


def generate_id(prefix: str = 'uewf') -> str:
    """Generate unique ID."""
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    random_hash = hashlib.md5(str(random.random()).encode()).hexdigest()[:6]
    return f"{prefix}_{timestamp}_{random_hash}"


def random_string(length: int = 8) -> str:
    """Generate random string."""
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))


def parse_cookies(cookie_string: str) -> Dict[str, str]:
    """Parse cookie string into dictionary."""
    cookies = {}
    if cookie_string:
        for item in cookie_string.split(';'):
            item = item.strip()
            if '=' in item:
                key, value = item.split('=', 1)
                cookies[key.strip()] = value.strip()
    return cookies


def parse_headers(header_list: List[str]) -> Dict[str, str]:
    """Parse list of header strings into dictionary."""
    headers = {}
    for header in header_list:
        if ':' in header:
            key, value = header.split(':', 1)
            headers[key.strip()] = value.strip()
    return headers


def chunk_list(lst: List, chunk_size: int) -> List[List]:
    """Split list into chunks."""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def safe_truncate(text: str, max_length: int = 500) -> str:
    """Safely truncate text to max length."""
    if len(text) <= max_length:
        return text
    return text[:max_length] + '...'


def extract_params_from_url(url: str) -> Dict[str, str]:
    """Extract parameters from URL."""
    parsed = urlparse(url)
    return parse_qs(parsed.query)


def merge_dicts(base: Dict, override: Dict) -> Dict:
    """Deep merge two dictionaries."""
    result = base.copy()
    
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result


def flatten_dict(d: Dict, parent_key: str = '', sep: str = '.') -> Dict:
    """Flatten nested dictionary."""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def colorize_severity(severity: str) -> str:
    """Return ANSI color code for severity level."""
    colors = {
        'critical': '\033[91m',  # Red
        'high': '\033[91m',      # Red
        'medium': '\033[93m',    # Yellow
        'low': '\033[92m',       # Green
        'info': '\033[94m',      # Blue
    }
    reset = '\033[0m'
    return f"{colors.get(severity, '')}{severity.upper()}{reset}"


def calculate_risk_score(vulnerabilities: List[Dict]) -> float:
    """Calculate overall risk score from vulnerabilities."""
    weights = {
        'critical': 10.0,
        'high': 7.5,
        'medium': 5.0,
        'low': 2.5,
        'info': 0.5
    }
    
    if not vulnerabilities:
        return 0.0
    
    total_score = 0.0
    
    for vuln in vulnerabilities:
        severity = vuln.get('severity', 'info')
        confidence = vuln.get('confidence', 0.5)
        weight = weights.get(severity, 1.0)
        
        total_score += weight * confidence
    
    # Normalize to 0-10 scale
    avg_score = total_score / len(vulnerabilities)
    return min(avg_score, 10.0)


def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe filesystem usage."""
    # Remove invalid characters
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # Limit length
    if len(sanitized) > 200:
        name, ext = os.path.splitext(sanitized)
        sanitized = name[:200] + ext
    return sanitized


import os


def get_file_extension(filename: str) -> str:
    """Get file extension."""
    _, ext = os.path.splitext(filename)
    return ext.lower()


def is_binary_content(content: bytes) -> bool:
    """Check if content is binary."""
    textchars = bytearray({7, 8, 9, 10, 12, 13, 27} | set(range(0x20, 0x100)) - {0x7f})
    return bool(content.translate(None, textchars))

