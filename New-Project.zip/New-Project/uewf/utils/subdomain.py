"""
Comprehensive subdomain discovery engine for uEWF.
Combines multiple real-world techniques:
- crt.sh Certificate Transparency logs
- SecurityTrails API
- DNS Bruteforce with common wordlist
- Subfinder external tool
- Active verification (HTTP probing)
"""

import json
import socket
import dns.resolver
import concurrent.futures
from typing import List, Dict, Set, Optional, Callable
from urllib.parse import urlparse
from pathlib import Path
import random
import time

import requests

from ..core.logger import get_logger
from ..core.config import Config
from ..utils.external import get_tool_manager

logger = get_logger(__name__)


# Comprehensive subdomain wordlist (common + security-focused)
COMMON_SUBDOMAINS = [
    # Web services
    'www', 'wwww', 'web', 'webserver', 'website', 'site', 'home', 'index',
    'mail', 'email', 'webmail', 'mail2', 'mail1', 'mx', 'mx1', 'mx2',
    'smtp', 'pop', 'pop3', 'imap', 'exchange', 'owa', 'outlook',
    'autodiscover', 'lyncdiscover', 'lync',
    # DNS / Infrastructure
    'ns1', 'ns2', 'ns3', 'ns4', 'dns', 'dns1', 'dns2',
    'ns', 'nameserver', 'ns0', 'ns01', 'ns02',
    'cpanel', 'whm', 'webmail', 'webdisk', 'cpcalendars', 'cpcontacts',
    'server', 'servidor', 'vps', 'host', 'hosting', 'hostmaster',
    'admin', 'administrator', 'root', 'sysadmin',
    'ftp', 'ssh', 'sftp', 'sftp', 'sftp',
    'api', 'api2', 'api3', 'rest', 'restapi', 'graphql',
    'app', 'app1', 'app2', 'app3', 'myapp',
    'dev', 'develop', 'development', 'developer',
    'test', 'testing', 'tst', 'beta', 'alpha', 'staging', 'stage',
    'demo', 'sandbox', 'lab', 'labs', 'playground',
    # Security/Auth
    'login', 'signin', 'signup', 'register', 'auth', 'oauth', 'sso',
    'secure', 'security', 'vpn', 'portal', 'access',
    'saml', 'idp', 'sso', 'openid',
    'password', 'forgot', 'reset', 'recover',
    # Cloud & CDN
    'cdn', 'static', 'media', 'img', 'images', 'css', 'js', 'assets',
    'static1', 'static2', 'static3',
    'cloud', 'aws', 'azure', 'gcp', 'google', 'amazon',
    's3', 'bucket', 'storage', 'files', 'file',
    # Monitoring & Analytics
    'monitor', 'monitoring', 'grafana', 'prometheus', 'kibana',
    'analytics', 'stats', 'statistics', 'metrics', 'logs', 'logging',
    'splunk', 'elk', 'nagios', 'zabbix',
    'status', 'statuspage', 'uptime', 'health',
    # CI/CD & Development
    'jenkins', 'jira', 'confluence', 'bitbucket', 'gitlab', 'github',
    'git', 'svn', 'repo', 'repos', 'repository', 'code',
    'ci', 'cd', 'build', 'deploy', 'release',
    'sonar', 'sonarqube', 'nexus', 'artifactory',
    'harbor', 'docker', 'k8s', 'kubernetes',
    # Corporate
    'corp', 'corporate', 'intranet', 'internal', 'portal',
    'hr', 'humanresources', 'payroll', 'benefits',
    'finance', 'accounting', 'billing', 'invoice', 'payment',
    'erp', 'crm', 'sales', 'marketing',
    'partner', 'partners', 'partnerportal', 'vendor', 'vendors',
    'supplier', 'suppliers', 'distributor',
    'learning', 'lms', 'training', 'learn', 'academy',
    'wiki', 'knowledge', 'kb', 'knowledgebase',
    'support', 'help', 'helpdesk', 'service', 'services',
    'chat', 'livechat', 'talk', 'discuss', 'forum', 'community',
    'blog', 'news', 'press', 'media', 'events',
    # Remote Access & Communication
    'remote', 'remoteaccess', 'rdp', 'vnc', 'teamviewer',
    'meet', 'zoom', 'teams', 'skype', 'slack', 'discord',
    'phone', 'voip', 'sip', 'telephony',
    'calendar', 'cal', 'schedule',
    'drive', 'docs', 'documents', 'files', 'share',
    # Development
    'phpmyadmin', 'phpmyadmin2', 'pma',
    'phpPgAdmin', 'adminer',
    'webmin', 'usermin',
    'mysql', 'phpmyadmin', 'pgadmin',
    'redis', 'memcache', 'memcached',
    'rabbitmq', 'kafka', 'zookeeper',
    'elasticsearch', 'elastic', 'opensearch',
    'backup', 'backups', 'dump', 'sql', 'db', 'database',
    'logs', 'log', 'debug', 'error', 'trace',
    'test', 'tests', 'tmp', 'temp', 'tempdir',
    'old', 'new', 'bak', 'backup', 'copy', 'backup',
    'swagger', 'api-docs', 'docs-api', 'openapi',
    'graphql', 'graphiql', 'playground',
    'socket', 'websocket', 'ws', 'wss',
    'proxy', 'proxy2', 'gateway', 'gateway2',
    'tunnel', 'ngrok', 'localtunnel',
    'metrics', 'prometheus', 'grafana',
    'health', 'healthcheck', 'ready', 'live',
    'info', 'status', 'version', 'ping',
]


class SubdomainEngine:
    """
    Comprehensive subdomain discovery engine.
    Uses multiple sources and techniques to discover subdomains,
    then actively probes them to verify they are alive.
    """

    def __init__(self, domain: str):
        """
        Initialize subdomain engine for a given domain.
        
        Args:
            domain: The root domain to discover subdomains for (e.g., 'example.com')
        """
        # Clean domain
        domain = domain.lower().strip()
        if domain.startswith(('http://', 'https://')):
            parsed = urlparse(domain)
            domain = parsed.netloc
        if ':' in domain:
            domain = domain.split(':')[0]
        
        self.domain = domain
        self.tool_manager = get_tool_manager()
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (compatible; uEWF-Scanner/1.0; +https://github.com/iprincekumarr/uewf)',
            'Accept': 'application/json,text/html,*/*',
        })
        
        # Configuration
        self.bruteforce_concurrency = 50
        self.http_probe_concurrency = 30
        self.request_timeout = 10
        self.dns_timeout = 5
        
        # Results storage
        self.discovered_subdomains: Set[str] = set()
        self.verified_subdomains: List[Dict] = []
    
    def discover_all(self, sources: List[str] = None, wordlist: List[str] = None) -> List[Dict]:
        """
        Run all subdomain discovery methods and verify active ones.
        
        Args:
            sources: List of sources to use ['crt.sh', 'securitytrails', 'subfinder', 'bruteforce']
                     If None, all available sources are used.
            wordlist: Custom subdomain wordlist for bruteforce. Uses default if None.
        
        Returns:
            List of verified active subdomains with metadata
        """
        if sources is None:
            sources = ['crt.sh', 'securitytrails', 'subfinder', 'assetfinder', 'amass', 'bruteforce']
        
        logger.debug(f"SubdomainEngine initialized for {self.domain}")
        logger.info(f"Sources: {', '.join(sources)}")
        
        discovered = set()
        
        # Phase 1: Discovery from all sources
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(sources)) as executor:
            futures = {}
            
            if 'crt.sh' in sources:
                futures[executor.submit(self._discover_crtsh)] = 'crt.sh'
            
            if 'securitytrails' in sources:
                futures[executor.submit(self._discover_securitytrails)] = 'securitytrails'
            
            if 'subfinder' in sources:
                futures[executor.submit(self._discover_subfinder)] = 'subfinder'
            
            if 'assetfinder' in sources:
                futures[executor.submit(self._discover_assetfinder)] = 'assetfinder'
            
            if 'amass' in sources:
                futures[executor.submit(self._discover_amass)] = 'amass'
            
            if 'bruteforce' in sources:
                futures[executor.submit(self._discover_bruteforce, wordlist)] = 'bruteforce'
            
            for future in concurrent.futures.as_completed(futures):
                source_name = futures[future]
                try:
                    result = future.result()
                    new_subs = set(result) - discovered
                    discovered.update(result)
                    if new_subs:
                        logger.info(f"{source_name}: Discovered {len(result)} subdomains ({len(new_subs)} new)")
                    else:
                        logger.info(f"{source_name}: Discovered {len(result)} subdomains (0 new)")
                except Exception as e:
                    logger.warning(f"{source_name} discovery failed: {e}")
        
        self.discovered_subdomains = discovered
        logger.info(f"Total unique subdomains discovered: {len(discovered)}")
        
        # Phase 2: Active verification (HTTP probing)
        if discovered:
            self.verified_subdomains = self._verify_active(discovered)
            logger.info(f"Active subdomains: {len(self.verified_subdomains)}/{len(discovered)}")
        else:
            self.verified_subdomains = []
        
        return self.verified_subdomains
    
    # ==================== DISCOVERY METHODS ====================
    
    def _discover_crtsh(self) -> Set[str]:
        """
        Discover subdomains using crt.sh Certificate Transparency logs.
        This is the most reliable free source for subdomains.
        """
        subdomains = set()
        
        try:
            # crt.sh API endpoint
            url = f"https://crt.sh/?q=%25.{self.domain}&output=json"
            resp = self.session.get(url, timeout=30)
            
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    for entry in data:
                        name_value = entry.get('name_value', '')
                        # crt.sh returns multiple subdomains separated by newlines
                        for sub in name_value.split('\n'):
                            sub = sub.strip().lower()
                            # Filter to only include subdomains of our target
                            if sub.endswith(f'.{self.domain}') and sub != self.domain:
                                # Remove wildcard entries
                                if not sub.startswith('*.'):
                                    subdomains.add(sub)
                except (json.JSONDecodeError, ValueError) as e:
                    logger.debug(f"crt.sh JSON parse error: {e}")
                    # Fallback: try HTML parsing
                    if resp.text:
                        import re
                        pattern = re.compile(r'<TD[^>]*>([a-zA-Z0-9._-]+\.' + re.escape(self.domain) + r')</TD>')
                        matches = pattern.findall(resp.text)
                        for match in matches:
                            subdomains.add(match.lower())
            else:
                logger.debug(f"crt.sh returned status {resp.status_code}")
        
        except requests.exceptions.Timeout:
            logger.warning("crt.sh API timed out")
        except Exception as e:
            logger.debug(f"crt.sh discovery failed: {e}")
        
        return subdomains
    
    def _discover_securitytrails(self) -> Set[str]:
        """
        Discover subdomains using SecurityTrails API.
        Requires API key from config (optional - uses crt.sh as fallback if no key).
        """
        subdomains = set()
        
        api_key = Config.get('securitytrails_api_key', '')
        
        if not api_key:
            logger.debug("No SecurityTrails API key configured, skipping")
            return subdomains
        
        try:
            url = f"https://api.securitytrails.com/v1/domain/{self.domain}/subdomains"
            headers = {
                'APIKEY': api_key,
                'Accept': 'application/json',
            }
            
            resp = self.session.get(url, headers=headers, timeout=30)
            
            if resp.status_code == 200:
                data = resp.json()
                subs = data.get('subdomains', [])
                for sub in subs:
                    full = f"{sub}.{self.domain}".lower()
                    subdomains.add(full)
            elif resp.status_code == 401:
                logger.warning("Invalid SecurityTrails API key")
            else:
                logger.debug(f"SecurityTrails returned status {resp.status_code}")
        
        except requests.exceptions.Timeout:
            logger.warning("SecurityTrails API timed out")
        except Exception as e:
            logger.debug(f"SecurityTrails discovery failed: {e}")
        
        return subdomains
    
    def _discover_subfinder(self) -> Set[str]:
        """
        Discover subdomains using external subfinder tool.
        """
        subdomains = set()
        
        if not self.tool_manager.is_tool_installed('subfinder'):
            logger.info("subfinder not installed, skipping")
            return subdomains
        
        try:
            # Try JSON output for richer data
            output = self.tool_manager.run_tool('subfinder', [
                '-d', self.domain,
                '-silent',
                '-all',  # Use all sources
            ], timeout=180)
            
            if output:
                for line in output:
                    sub = line.strip().lower()
                    if sub and sub.endswith(f'.{self.domain}'):
                        subdomains.add(sub)
        
        except Exception as e:
            logger.debug(f"subfinder discovery failed: {e}")
        
        return subdomains
    
    def _discover_assetfinder(self) -> Set[str]:
        """
        Discover subdomains using assetfinder (by TomNomNom).
        Uses various sources like crt.sh, DNS, Facebook, etc.
        """
        subdomains = set()
        
        if not self.tool_manager.is_tool_installed('assetfinder'):
            return subdomains
        
        try:
            output = self.tool_manager.run_assetfinder(self.domain)
            if output:
                for sub in output:
                    sub = sub.strip().lower()
                    if sub and sub.endswith(f'.{self.domain}') and sub != f'.{self.domain}':
                        # Remove leading dot if present
                        if sub.startswith('.'):
                            sub = sub[1:]
                        subdomains.add(sub)
        except Exception as e:
            logger.debug(f"assetfinder discovery failed: {e}")
        
        return subdomains
    
    def _discover_amass(self) -> Set[str]:
        """
        Discover subdomains using amass (OWASP).
        Runs in passive mode for speed and safety.
        """
        subdomains = set()
        
        if not self.tool_manager.is_tool_installed('amass'):
            return subdomains
        
        try:
            output = self.tool_manager.run_amass(self.domain, passive=True)
            if output:
                for sub in output:
                    sub = sub.strip().lower()
                    if sub and sub.endswith(f'.{self.domain}') and sub != self.domain:
                        if sub.startswith('.'):
                            sub = sub[1:]
                        subdomains.add(sub)
        except Exception as e:
            logger.debug(f"amass discovery failed: {e}")
        
        return subdomains
    
    def _discover_bruteforce(self, wordlist: List[str] = None) -> Set[str]:
        """
        DNS bruteforce subdomain discovery.
        Resolves common subdomain names via DNS A/AAAA records.
        """
        subdomains = set()
        
        if wordlist is None:
            wordlist = COMMON_SUBDOMAINS
        
        def check_subdomain(sub: str) -> Optional[str]:
            """Check if a subdomain resolves via DNS."""
            full_domain = f"{sub}.{self.domain}".lower()
            try:
                # Try A record
                answers = dns.resolver.resolve(full_domain, 'A', lifetime=self.dns_timeout)
                if answers:
                    return full_domain
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, 
                    dns.resolver.NoNameservers, dns.exception.Timeout):
                pass
            except Exception:
                pass
            
            # Try CNAME
            try:
                answers = dns.resolver.resolve(full_domain, 'CNAME', lifetime=self.dns_timeout)
                if answers:
                    return full_domain
            except Exception:
                pass
            
            return None
        
        # Run bruteforce with concurrency
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.bruteforce_concurrency) as executor:
            futures = {executor.submit(check_subdomain, sub): sub for sub in wordlist}
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    subdomains.add(result)
        
        return subdomains
    
    # ==================== ACTIVE VERIFICATION ====================
    
    def _verify_active(self, subdomains: Set[str]) -> List[Dict]:
        """
        Verify which subdomains are actually alive by sending HTTP requests.
        Returns detailed metadata for each active subdomain.
        """
        logger.info(f"Probing {len(subdomains)} potential subdomains for HTTP responsiveness")
        
        verified = []
        processed = 0
        
        # First try httpx if available (faster, more detailed)
        if self.tool_manager.is_tool_installed('httpx'):
            logger.info("Using httpx for subdomain probing")
            urls = [f"https://{s}" for s in subdomains]
            httpx_results = self.tool_manager.run_httpx(urls)
            
            seen_hosts = set()
            for result in httpx_results:
                host = result.get('host', '')
                if host and host not in seen_hosts:
                    seen_hosts.add(host)
                    verified.append({
                        'subdomain': host,
                        'url': f"https://{host}",
                        'status_code': result.get('status_code', 0),
                        'title': result.get('title', ''),
                        'content_length': result.get('content_length', 0),
                        'technologies': result.get('tech', []) or [],
                        'ip': result.get('ip', ''),
                        'webserver': result.get('webserver', ''),
                        'verified_by': 'httpx',
                        'alive': True,
                    })
            
            # Add any subdomains not checked by httpx (that failed)
            checked_hosts = {v['subdomain'] for v in verified}
            unchecked = [s for s in subdomains if s not in checked_hosts]
            
            if unchecked:
                logger.info(f"Probing {len(unchecked)} subdomains with direct HTTP requests")
                for sub in unchecked:
                    result = self._probe_subdomain_http(sub)
                    if result:
                        verified.append(result)
        
        else:
            logger.info("httpx not available, using direct HTTP probing")
            # Direct HTTP probing
            sub_list = list(subdomains)
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.http_probe_concurrency) as executor:
                futures = {executor.submit(self._probe_subdomain_http, sub): sub for sub in sub_list}
                
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    if result:
                        verified.append(result)
                    processed += 1
                    if processed % 50 == 0:
                        logger.info(f"Probed {processed}/{len(sub_list)} subdomains")
        
        # Sort by status code (200 first, then others)
        verified.sort(key=lambda x: (0 if x.get('status_code') == 200 else 1, x.get('subdomain', '')))
        
        return verified
    
    def _probe_subdomain_http(self, subdomain: str) -> Optional[Dict]:
        """
        Probe a single subdomain via HTTP/HTTPS to check if it's alive.
        """
        result_data = {
            'subdomain': subdomain,
            'url': '',
            'status_code': 0,
            'title': '',
            'content_length': 0,
            'technologies': [],
            'ip': '',
            'webserver': '',
            'verified_by': 'direct',
            'alive': False,
        }
        
        # Try to resolve IP
        try:
            ip = socket.gethostbyname(subdomain)
            result_data['ip'] = ip
        except socket.gaierror:
            return None
        
        # Try HTTPS first, then HTTP
        for protocol in ['https', 'http']:
            url = f"{protocol}://{subdomain}"
            try:
                resp = self.session.get(
                    url,
                    timeout=self.request_timeout,
                    allow_redirects=True,
                    verify=False,
                )
                
                result_data['url'] = url
                result_data['status_code'] = resp.status_code
                result_data['content_length'] = len(resp.content)
                result_data['webserver'] = resp.headers.get('Server', '')
                result_data['alive'] = True
                
                # Extract title from HTML
                if 'text/html' in resp.headers.get('Content-Type', ''):
                    import re
                    title_match = re.search(r'<title[^>]*>(.*?)</title>', resp.text, re.IGNORECASE | re.DOTALL)
                    if title_match:
                        title = title_match.group(1).strip()
                        result_data['title'] = title[:200]  # Limit title length
                
                # Basic technology detection from headers
                techs = []
                if resp.headers.get('X-Powered-By'):
                    techs.append(resp.headers['X-Powered-By'])
                if resp.headers.get('Set-Cookie', ''):
                    cookie = resp.headers['Set-Cookie']
                    if 'PHPSESSID' in cookie:
                        techs.append('PHP')
                    if 'JSESSIONID' in cookie:
                        techs.append('Java')
                    if 'ASPSESSIONID' in cookie or 'ASP.NET' in cookie:
                        techs.append('ASP.NET')
                result_data['technologies'] = list(set(techs))
                
                return result_data
            
            except requests.exceptions.SSLError:
                # SSL error means server is there but SSL issue - still alive
                result_data['url'] = url
                result_data['status_code'] = 0
                result_data['alive'] = True
                result_data['title'] = '[SSL Error]'
                return result_data
            
            except requests.exceptions.ConnectionError:
                continue  # Try next protocol
            
            except requests.exceptions.Timeout:
                continue  # Try next protocol
            
            except Exception as e:
                logger.debug(f"Probe failed for {url}: {e}")
                continue
        
        # Neither HTTP nor HTTPS worked
        return None
    
    def get_subdomains_by_status(self, status_code: int = None) -> List[Dict]:
        """Get verified subdomains filtered by HTTP status code."""
        if status_code:
            return [s for s in self.verified_subdomains if s.get('status_code') == status_code]
        return self.verified_subdomains
    
    def get_active_subdomains(self) -> List[str]:
        """Get list of active subdomain hostnames."""
        return [s['subdomain'] for s in self.verified_subdomains if s.get('alive')]
    
    def get_active_urls(self) -> List[str]:
        """Get list of active subdomain URLs (https://sub.domain.com)."""
        return [s['url'] for s in self.verified_subdomains if s.get('alive') and s.get('url')]
    
    def get_summary(self) -> Dict:
        """Get summary of subdomain discovery results."""
        status_counts = {}
        for sub in self.verified_subdomains:
            code = sub.get('status_code', 0)
            category = f"{code}" if code else 'no_http'
            status_counts[category] = status_counts.get(category, 0) + 1
        
        return {
            'domain': self.domain,
            'total_discovered': len(self.discovered_subdomains),
            'total_active': len(self.verified_subdomains),
            'alive_count': sum(1 for s in self.verified_subdomains if s.get('alive')),
            'status_codes': status_counts,
            'sources_used': ['crt.sh', 'securitytrails', 'subfinder', 'assetfinder', 'amass', 'bruteforce'],
        }


def discover_subdomains(domain: str, sources: List[str] = None, wordlist: List[str] = None) -> List[Dict]:
    """
    Convenience function to discover and verify subdomains for a domain.
    
    Args:
        domain: Root domain (e.g., 'example.com')
        sources: Discovery sources to use
        wordlist: Custom wordlist for bruteforce
    
    Returns:
        List of verified active subdomains with metadata
    """
    engine = SubdomainEngine(domain)
    return engine.discover_all(sources=sources, wordlist=wordlist)
