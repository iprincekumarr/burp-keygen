"""
External tool management for uEWF.
Manages integration with popular security tools like waybackurls, gau, katana, etc.
"""

import subprocess
import shutil
import json
from typing import List, Dict, Optional, Set
from pathlib import Path
import tempfile
import os
import urllib.parse

from ..core.logger import get_logger

logger = get_logger(__name__)


# Tool definitions: name -> {binary, install_hint, max_args}
TOOLS = {
    'waybackurls': {
        'binary': 'waybackurls',
        'description': 'Fetch URLs from Wayback Machine',
        'install_hint': 'go install github.com/tomnomnom/waybackurls@latest',
    },
    'gau': {
        'binary': 'gau',
        'description': 'Get All URLs from multiple sources',
        'install_hint': 'go install github.com/lc/gau/v2/cmd/gau@latest',
    },
    'katana': {
        'binary': 'katana',
        'description': 'Web crawler by ProjectDiscovery',
        'install_hint': 'go install github.com/projectdiscovery/katana/cmd/katana@latest',
    },
    'httpx': {
        'binary': 'httpx',
        'description': 'HTTP probing tool by ProjectDiscovery',
        'install_hint': 'go install github.com/projectdiscovery/httpx/cmd/httpx@latest',
    },
    'subfinder': {
        'binary': 'subfinder',
        'description': 'Subdomain discovery tool (ProjectDiscovery)',
        'install_hint': 'go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest',
    },
    'assetfinder': {
        'binary': 'assetfinder',
        'description': 'Subdomain discovery (TomNomNom) - finds domains from various sources',
        'install_hint': 'go install github.com/tomnomnom/assetfinder@latest',
    },
    'amass': {
        'binary': 'amass',
        'description': 'Advanced subdomain enumeration (OWASP)',
        'install_hint': 'go install github.com/owasp-amass/amass/v4/...@master',
    },
    'nuclei': {
        'binary': 'nuclei',
        'description': 'Fast vulnerability scanner (ProjectDiscovery)',
        'install_hint': 'go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest',
    },
    'httprobe': {
        'binary': 'httprobe',
        'description': 'Probe for working HTTP/HTTPS servers (TomNomNom)',
        'install_hint': 'go install github.com/tomnomnom/httprobe@latest',
    },
    'dalfox': {
        'binary': 'dalfox',
        'description': 'XSS scanning tool',
        'install_hint': 'go install github.com/hahwul/dalfox/v2@latest',
    },
    'anew': {
        'binary': 'anew',
        'description': 'Append unique lines to file',
        'install_hint': 'go install github.com/tomnomnom/anew@latest',
    },
    'ffuf': {
        'binary': 'ffuf',
        'description': 'Fast web fuzzer for directory/parameter discovery',
        'install_hint': 'go install github.com/ffuf/ffuf/v2@latest',
    },
    'gobuster': {
        'binary': 'gobuster',
        'description': 'Directory/file & DNS subdomain brute-forcer',
        'install_hint': 'go install github.com/OJ/gobuster/v3@latest',
    },
}


class ExternalToolManager:
    """Manages integration with external security tools."""
    
    def __init__(self):
        self._cache = {}
    
    def is_tool_installed(self, tool_name: str) -> bool:
        """Check if an external tool is installed."""
        if tool_name not in TOOLS:
            return False
        
        if tool_name in self._cache:
            return self._cache[tool_name]
        
        binary = TOOLS[tool_name]['binary']
        result = shutil.which(binary) is not None
        self._cache[tool_name] = result
        return result
    
    def get_installed_tools(self) -> List[str]:
        """Get list of installed external tools."""
        return [name for name in TOOLS if self.is_tool_installed(name)]
    
    def install_tool(self, tool_name: str) -> bool:
        """
        Automatically install an external tool using go install.
        
        Args:
            tool_name: Name of the tool to install
            
        Returns:
            True if installation succeeded, False otherwise
        """
        if tool_name not in TOOLS:
            logger.error(f"Unknown tool: {tool_name}")
            return False
        
        if self.is_tool_installed(tool_name):
            return True
        
        install_hint = TOOLS[tool_name]['install_hint']
        logger.info(f"Auto-installing {tool_name}...")
        logger.info(f"  {install_hint}")
        
        try:
            # Check if Go is installed
            go_check = subprocess.run(['go', 'version'], capture_output=True, text=True, timeout=10)
            if go_check.returncode != 0:
                logger.error("Go is not installed. Cannot auto-install tools.")
                logger.info("Install Go from https://go.dev/dl/ then rerun scan.")
                return False
            
            # Run the go install command
            cmd = install_hint.split()
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes for installation
            )
            
            if result.returncode == 0:
                self._cache[tool_name] = True
                logger.info(f"✅ Successfully installed {tool_name}")
                return True
            else:
                error_msg = result.stderr[:300] if result.stderr else "Unknown error"
                logger.error(f"Failed to install {tool_name}: {error_msg}")
                self._cache[tool_name] = False
                return False
                
        except subprocess.TimeoutExpired:
            logger.error(f"Installation of {tool_name} timed out")
            return False
        except FileNotFoundError:
            logger.error("Go binary not found in PATH")
            return False
        except Exception as e:
            logger.error(f"Error installing {tool_name}: {e}")
            return False
    
    def run_tool(self, tool_name: str, args: List[str], timeout: int = 60) -> Optional[List[str]]:
        """
        Run an external tool and return its output lines.
        Automatically installs the tool if not present.
        
        Args:
            tool_name: Name of the tool to run
            args: Command-line arguments
            timeout: Timeout in seconds
            
        Returns:
            List of output lines, or None if failed
        """
        if not self.is_tool_installed(tool_name):
            logger.info(f"Tool '{tool_name}' not found. Attempting auto-install...")
            if not self.install_tool(tool_name):
                logger.warning(f"Could not install '{tool_name}'. Some features may be limited.")
                return None
        
        binary = TOOLS[tool_name]['binary']
        cmd = [binary] + args
        
        try:
            logger.debug(f"Running: {' '.join(cmd)}")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                errors='replace'
            )
            
            if result.returncode != 0:
                logger.warning(f"Tool '{tool_name}' exited with code {result.returncode}: {result.stderr[:200]}")
                return None
            
            output = result.stdout.strip().split('\n') if result.stdout.strip() else []
            logger.debug(f"Tool '{tool_name}' returned {len(output)} lines")
            return output
            
        except subprocess.TimeoutExpired:
            logger.warning(f"Tool '{tool_name}' timed out after {timeout}s")
            return None
        except FileNotFoundError:
            self._cache[tool_name] = False
            logger.error(f"Tool '{tool_name}' binary not found")
            return None
        except Exception as e:
            logger.error(f"Error running '{tool_name}': {e}")
            return None
    
    def run_waybackurls(self, domain: str) -> List[str]:
        """Run waybackurls on a domain."""
        output = self.run_tool('waybackurls', [domain], timeout=120)
        return output or []
    
    def run_gau(self, domain: str) -> List[str]:
        """Run gau (Get All URLs) on a domain."""
        output = self.run_tool('gau', ['--o', '/dev/stdout', domain], timeout=120)
        return output or []
    
    def run_katana(self, target_url: str, depth: int = 3) -> List[str]:
        """Run katana crawler on a target URL."""
        output = self.run_tool('katana', [
            '-u', target_url,
            '-d', str(depth),
            '-o', '/dev/stdout',
            '-jc',  # crawl JS files
            '-kf', 'robotstxt,sitemapxml'  # known files
        ], timeout=180)
        return output or []
    
    def run_httpx(self, urls: List[str]) -> List[Dict]:
        """Run httpx to probe URLs and get status codes."""
        if not urls:
            return []
        
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
                f.write('\n'.join(urls))
                temp_path = f.name
            
            output = self.run_tool('httpx', [
                '-l', temp_path,
                '-o', '/dev/stdout',
                '-json',
                '-silent',
                '-status-code',
                '-title',
                '-tech-detect',
                '-follow-redirects',
            ], timeout=180)
            
            results = []
            if output:
                for line in output:
                    try:
                        data = json.loads(line)
                        results.append(data)
                    except json.JSONDecodeError:
                        pass
            
            return results
        finally:
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def run_subfinder(self, domain: str, use_all_sources: bool = True) -> List[str]:
        """
        Run subfinder for subdomain discovery.
        
        Args:
            domain: Target domain
            use_all_sources: Whether to use all available sources
        
        Returns:
            List of discovered subdomains
        """
        args = ['-d', domain, '-silent']
        if use_all_sources:
            args.append('-all')
        output = self.run_tool('subfinder', args, timeout=180)
        return output or []
    
    def run_assetfinder(self, domain: str) -> List[str]:
        """
        Run assetfinder (by TomNomNom) for subdomain discovery.
        Finds subdomains from various sources like crt.sh, DNS, etc.
        
        Returns:
            List of discovered subdomains
        """
        output = self.run_tool('assetfinder', [domain], timeout=120)
        return output or []
    
    def run_amass(self, domain: str, passive: bool = True) -> List[str]:
        """
        Run amass (OWASP) for advanced subdomain enumeration.
        
        Args:
            domain: Target domain
            passive: If True, use passive mode only (no DNS brute-force)
        
        Returns:
            List of discovered subdomains
        """
        args = ['enum', '-d', domain, '-json', '/dev/stdout', '-o', '/dev/stdout', '-nocolor']
        if passive:
            args.append('-passive')
        output = self.run_tool('amass', args, timeout=300)
        
        # Parse JSON lines from amass output
        subdomains = set()
        if output:
            for line in output:
                try:
                    data = json.loads(line)
                    name = data.get('name', '')
                    if name:
                        subdomains.add(name.lower())
                except json.JSONDecodeError:
                    # Fallback: treat line as hostname
                    line = line.strip().lower()
                    if line and '.' in line:
                        subdomains.add(line)
        
        return list(subdomains)
    
    def run_nuclei(self, target_url: str, severity: str = None) -> List[Dict]:
        """
        Run nuclei vulnerability scanner on a target.
        
        Args:
            target_url: Target URL to scan
            severity: Filter by severity (critical, high, medium, low, info)
        
        Returns:
            List of findings with template, severity, etc.
        """
        args = ['-u', target_url, '-json', '-silent', '-no-color']
        if severity:
            args.extend(['-severity', severity])
        output = self.run_tool('nuclei', args, timeout=300)
        
        results = []
        if output:
            for line in output:
                try:
                    data = json.loads(line)
                    results.append(data)
                except json.JSONDecodeError:
                    pass
        return results
    
    def run_httprobe(self, domains: List[str]) -> List[Dict]:
        """
        Run httprobe (TomNomNom) to check which domains are alive.
        
        Args:
            domains: List of domain/host names to probe
        
        Returns:
            List of {host, url, alive} dicts
        """
        import tempfile
        import os
        
        temp_path = None
        results = []
        try:
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
                f.write('\n'.join(domains))
                temp_path = f.name
            
            output = self.run_tool('httprobe', [
                '-c', '50',
                '-t', '3000',
                temp_path
            ], timeout=180)
            
            if output:
                for line in output:
                    line = line.strip()
                    if line:
                        from urllib.parse import urlparse
                        parsed = urlparse(line)
                        results.append({
                            'host': parsed.netloc or line,
                            'url': line,
                            'alive': True
                        })
        finally:
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)
        
        return results
    
    def run_subfinder_json(self, domain: str) -> List[Dict]:
        """
        Run subfinder with JSON output for richer data.
        
        Returns:
            List of dicts with subdomain, source, etc.
        """
        output = self.run_tool('subfinder', [
            '-d', domain,
            '-all',
            '-json',
            '-silent',
        ], timeout=180)
        
        results = []
        if output:
            for line in output:
                try:
                    data = json.loads(line)
                    results.append(data)
                except json.JSONDecodeError:
                    # Fallback: treat as plain subdomain
                    if line.strip():
                        results.append({
                            'host': line.strip(),
                            'source': 'subfinder',
                        })
        
        return results
    
    def run_securitytrails(self, domain: str) -> Optional[List[str]]:
        """
        Query SecurityTrails API for subdomains.
        Requires SECURITYTRAILS_API_KEY environment variable or config.
        
        Returns:
            List of subdomains or None if API key not configured
        """
        api_key = os.environ.get('SECURITYTRAILS_API_KEY') or ''
        if not api_key:
            from ..core.config import Config
            api_key = Config.get('securitytrails_api_key', '')
        
        if not api_key:
            logger.debug("No SecurityTrails API key configured")
            return None
        
        try:
            import requests
            url = f"https://api.securitytrails.com/v1/domain/{domain}/subdomains"
            headers = {'APIKEY': api_key, 'Accept': 'application/json'}
            resp = requests.get(url, headers=headers, timeout=30)
            
            if resp.status_code == 200:
                data = resp.json()
                subs = data.get('subdomains', [])
                return [f"{sub}.{domain}" for sub in subs]
            elif resp.status_code == 401:
                logger.warning("Invalid SecurityTrails API key")
            else:
                logger.debug(f"SecurityTrails returned {resp.status_code}")
        except Exception as e:
            logger.debug(f"SecurityTrails API error: {e}")
        
        return None
    
    def run_dalfox(self, target_url: str, param: str = None) -> List[Dict]:
        """Run dalfox for XSS scanning."""
        args = ['url', target_url, '--silence', '--no-color', '--json']
        if param:
            args.extend(['--param', param])
        
        output = self.run_tool('dalfox', args, timeout=180)
        
        results = []
        if output:
            for line in output:
                try:
                    data = json.loads(line)
                    results.append(data)
                except json.JSONDecodeError:
                    pass
        
        return results

    def discover_wayback_gau(self, domain: str) -> List[Dict]:
        """
        Discover URLs using Wayback Machine + GAU (if available).
        Falls back to Archive.org API if tools not installed.
        
        Returns:
            List of {url, parameters, method} dicts
        """
        discovered = set()
        endpoints = []
        
        # Method 1: Try waybackurls tool
        if self.is_tool_installed('waybackurls'):
            logger.info("Using waybackurls for URL discovery")
            urls = self.run_waybackurls(domain)
            for url in urls:
                if url and url.startswith(('http://', 'https://')):
                    discovered.add(url)
        
        # Method 2: Try gau tool
        if self.is_tool_installed('gau'):
            logger.info("Using gau for URL discovery")
            urls = self.run_gau(domain)
            for url in urls:
                if url and url.startswith(('http://', 'https://')):
                    discovered.add(url)
        
        # Method 3: Fallback to Archive.org API
        if not discovered:
            logger.info("Falling back to Archive.org API for URL discovery")
            try:
                import requests
                api_url = f"https://web.archive.org/cdx/search/cdx?url={domain}/*&output=json&fl=original&collapse=urlkey"
                resp = requests.get(api_url, timeout=30)
                if resp.status_code == 200:
                    data = resp.json()
                    for row in data[1:]:  # Skip header
                        if row and len(row) > 0:
                            url = row[0]
                            if url.startswith(('http://', 'https://')):
                                discovered.add(url)
            except Exception as e:
                logger.debug(f"Archive.org API failed: {e}")
        
        # Parse discovered URLs into endpoint format
        for url in discovered:
            parsed = urllib.parse.urlparse(url)
            query_params = urllib.parse.parse_qs(parsed.query)
            param_names = list(query_params.keys())
            
            endpoints.append({
                'url': url.split('?')[0],
                'parameters': param_names,
                'method': 'GET',
                'full_url': url,
            })
        
        logger.info(f"Discovered {len(discovered)} URLs from Wayback/GAU")
        return endpoints
    
    def discover_katana(self, target_url: str, depth: int = 3) -> List[Dict]:
        """
        Discover endpoints using katana crawler (if available).
        
        Returns:
            List of {url, parameters, method} dicts
        """
        if not self.is_tool_installed('katana'):
            logger.info("Katana not installed. Skipping JS/spa crawling.")
            return []
        
        logger.info("Using katana for deep crawling")
        urls = self.run_katana(target_url, depth)
        
        endpoints = []
        seen = set()
        
        for url in urls:
            if url and url.startswith(('http://', 'https://')):
                parsed = urllib.parse.urlparse(url)
                base_url = url.split('?')[0]
                
                if base_url in seen:
                    continue
                seen.add(base_url)
                
                query_params = urllib.parse.parse_qs(parsed.query)
                param_names = list(query_params.keys())
                
                endpoints.append({
                    'url': base_url,
                    'parameters': param_names,
                    'method': 'GET',
                    'full_url': url,
                })
        
        logger.info(f"Katana discovered {len(endpoints)} unique endpoints")
        return endpoints


# Singleton
_tool_manager = None

def get_tool_manager() -> ExternalToolManager:
    """Get the global ExternalToolManager instance."""
    global _tool_manager
    if _tool_manager is None:
        _tool_manager = ExternalToolManager()
    return _tool_manager
