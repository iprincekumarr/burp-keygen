"""
Main entry point for uEWF framework.
"""

import sys
import os

def main():
    """Main entry point."""
    # Add current directory to path
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("Error: uEWF requires Python 3.8 or higher")
        sys.exit(1)
    
    try:
        from uewf.cli import cli
        cli()
    except KeyboardInterrupt:
        print("\n\n[!] Scan interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n[!] Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

