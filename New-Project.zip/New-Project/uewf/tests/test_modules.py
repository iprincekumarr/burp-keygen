"""
Test suite for uEWF modules.
"""

import unittest
import json
from pathlib import Path
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from uewf.core.config import Config
from uewf.core.safeties import SafetyManager
from uewf.core.modules import ModuleManager
from uewf.utils.payloads import PayloadManager
from uewf.utils.helpers import normalize_url, is_valid_url, extract_domain


class TestConfig(unittest.TestCase):
    """Test configuration management."""
    
    def setUp(self):
        Config.initialize()
    
    def test_default_config(self):
        """Test default configuration values."""
        self.assertIsNotNone(Config.get('version'))
        self.assertTrue(Config.get('safe_mode'))
        self.assertEqual(Config.get('timeout'), 30)
    
    def test_set_and_get(self):
        """Test setting and getting configuration values."""
        Config.set('test_key', 'test_value')
        self.assertEqual(Config.get('test_key'), 'test_value')
    
    def test_nested_config(self):
        """Test nested configuration access."""
        Config.set('nested.key', 'nested_value')
        self.assertEqual(Config.get('nested.key'), 'nested_value')


class TestSafety(unittest.TestCase):
    """Test safety manager."""
    
    def setUp(self):
        self.safety = SafetyManager()
    
    def test_blocked_domains(self):
        """Test blocked domain detection."""
        self.assertFalse(self.safety.validate_target('http://google.com'))
        self.assertFalse(self.safety.validate_target('http://facebook.com'))
        self.assertFalse(self.safety.validate_target('http://gov.example.gov'))
    
    def test_payload_validation(self):
        """Test payload safety validation."""
        is_safe, reason = self.safety.validate_payload("' OR '1'='1", 'sqli')
        self.assertTrue(is_safe)
        
        is_safe, reason = self.safety.validate_payload("DROP TABLE users", 'sqli')
        self.assertFalse(is_safe)


class TestHelpers(unittest.TestCase):
    """Test helper utilities."""
    
    def test_normalize_url(self):
        """Test URL normalization."""
        url = normalize_url('example.com')
        self.assertTrue(url.startswith('https://'))
        self.assertIn('example.com', url)
    
    def test_is_valid_url(self):
        """Test URL validation."""
        self.assertTrue(is_valid_url('https://example.com'))
        self.assertFalse(is_valid_url(''))
        self.assertFalse(is_valid_url('not-a-url'))
    
    def test_extract_domain(self):
        """Test domain extraction."""
        domain = extract_domain('https://www.example.com/path?query=value')
        self.assertEqual(domain, 'www.example.com')


class TestPayloads(unittest.TestCase):
    """Test payload management."""
    
    def setUp(self):
        self.pm = PayloadManager()
    
    def test_payload_loading(self):
        """Test payload loading."""
        sqli_payloads = self.pm.get_payloads('sqli')
        self.assertTrue(len(sqli_payloads) > 0)
        
        xss_payloads = self.pm.get_payloads('xss')
        self.assertTrue(len(xss_payloads) > 0)
    
    def test_payload_count(self):
        """Test payload count."""
        total = self.pm.get_payload_count()
        self.assertTrue(total > 0)
    
    def test_search_payloads(self):
        """Test payload search."""
        results = self.pm.search_payloads('script')
        self.assertTrue(len(results) > 0)


class TestModuleManager(unittest.TestCase):
    """Test module management."""
    
    def test_module_registration(self):
        """Test module registration."""
        modules = ModuleManager.get_modules()
        self.assertTrue(len(modules) > 0)
        
        module_names = ModuleManager.get_module_names()
        self.assertIn('sqli', module_names)
        self.assertIn('xss', module_names)
        self.assertIn('recon', module_names)
    
    def test_module_info(self):
        """Test module information retrieval."""
        info = ModuleManager.get_module_info('sqli')
        self.assertIsNotNone(info)
        self.assertEqual(info['name'], 'sqli')
        
        info = ModuleManager.get_module_info('nonexistent')
        self.assertIsNone(info)


class TestWAFDetector(unittest.TestCase):
    """Test WAF detection."""
    
    def test_waf_detection_initialization(self):
        """Test WAF detector initialization."""
        from uewf.utils.waf_detector import WAFDetector
        detector = WAFDetector()
        self.assertIsNotNone(detector)
        self.assertTrue(hasattr(detector, 'WAF_SIGNATURES'))
    
    def test_waf_signatures(self):
        """Test WAF signature definitions."""
        from uewf.utils.waf_detector import WAFDetector
        detector = WAFDetector()
        self.assertIn('Cloudflare', detector.WAF_SIGNATURES)
        self.assertIn('ModSecurity', detector.WAF_SIGNATURES)
        self.assertIn('AWS WAF', detector.WAF_SIGNATURES)


class TestDatabase(unittest.TestCase):
    """Test database operations."""
    
    def setUp(self):
        Config.initialize()
        from uewf.core.database import Database
        self.db = Database()
        self.db.initialize()
    
    def test_create_scan(self):
        """Test scan creation."""
        scan_id = self.db.create_scan('http://test.com', ['sqli', 'xss'], {'safe_mode': True})
        self.assertIsNotNone(scan_id)
        self.assertTrue(scan_id > 0)
    
    def test_add_vulnerability(self):
        """Test vulnerability addition."""
        scan_id = self.db.create_scan('http://test.com', ['all'])
        vuln_id = self.db.add_vulnerability(scan_id, {
            'type': 'Test SQLi',
            'severity': 'high',
            'url': 'http://test.com/page?id=1',
            'parameter': 'id',
            'description': 'Test vulnerability',
            'evidence': 'Test evidence',
            'confidence': 0.8
        })
        self.assertIsNotNone(vuln_id)
        self.assertTrue(vuln_id > 0)
    
    def test_get_vulnerabilities(self):
        """Test vulnerability retrieval."""
        scan_id = self.db.create_scan('http://test.com', ['all'])
        self.db.add_vulnerability(scan_id, {
            'type': 'Test XSS',
            'severity': 'medium',
            'url': 'http://test.com/page',
            'description': 'Test XSS vulnerability'
        })
        
        vulns = self.db.get_vulnerabilities(scan_id=scan_id)
        self.assertEqual(len(vulns), 1)
        self.assertEqual(vulns[0]['type'], 'Test XSS')
    
    def test_get_stats(self):
        """Test database statistics."""
        stats = self.db.get_stats()
        self.assertIn('scans', stats)
        self.assertIn('vulnerabilities', stats)
        self.assertIn('targets', stats)


class TestExport(unittest.TestCase):
    """Test export functionality."""
    
    def setUp(self):
        self.test_data = {
            'target': 'http://test.com',
            'vulnerabilities': [
                {
                    'type': 'SQL Injection',
                    'severity': 'high',
                    'url': 'http://test.com/page?id=1',
                    'description': 'Test SQLi'
                }
            ]
        }
    
    def test_json_export(self):
        """Test JSON export."""
        from uewf.utils.export import save_results
        
        output_path = '/tmp/test_uewf_export'
        result_path = save_results(self.test_data, output_path, 'json')
        
        self.assertTrue(Path(result_path).exists())
        
        with open(result_path) as f:
            data = json.load(f)
            self.assertEqual(data['target'], self.test_data['target'])
        
        # Cleanup
        Path(result_path).unlink()
    
    def test_csv_export(self):
        """Test CSV export."""
        from uewf.utils.export import save_results
        
        output_path = '/tmp/test_uewf_export'
        result_path = save_results(self.test_data, output_path, 'csv')
        
        self.assertTrue(Path(result_path).exists())
        
        # Cleanup
        Path(result_path).unlink()


if __name__ == '__main__':
    unittest.main()

