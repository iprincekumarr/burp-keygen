"""
Reconnaissance module for uEWF.
Gathers information about targets including subdomains, technologies, and endpoints.
"""

import re
import json
import dns.resolver
import socket
from typing import List, Dict, Optional, Set
from urllib.parse import urlparse, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup
from datetime import datetime

from ..core.modules import BaseModule, ModuleManager
from ..core.logger import get_logger

logger = get_logger(__name__)


class Reconnaissance(BaseModule):
    """Information gathering and reconnaissance module."""
    
    name = "recon"
    description = "Target reconnaissance and information gathering"
    version = "1.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = [
        "DNS Enumeration",
        "Subdomain Discovery",
        "Technology Fingerprinting",
        "Endpoint Discovery",
        "Port Scanning",
        "WHOIS Lookup"
    ]
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self.target = self.config.get('target', '')
        self.session = None
        self.results = {
            'urls': [],
            'subdomains': [],
            'parameters': [],
            'technologies': {},
            'endpoints': [],
            'dns_records': {},
            'whois': None,
            'open_ports': []
        }
    
    def test(self, url: str, parameters: List = None, method: str = 'GET', session=None) -> List[Dict]:
        """Run reconnaissance (returns vulnerability context for compatibility)."""
        self.session = session or requests.Session()
        self.target = url
        
        logger.info(f"Starting reconnaissance on {url}")
        
        self._gather_info()
        self._discover_endpoints()
        self._fingerprint_technologies()
        
        # Return recon results as informational findings
        vulns = []
        if self.results.get('technologies'):
            vulns.append({
                'type': 'Information Disclosure',
                'severity': 'info',
                'url': url,
                'description': f"Technologies detected: {json.dumps(self.results['technologies'])}",
                'confidence': 1.0
            })
        
        if len(self.results.get('endpoints', [])) > 10:
            vulns.append({
                'type': 'Attack Surface Mapping',
                'severity': 'info',
                'url': url,
                'description': f"Discovered {len(self.results['endpoints'])} endpoints",
                'confidence': 1.0
            })
        
        return vulns
    
    def gather(self, passive_only: bool = False, depth: int = 3) -> Dict:
        """Gather comprehensive target information."""
        logger.info(f"Gathering information for {self.target}")
        
        if not passive_only:
            self._discover_subdomains()
            self._dns_enumeration()
        
        self._gather_info()
        self._discover_endpoints(depth=depth)
        self._fingerprint_technologies()
        
        return self.results
    
    def _gather_info(self):
        """Gather basic information about target."""
        parsed = urlparse(self.target)
        domain = parsed.netloc
        
        self.results['domain'] = domain
        self.results['scheme'] = parsed.scheme
        self.results['base_url'] = f"{parsed.scheme}://{parsed.netloc}"
        
        # Get IP address
        try:
            ip = socket.gethostbyname(domain)
            self.results['ip_address'] = ip
            logger.info(f"Resolved {domain} -> {ip}")
        except Exception as e:
            logger.warning(f"Could not resolve {domain}: {e}")
        
        # Check robots.txt
        try:
            robots_url = f"{self.results['base_url']}/robots.txt"
            response = self.session.get(robots_url, timeout=10)
            if response.status_code == 200:
                self.results['robots_txt'] = response.text
                # Extract disallowed paths
                disallowed = re.findall(r'Disallow:\s*(.*)', response.text)
                self.results['disallowed_paths'] = [d.strip() for d in disallowed if d.strip()]
                logger.info(f"Found {len(disallowed)} disallowed paths in robots.txt")
        except Exception:
            pass
        
        # Check sitemap.xml
        try:
            sitemap_url = f"{self.results['base_url']}/sitemap.xml"
            response = self.session.get(sitemap_url, timeout=10)
            if response.status_code == 200:
                self.results['sitemap'] = response.text
                # Extract URLs from sitemap
                urls = re.findall(r'<loc>(.*?)</loc>', response.text)
                self.results['urls'].extend(urls)
                logger.info(f"Found {len(urls)} URLs in sitemap")
        except Exception:
            pass
        
        # Security headers check
        try:
            response = self.session.get(self.target, timeout=10)
            security_headers = {
                'Strict-Transport-Security': response.headers.get('Strict-Transport-Security'),
                'Content-Security-Policy': response.headers.get('Content-Security-Policy'),
                'X-Content-Type-Options': response.headers.get('X-Content-Type-Options'),
                'X-Frame-Options': response.headers.get('X-Frame-Options'),
                'X-XSS-Protection': response.headers.get('X-XSS-Protection'),
                'Referrer-Policy': response.headers.get('Referrer-Policy'),
                'Permissions-Policy': response.headers.get('Permissions-Policy'),
            }
            self.results['security_headers'] = {
                k: v for k, v in security_headers.items() if v is not None
            }
        except Exception:
            pass
    
    def _discover_endpoints(self, depth: int = 3):
        """Discover endpoints on the target."""
        visited = set()
        to_visit = [self.target]
        current_depth = 0
        
        while to_visit and current_depth < depth:
            url = to_visit.pop(0)
            if url in visited:
                continue
            
            visited.add(url)
            
            try:
                response = self.session.get(url, timeout=10)
                
                if 'text/html' in response.headers.get('Content-Type', ''):
                    soup = BeautifulSoup(response.text, 'lxml')
                    
                    # Find all links
                    for link in soup.find_all(['a', 'link'], href=True):
                        href = link['href']
                        full_url = urljoin(url, href)
                        
                        if full_url.startswith(self.results.get('base_url', self.target)):
                            if full_url not in visited:
                                to_visit.append(full_url)
                            
                            # Extract parameters
                            if '?' in full_url:
                                self.results['endpoints'].append({
                                    'url': full_url.split('?')[0],
                                    'method': 'GET',
                                    'parameters': self._extract_params(full_url)
                                })
                            else:
                                self.results['endpoints'].append({
                                    'url': full_url,
                                    'method': 'GET',
                                    'parameters': []
                                })
                    
                    # Find forms
                    for form in soup.find_all('form'):
                        form_action = form.get('action', url)
                        form_url = urljoin(url, form_action)
                        form_method = form.get('method', 'GET').upper()
                        
                        form_params = []
                        for input_field in form.find_all(['input', 'textarea', 'select']):
                            name = input_field.get('name')
                            if name:
                                form_params.append({
                                    'name': name,
                                    'type': input_field.get('type', 'text')
                                })
                        
                        self.results['endpoints'].append({
                            'url': form_url,
                            'method': form_method,
                            'parameters': form_params
                        })
                    
                    # Find scripts
                    for script in soup.find_all('script', src=True):
                        src = script['src']
                        if src.endswith('.js'):
                            self.results['endpoints'].append({
                                'url': urljoin(url, src),
                                'method': 'GET',
                                'type': 'javascript'
                            })
            
            except Exception as e:
                logger.debug(f"Failed to crawl {url}: {e}")
            
            current_depth += 1
        
        # Remove duplicates
        seen = set()
        unique_endpoints = []
        for ep in self.results['endpoints']:
            key = f"{ep['url']}:{ep['method']}"
            if key not in seen:
                seen.add(key)
                unique_endpoints.append(ep)
        
        self.results['endpoints'] = unique_endpoints
        logger.info(f"Discovered {len(unique_endpoints)} endpoints")
    
    def _fingerprint_technologies(self):
        """Fingerprint technologies used by the target."""
        technologies = {}
        
        try:
            response = self.session.get(self.target, timeout=10)
            
            # Server header
            server = response.headers.get('Server')
            if server:
                technologies['server'] = server
            
            # X-Powered-By header
            powered_by = response.headers.get('X-Powered-By')
            if powered_by:
                technologies['framework'] = powered_by
            
            # Cookies analysis
            for cookie in response.cookies:
                if 'PHPSESSID' in cookie.name:
                    technologies['language'] = 'PHP'
                elif 'JSESSIONID' in cookie.name:
                    technologies['language'] = 'Java'
                elif 'ASPSESSIONID' in cookie.name or 'ASP.NET' in cookie.name:
                    technologies['language'] = 'ASP.NET'
            
            # HTML analysis
            soup = BeautifulSoup(response.text, 'lxml')
            
            # Meta generator
            generator = soup.find('meta', attrs={'name': 'generator'})
            if generator:
                technologies['cms'] = generator.get('content', '')
            
            # WordPress detection
            if 'wp-content' in response.text or 'wp-includes' in response.text:
                technologies['cms'] = 'WordPress'
            
            # Drupal detection
            if 'Drupal.settings' in response.text or '/drupal.js' in response.text:
                technologies['cms'] = 'Drupal'
            
            # Joomla detection
            if '/joomla.js' in response.text or 'com_content' in response.text:
                technologies['cms'] = 'Joomla'
            
            # JavaScript libraries
            js_libs = []
            for script in soup.find_all('script', src=True):
                src = script['src']
                if 'jquery' in src.lower():
                    js_libs.append('jQuery')
                elif 'react' in src.lower():
                    js_libs.append('React')
                elif 'vue' in src.lower():
                    js_libs.append('Vue.js')
                elif 'angular' in src.lower():
                    js_libs.append('Angular')
                elif 'bootstrap' in src.lower():
                    js_libs.append('Bootstrap')
            
            if js_libs:
                technologies['javascript_libraries'] = list(set(js_libs))
            
            # Database detection
            if 'sql' in response.text.lower():
                technologies['possible_database'] = 'SQL-based'
            
        except Exception as e:
            logger.warning(f"Technology fingerprinting failed: {e}")
        
        self.results['technologies'] = technologies
        logger.info(f"Detected technologies: {json.dumps(technologies, indent=2)}")
    
    def _discover_subdomains(self):
        """Discover subdomains using common techniques."""
        from urllib.parse import urlparse
        
        domain = urlparse(self.target).netloc
        if ':' in domain:
            domain = domain.split(':')[0]
        
        # Common subdomains wordlist
        common_subdomains = [
            'www', 'mail', 'remote', 'blog', 'webmail', 'server', 'ns1', 'ns2', 
            'smtp', 'secure', 'vpn', 'admin', 'cpanel', 'whm', 'test', 'dev', 
            'staging', 'api', 'app', 'm', 'mobile', 'shop', 'portal', 'cdn',
            'static', 'media', 'img', 'css', 'js', 'assets', 'download',
            'ftp', 'ssh', 'git', 'svn', 'jenkins', 'jira', 'confluence',
            'wiki', 'docs', 'help', 'support', 'status', 'statuspage',
            'calendar', 'drive', 'cloud', 'office', 'exchange', 'owa',
            'autodiscover', 'lyncdiscover', 'sip', 'meet', 'teams',
            'news', 'info', 'store', 'cart', 'checkout', 'payment',
            'gateway', 'payment', 'billing', 'invoice', 'account',
            'login', 'signup', 'register', 'auth', 'oauth', 'sso',
            'partner', 'partners', 'affiliate', 'affiliates',
            'research', 'lab', 'labs', 'beta', 'alpha', 'demo',
            'internal', 'intranet', 'corp', 'corporate',
            'monitor', 'monitoring', 'analytics', 'analytics',
            'tracking', 'track', 'stats', 'statistics',
            'survey', 'surveys', 'feedback', 'bug', 'bugs',
        ]
        
        found_subdomains = []
        
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = {
                executor.submit(self._check_subdomain, f"{sub}.{domain}"): sub 
                for sub in common_subdomains
            }
            
            for future in as_completed(futures):
                sub = futures[future]
                try:
                    if future.result():
                        found_subdomains.append(f"{sub}.{domain}")
                except Exception:
                    pass
        
        self.results['subdomains'] = found_subdomains
        logger.info(f"Found {len(found_subdomains)} subdomains")
    
    def _check_subdomain(self, subdomain: str) -> bool:
        """Check if a subdomain exists."""
        try:
            socket.gethostbyname(subdomain)
            return True
        except socket.gaierror:
            return False
    
    def _dns_enumeration(self):
        """Enumerate DNS records."""
        from urllib.parse import urlparse
        
        domain = urlparse(self.target).netloc
        if ':' in domain:
            domain = domain.split(':')[0]
        
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA', 'CNAME']
        dns_records = {}
        
        for record_type in record_types:
            try:
                answers = dns.resolver.resolve(domain, record_type)
                dns_records[record_type] = [str(answer) for answer in answers]
            except Exception as e:
                logger.debug(f"DNS {record_type} lookup failed: {e}")
        
        self.results['dns_records'] = dns_records
        logger.info(f"Enumerated DNS records: {list(dns_records.keys())}")
    
    def _extract_params(self, url: str) -> List[str]:
        """Extract parameter names from URL."""
        parsed = urlparse(url)
        params = parsed.query.split('&')
        return [p.split('=')[0] for p in params if '=' in p]
    
    def cleanup(self):
        """Cleanup resources."""
        if self.session:
            self.session.close()


# Register module
ModuleManager.register_module('recon', Reconnaissance)

