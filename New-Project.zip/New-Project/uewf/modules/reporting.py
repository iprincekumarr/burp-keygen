"""
Reporting module for uEWF.
Generates comprehensive security assessment reports in multiple formats.
"""

import json
import os
from typing import Dict, List, Optional
from datetime import datetime
from pathlib import Path
from jinja2 import Template, Environment, FileSystemLoader
import markdown
import re

from ..core.modules import BaseModule, ModuleManager
from ..core.logger import get_logger
from ..core.config import Config

logger = get_logger(__name__)


class ReportGenerator(BaseModule):
    """Security assessment report generator."""
    
    name = "reporting"
    description = "Generates comprehensive security assessment reports"
    version = "1.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = [
        "JSON Report",
        "HTML Report",
        "Markdown Report",
        "PDF Report (via HTML)",
        "SARIF Report"
    ]
    
    # HTML Template for reports
    HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>uEWF Security Assessment Report - {{ target }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
               line-height: 1.6; color: #333; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                  color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; }
        .header h1 { font-size: 2em; margin-bottom: 10px; }
        .header .meta { opacity: 0.9; font-size: 0.9em; }
        .summary { background: white; border-radius: 10px; padding: 30px; margin-bottom: 30px;
                   box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 20px; margin-top: 20px; }
        .stat-card { text-align: center; padding: 20px; border-radius: 8px; }
        .stat-card.critical { background: #fff5f5; border-left: 4px solid #e53e3e; }
        .stat-card.high { background: #fffaf0; border-left: 4px solid #dd6b20; }
        .stat-card.medium { background: #fffff0; border-left: 4px solid #d69e2e; }
        .stat-card.low { background: #f0fff4; border-left: 4px solid #38a169; }
        .stat-card.info { background: #ebf8ff; border-left: 4px solid #3182ce; }
        .stat-number { font-size: 2.5em; font-weight: bold; }
        .stat-label { color: #666; margin-top: 5px; }
        .vuln-card { background: white; border-radius: 10px; padding: 25px; margin-bottom: 20px;
                     box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .vuln-header { display: flex; justify-content: space-between; align-items: center;
                       margin-bottom: 15px; }
        .severity-badge { padding: 4px 12px; border-radius: 4px; font-size: 0.8em; 
                          font-weight: bold; text-transform: uppercase; }
        .severity-badge.critical { background: #e53e3e; color: white; }
        .severity-badge.high { background: #dd6b20; color: white; }
        .severity-badge.medium { background: #d69e2e; color: white; }
        .severity-badge.low { background: #38a169; color: white; }
        .severity-badge.info { background: #3182ce; color: white; }
        .vuln-detail { margin-top: 15px; }
        .vuln-detail h4 { color: #4a5568; margin-bottom: 5px; }
        .vuln-detail p, .vuln-detail pre { margin-bottom: 10px; }
        .vuln-detail pre { background: #f7fafc; padding: 15px; border-radius: 5px; 
                          overflow-x: auto; font-size: 0.85em; }
        .remediation { background: #f0fff4; border-left: 4px solid #38a169; 
                       padding: 15px; border-radius: 5px; margin-top: 10px; }
        .section-title { font-size: 1.5em; color: #2d3748; margin: 30px 0 20px; 
                          padding-bottom: 10px; border-bottom: 2px solid #e2e8f0; }
        .tech-list { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px; }
        .tech-badge { background: #edf2f7; padding: 5px 15px; border-radius: 15px;
                      font-size: 0.85em; color: #4a5568; }
        .endpoint-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .endpoint-table th, .endpoint-table td { padding: 12px; text-align: left; 
                                                  border-bottom: 1px solid #e2e8f0; }
        .endpoint-table th { background: #f7fafc; font-weight: 600; color: #4a5568; }
        .endpoint-table tr:hover { background: #f7fafc; }
        .footer { text-align: center; padding: 40px; color: #a0aec0; font-size: 0.85em; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 uEWF Security Assessment Report</h1>
            <div class="meta">
                <p><strong>Target:</strong> {{ target }}</p>
                <p><strong>Scan Date:</strong> {{ scan_date }}</p>
                <p><strong>Duration:</strong> {{ duration }} seconds</p>
                <p><strong>Generated:</strong> {{ report_date }}</p>
            </div>
        </div>
        
        {% if scan_summary %}
        <div class="summary">
            <h2>📊 Executive Summary</h2>
            <p>Total vulnerabilities found: <strong>{{ vulnerabilities|length }}</strong></p>
            
            <div class="summary-grid">
                {% for severity in ['critical', 'high', 'medium', 'low', 'info'] %}
                {% set count = scan_summary.by_severity.get(severity, 0) %}
                {% if count > 0 %}
                <div class="stat-card {{ severity }}">
                    <div class="stat-number">{{ count }}</div>
                    <div class="stat-label">{{ severity|upper }}</div>
                </div>
                {% endif %}
                {% endfor %}
            </div>
        </div>
        {% endif %}
        
        {% if technologies %}
        <div class="summary">
            <h2>🛠️ Detected Technologies</h2>
            <div class="tech-list">
                {% for key, value in technologies.items() %}
                <span class="tech-badge">{{ key }}: {{ value }}</span>
                {% endfor %}
            </div>
        </div>
        {% endif %}
        
        <h2 class="section-title">🔍 Vulnerabilities Found</h2>
        
        {% if vulnerabilities %}
            {% for vuln in vulnerabilities %}
            <div class="vuln-card">
                <div class="vuln-header">
                    <h3>{{ vuln.type }}</h3>
                    <span class="severity-badge {{ vuln.severity }}">{{ vuln.severity }}</span>
                </div>
                
                {% if vuln.url %}
                <div class="vuln-detail">
                    <h4>URL</h4>
                    <p>{{ vuln.url }}</p>
                </div>
                {% endif %}
                
                {% if vuln.parameter %}
                <div class="vuln-detail">
                    <h4>Parameter</h4>
                    <p>{{ vuln.parameter }}</p>
                </div>
                {% endif %}
                
                <div class="vuln-detail">
                    <h4>Description</h4>
                    <p>{{ vuln.description }}</p>
                </div>
                
                {% if vuln.payload %}
                <div class="vuln-detail">
                    <h4>Test Payload</h4>
                    <pre><code>{{ vuln.payload }}</code></pre>
                </div>
                {% endif %}
                
                {% if vuln.evidence %}
                <div class="vuln-detail">
                    <h4>Evidence</h4>
                    <pre><code>{{ vuln.evidence }}</code></pre>
                </div>
                {% endif %}
                
                {% if vuln.remediation %}
                <div class="remediation">
                    <h4>✅ Remediation</h4>
                    <p>{{ vuln.remediation }}</p>
                </div>
                {% endif %}
            </div>
            {% endfor %}
        {% else %}
            <div class="vuln-card">
                <h3>✅ No vulnerabilities found</h3>
                <p>The target appears to be secure against the tested attack vectors.</p>
            </div>
        {% endif %}
        
        {% if endpoints %}
        <h2 class="section-title">🔗 Discovered Endpoints</h2>
        <div class="summary">
            <table class="endpoint-table">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>URL</th>
                        <th>Parameters</th>
                    </tr>
                </thead>
                <tbody>
                    {% for ep in endpoints[:50] %}
                    <tr>
                        <td>{{ ep.method }}</td>
                        <td>{{ ep.url }}</td>
                        <td>{{ ep.parameters|length }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
            {% if endpoints|length > 50 %}
            <p style="margin-top: 15px; color: #666;">... and {{ endpoints|length - 50 }} more endpoints</p>
            {% endif %}
        </div>
        {% endif %}
        
        <div class="footer">
            <p>Generated by <strong>uEWF</strong> - Unified Web Exploitation Framework</p>
            <p>This report is for authorized security testing purposes only.</p>
            <p>Report generated on {{ report_date }}</p>
        </div>
    </div>
</body>
</html>
    """
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def test(self, url: str, parameters: list = None, method: str = 'GET', session=None) -> list:
        """No vulnerabilities to return from reporting module."""
        return []
    
    def generate(self, data: Dict, format: str = 'html', output_path: str = None, 
                 template: str = None) -> str:
        """Generate security assessment report."""
        
        if not output_path:
            output_dir = Config.get_output_dir()
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_path = str(output_dir / f"report_{timestamp}")
        
        # Prepare report data
        report_data = self._prepare_report_data(data)
        
        if format == 'json':
            return self._generate_json(report_data, output_path)
        elif format == 'html':
            return self._generate_html(report_data, output_path, template)
        elif format == 'markdown':
            return self._generate_markdown(report_data, output_path)
        elif format == 'pdf':
            return self._generate_pdf(report_data, output_path)
        elif format == 'sarif':
            return self._generate_sarif(report_data, output_path)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _prepare_report_data(self, data: Dict) -> Dict:
        """Prepare and normalize report data."""
        vulnerabilities = data.get('vulnerabilities', [])
        
        # Sort vulnerabilities by severity
        severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
        vulnerabilities.sort(key=lambda x: severity_order.get(x.get('severity', 'info'), 5))
        
        # Calculate summary
        severity_counts = {}
        for vuln in vulnerabilities:
            sev = vuln.get('severity', 'info')
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        
        scan_summary = {
            'total': len(vulnerabilities),
            'by_severity': severity_counts,
            'critical': severity_counts.get('critical', 0),
            'high': severity_counts.get('high', 0),
            'medium': severity_counts.get('medium', 0),
            'low': severity_counts.get('low', 0),
            'info': severity_counts.get('info', 0)
        }
        
        # Compile report
        report_data = {
            'target': data.get('target', 'N/A'),
            'scan_date': data.get('start_time', 'N/A'),
            'duration': data.get('scan_summary', {}).get('duration_seconds', 0),
            'report_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'scan_summary': scan_summary,
            'vulnerabilities': vulnerabilities,
            'technologies': data.get('technology_stack', {}),
            'endpoints': data.get('endpoints', []),
            'modules_used': data.get('modules_used', []),
        }
        
        return report_data
    
    def _generate_json(self, data: Dict, output_path: str) -> str:
        """Generate JSON report."""
        path = f"{output_path}.json"
        with open(path, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        logger.info(f"JSON report generated: {path}")
        return path
    
    def _generate_html(self, data: Dict, output_path: str, template_path: str = None) -> str:
        """Generate HTML report."""
        if template_path:
            env = Environment(loader=FileSystemLoader(Path(template_path).parent))
            template = env.get_template(Path(template_path).name)
        else:
            template = Template(self.HTML_TEMPLATE)
        
        html_content = template.render(**data)
        
        # Inline CSS for standalone HTML
        path = f"{output_path}.html"
        with open(path, 'w') as f:
            f.write(html_content)
        
        logger.info(f"HTML report generated: {path}")
        return path
    
    def _generate_markdown(self, data: Dict, output_path: str) -> str:
        """Generate Markdown report."""
        md = []
        md.append(f"# uEWF Security Assessment Report\n")
        md.append(f"**Target:** {data['target']}")
        md.append(f"**Scan Date:** {data['scan_date']}")
        md.append(f"**Duration:** {data['duration']} seconds")
        md.append(f"**Generated:** {data['report_date']}\n")
        
        md.append("## Executive Summary\n")
        md.append(f"Total vulnerabilities found: {data['scan_summary']['total']}\n")
        md.append("| Severity | Count |")
        md.append("|----------|-------|")
        for severity in ['critical', 'high', 'medium', 'low', 'info']:
            count = data['scan_summary']['by_severity'].get(severity, 0)
            if count > 0:
                md.append(f"| {severity.upper()} | {count} |")
        
        md.append("\n## Vulnerabilities Found\n")
        
        if data['vulnerabilities']:
            for vuln in data['vulnerabilities']:
                md.append(f"### {vuln['type']} ({vuln['severity'].upper()})\n")
                if vuln.get('url'):
                    md.append(f"- **URL:** {vuln['url']}")
                if vuln.get('parameter'):
                    md.append(f"- **Parameter:** {vuln['parameter']}")
                md.append(f"- **Description:** {vuln['description']}")
                if vuln.get('evidence'):
                    md.append(f"- **Evidence:** `{vuln['evidence']}`")
                if vuln.get('remediation'):
                    md.append(f"- **Remediation:** {vuln['remediation']}")
                md.append("")
        else:
            md.append("No vulnerabilities found.\n")
        
        if data.get('endpoints'):
            md.append("\n## Discovered Endpoints\n")
            for ep in data['endpoints'][:30]:
                md.append(f"- [{ep['method']}] {ep['url']}")
        
        md.append("\n---\n")
        md.append("*Generated by uEWF - Unified Web Exploitation Framework*\n")
        
        path = f"{output_path}.md"
        with open(path, 'w') as f:
            f.write('\n'.join(md))
        
        logger.info(f"Markdown report generated: {path}")
        return path
    
    def _generate_pdf(self, data: Dict, output_path: str) -> str:
        """Generate PDF report (via HTML conversion)."""
        # Generate HTML first, then convert to PDF
        html_path = self._generate_html(data, output_path + "_temp")
        pdf_path = f"{output_path}.pdf"
        
        try:
            import pdfkit
            pdfkit.from_file(html_path, pdf_path)
            # Clean up temp HTML
            os.remove(html_path)
            logger.info(f"PDF report generated: {pdf_path}")
            return pdf_path
        except ImportError:
            logger.warning("pdfkit not installed. Saving as HTML instead.")
            # Rename temp HTML to final path
            final_html_path = f"{output_path}.html"
            os.rename(html_path, final_html_path)
            return final_html_path
    
    def _generate_sarif(self, data: Dict, output_path: str) -> str:
        """Generate SARIF (Static Analysis Results Interchange Format) report."""
        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "uEWF",
                        "version": "1.0.0",
                        "informationUri": "https://github.com/example/uewf",
                        "rules": []
                    }
                },
                "results": []
            }]
        }
        
        for vuln in data.get('vulnerabilities', []):
            rule_id = f"{vuln['type'].replace(' ', '-').upper()}"
            
            # Add rule if not exists
            if not any(r.get('id') == rule_id for r in sarif['runs'][0]['tool']['driver']['rules']):
                sarif['runs'][0]['tool']['driver']['rules'].append({
                    "id": rule_id,
                    "name": vuln['type'],
                    "shortDescription": {"text": vuln.get('description', '')},
                    "defaultConfiguration": {"level": vuln.get('severity', 'warning')},
                })
            
            result = {
                "ruleId": rule_id,
                "level": "error" if vuln.get('severity') in ['critical', 'high'] else "warning",
                "message": {"text": vuln.get('description', '')},
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {"uri": vuln.get('url', '')},
                    }
                }]
            }
            
            if vuln.get('parameter'):
                result['locations'][0]['physicalLocation']['region'] = {
                    "message": {"text": f"Parameter: {vuln['parameter']}"}
                }
            
            sarif['runs'][0]['results'].append(result)
        
        path = f"{output_path}.sarif"
        with open(path, 'w') as f:
            json.dump(sarif, f, indent=2)
        
        logger.info(f"SARIF report generated: {path}")
        return path


# Register module
ModuleManager.register_module('reporting', ReportGenerator)

