"""
Cross-Site Scripting (XSS) testing module for uEWF.
Detects XSS vulnerabilities including reflected, stored, DOM-based, and blind XSS.
"""

import re
import json
from typing import List, Dict, Optional
from urllib.parse import urlparse, parse_qs, urljoin
import random
import string

import requests
from bs4 import BeautifulSoup

from ..core.modules import BaseModule, ModuleManager
from ..core.safeties import SafetyManager
from ..core.logger import get_logger
from ..utils.payloads import PayloadManager

logger = get_logger(__name__)


class XSSTester(BaseModule):
    """Cross-Site Scripting vulnerability tester."""
    
    name = "xss"
    description = "Cross-Site Scripting detection module"
    version = "1.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = [
        "Reflected XSS",
        "Stored XSS",
        "DOM-based XSS",
        "Blind XSS"
    ]
    
    # XSS event handlers for context-specific testing
    EVENT_HANDLERS = [
        "onload", "onerror", "onclick", "onmouseover",
        "onfocus", "onblur", "onchange", "onsubmit",
        "onreset", "onselect", "onscroll", "onunload",
        "onresize", "onabort", "onkeydown", "onkeypress",
        "onkeyup", "onmousedown", "onmousemove", "onmouseout",
        "onmouseup", "onwheel", "ondrag", "ondrop",
    ]
    
    # Context patterns for XSS detection
    CONTEXT_PATTERNS = {
        'html': [
            r'<[^>]*{payload}[^>]*>',
            r'{payload}',
        ],
        'attribute': [
            r'"[^"]*{payload}[^"]*"',
            r"'[^']*{payload}[^']*'",
        ],
        'script': [
            r'<script[^>]*>[^<]*{payload}[^<]*</script>',
            r"'[^']*{payload}[^']*'",
            r'"[^"]*{payload}[^"]*"',
        ],
        'url': [
            r'href=[\'"]?[^\'" >]*{payload}',
            r'src=[\'"]?[^\'" >]*{payload}',
        ],
        'style': [
            r'style=[\'"][^\'"]*{payload}[^\'"]*[\'"]',
        ],
    }
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self.target = self.config.get('target', '')
        self.parameter = self.config.get('parameter')
        self.cookie = self.config.get('cookie')
        self.safe_mode = self.config.get('safe_mode', True)
        self.session = None
        self.safety = SafetyManager()
        self.payload_manager = PayloadManager()
        self.vulnerabilities = []
    
    def test(self, url: str, parameters: List = None, method: str = 'GET', session=None) -> List[Dict]:
        """Run XSS tests."""
        self.session = session or requests.Session()
        self.target = url
        self.vulnerabilities = []
        
        logger.info(f"Starting XSS test on {url}")
        
        # Get parameters to test
        test_params = self._get_test_parameters(url, parameters)
        
        for param_info in test_params:
            param_name = param_info['name']
            param_value = param_info.get('value', '')
            
            if not self.safety.validate_parameter(param_name):
                continue
            
            # Test reflected XSS
            self._test_reflected_xss(url, param_name, param_value, method)
            
            # Test DOM-based XSS
            self._test_dom_xss(url, param_name, param_value, method)
        
        # Test stored XSS
        if self._has_forms(url):
            self._test_stored_xss(url)
        
        return self.vulnerabilities
    
    def _get_test_parameters(self, url: str, parameters: List) -> List[Dict]:
        """Get list of parameters to test."""
        if self.parameter:
            return [{'name': self.parameter, 'value': 'test'}]
        
        if parameters:
            if isinstance(parameters[0], dict):
                return parameters
            return [{'name': p, 'value': 'test'} for p in parameters if isinstance(p, str)]
        
        # Parse URL parameters
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if not params:
            # Try to find parameters in path
            path_parts = parsed.path.split('/')
            params_in_path = [p for p in path_parts if '=' in p]
            if params_in_path:
                return [{'name': p.split('=')[0], 'value': p.split('=')[1]} for p in params_in_path]
        
        return [{'name': k, 'value': v[0] if v else 'test'} for k, v in params.items()]
    
    def _make_request(self, url: str, params: Dict, method: str = 'GET') -> Optional[requests.Response]:
        """Make HTTP request with parameters."""
        try:
            if method.upper() == 'GET':
                response = self.session.get(url, params=params, timeout=30)
            else:
                response = self.session.post(url, data=params, timeout=30)
            return response
        except Exception as e:
            logger.debug(f"Request failed: {e}")
            return None
    
    def _test_reflected_xss(self, url: str, param: str, value: str, method: str):
        """Test for reflected XSS vulnerabilities."""
        logger.debug(f"Testing reflected XSS on parameter: {param}")
        
        # Test payloads for reflected XSS
        test_payloads = [
            # Simple script injection
            "<script>alert(1)</script>",
            "<script>alert('XSS')</script>",
            
            # Image-based XSS
            "<img src=x onerror=alert(1)>",
            "<img src=x onerror=alert('XSS')>",
            
            # SVG-based XSS
            "<svg onload=alert(1)>",
            "<svg/onload=alert('XSS')>",
            
            # Body-based XSS
            "<body onload=alert(1)>",
            
            # Input-based XSS
            "<input autofocus onfocus=alert(1)>",
            
            # Details-based XSS
            "<details open ontoggle=alert(1)>",
            
            # Select-based XSS
            "<select autofocus onfocus=alert(1)>",
            
            # Textarea-based XSS
            "<textarea autofocus onfocus=alert(1)>",
            
            # Keygen-based XSS
            "<keygen autofocus onfocus=alert(1)>",
            
            # Iframe-based XSS
            "<iframe onload=alert(1)>",
            
            # Link-based XSS
            "<a href=javascript:alert(1)>click</a>",
            "<a href=\"javascript:alert('XSS')\">click</a>",
            
            # Attribute-based XSS
            "\" onmouseover=alert(1) \"",
            "' onmouseover=alert(1) '",
            
            # Unicode-based XSS
            "<script>\\u0061lert(1)</script>",
            
            # URL-based XSS
            "javascript:alert(1)",
            
            # Mixed case
            "<ScRiPt>alert(1)</sCrIpT>",
            
            # Without parentheses
            "<script>alert`1`</script>",
            
            # With HTML encoding
            "&#60;script&#62;alert(1)&#60;/script&#62;",
            
            # Double encoding
            "%253Cscript%253Ealert(1)%253C/script%253E",
        ]
        
        for payload in test_payloads:
            if not self.safety.validate_payload(payload, 'xss')[0]:
                continue
            
            test_params = {param: payload}
            response = self._make_request(url, test_params, method)
            
            if response and self._check_xss_in_response(response, payload):
                vuln = {
                    'type': 'Reflected XSS',
                    'severity': 'high',
                    'url': url,
                    'parameter': param,
                    'payload': payload,
                    'description': f"Reflected XSS vulnerability detected in parameter '{param}'",
                    'evidence': f"Payload reflected in response: {payload[:100]}",
                    'remediation': 'Implement proper output encoding. Use context-specific escaping.',
                    'confidence': 0.95
                }
                self.vulnerabilities.append(vuln)
                logger.warning(f"Reflected XSS found: {param}")
                break
    
    def _check_xss_in_response(self, response: requests.Response, payload: str) -> bool:
        """Check if XSS payload is reflected in response without sanitization."""
        content = response.text
        
        # Check if payload exists in raw form
        if payload in content:
            # Check for obvious sanitization
            sanitized_versions = [
                payload.replace('<', '<'),
                payload.replace('>', '>'),
                payload.replace('"', '"'),
                payload.replace("'", '&#39;'),
                payload.replace('<script>', ''),
                payload.replace('</script>', ''),
                payload.replace('onerror', 'onerror_'),
                payload.replace('onload', 'onload_'),
                payload.replace('onfocus', 'onfocus_'),
                payload.replace('onmouseover', 'onmouseover_'),
                payload.replace('alert', 'alert_'),
            ]
            
            # If the exact payload is found without sanitization characters
            for sanitized in sanitized_versions:
                if sanitized in content:
                    return False
            
            return True
        
        return False
    
    def _test_stored_xss(self, url: str):
        """Test for stored XSS vulnerabilities."""
        logger.debug("Testing stored XSS")
        
        # Find forms that might store data
        try:
            response = self.session.get(url, timeout=30)
            soup = BeautifulSoup(response.text, 'lxml')
            
            forms = soup.find_all('form')
            
            for form in forms:
                form_action = form.get('action', url)
                form_url = urljoin(url, form_action)
                form_method = form.get('method', 'GET').upper()
                
                # Build form data
                form_data = {}
                for input_field in form.find_all(['input', 'textarea']):
                    input_name = input_field.get('name')
                    input_type = input_field.get('type', 'text')
                    
                    if input_name and input_type not in ['submit', 'button', 'hidden', 'password']:
                        # Test XSS in input fields
                        payload = "<script>alert('StoredXSS')</script>"
                        form_data[input_name] = payload
                
                if form_data:
                    try:
                        if form_method == 'POST':
                            response = self.session.post(form_url, data=form_data, timeout=30)
                        else:
                            response = self.session.get(form_url, params=form_data, timeout=30)
                        
                        # Check if payload was stored
                        if response and self._check_stored_xss(form_url):
                            for param_name in form_data.keys():
                                vuln = {
                                    'type': 'Stored XSS',
                                    'severity': 'critical',
                                    'url': form_url,
                                    'parameter': param_name,
                                    'payload': form_data[param_name],
                                    'description': f"Stored XSS vulnerability detected in form field '{param_name}'",
                                    'evidence': "XSS payload was stored and executed",
                                    'remediation': 'Implement input validation and output encoding. Use Content-Security-Policy headers.',
                                    'confidence': 0.9
                                }
                                self.vulnerabilities.append(vuln)
                                logger.warning(f"Stored XSS found in form: {param_name}")
                                break
                    except Exception as e:
                        logger.debug(f"Stored XSS test failed: {e}")
        
        except Exception as e:
            logger.debug(f"Form discovery failed: {e}")
    
    def _check_stored_xss(self, url: str) -> bool:
        """Check if XSS payload was stored and executed."""
        try:
            response = self.session.get(url, timeout=30)
            return "StoredXSS" in response.text or "alert('StoredXSS')" in response.text
        except Exception:
            return False
    
    def _test_dom_xss(self, url: str, param: str, value: str, method: str):
        """Test for DOM-based XSS vulnerabilities."""
        logger.debug(f"Testing DOM-based XSS on parameter: {param}")
        
        # Payloads that might execute in DOM context
        dom_payloads = [
            "#<script>alert(1)</script>",
            "#<img src=x onerror=alert(1)>",
            "javascript:alert(1)",
            "data:text/html,<script>alert(1)</script>",
            "\"-alert(1)-\"",
            "'-alert(1)-'",
            "`-alert(1)-`",
        ]
        
        for payload in dom_payloads:
            if not self.safety.validate_payload(payload, 'xss')[0]:
                continue
            
            test_params = {param: payload}
            response = self._make_request(url, test_params, method)
            
            if response and self._check_dom_xss_indicators(response, param, payload):
                vuln = {
                    'type': 'DOM-based XSS',
                    'severity': 'high',
                    'url': url,
                    'parameter': param,
                    'payload': payload,
                    'description': f"Potential DOM-based XSS vulnerability in parameter '{param}'",
                    'evidence': f"Payload found in DOM-context: {payload[:100]}",
                    'remediation': 'Avoid using innerHTML, document.write, and eval(). Use safe DOM manipulation methods.',
                    'confidence': 0.7
                }
                self.vulnerabilities.append(vuln)
                logger.warning(f"DOM-based XSS found: {param}")
                break
    
    def _check_dom_xss_indicators(self, response: requests.Response, param: str, payload: str) -> bool:
        """Check for DOM-based XSS indicators."""
        content = response.text
        
        # Check for common DOM XSS sinks
        dom_sinks = [
            'document.write',
            'innerHTML',
            'outerHTML',
            'insertAdjacentHTML',
            'eval(',
            'setTimeout(',
            'setInterval(',
            'Function(',
            'location.href',
            'location.hash',
            'location.search',
            'document.cookie',
        ]
        
        for sink in dom_sinks:
            if sink in content:
                # Check if our parameter value appears near the sink
                lines = content.split('\n')
                for i, line in enumerate(lines):
                    if sink in line and (param in line or payload in line):
                        return True
        
        return False
    
    def _has_forms(self, url: str) -> bool:
        """Check if page has forms for stored XSS testing."""
        try:
            response = self.session.get(url, timeout=30)
            soup = BeautifulSoup(response.text, 'lxml')
            return len(soup.find_all('form')) > 0
        except Exception:
            return False
    
    def cleanup(self):
        """Cleanup resources."""
        if self.session:
            self.session.close()


# Register module
ModuleManager.register_module('xss', XSSTester)

