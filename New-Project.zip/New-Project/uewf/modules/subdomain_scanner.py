"""
Subdomain scanning module for uEWF.
Discovers subdomains using multiple sources and techniques,
then integrates them into the main scanning pipeline.
"""

from typing import List, Dict, Optional
from urllib.parse import urlparse

from ..core.modules import BaseModule, ModuleManager
from ..core.logger import get_logger
from ..core.database import Database
from ..utils.subdomain import SubdomainEngine

logger = get_logger(__name__)


class SubdomainScanner(BaseModule):
    """Subdomain discovery and scanning module."""
    
    name = "subdomain_scanner"
    description = "Subdomain discovery using crt.sh, SecurityTrails, DNS bruteforce, and subfinder"
    version = "1.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = [
        "Certificate Transparency (crt.sh)",
        "DNS Bruteforce",
        "Subfinder",
        "SecurityTrails API",
        "Active HTTP Probing"
    ]
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self.target = self.config.get('target', '')
        self.sources = self.config.get('subdomain_sources', ['crt.sh', 'securitytrails', 'subfinder', 'bruteforce'])
        self.wordlist = self.config.get('subdomain_wordlist')
        self.session = None
    
    def test(self, url: str, parameters: List = None, method: str = 'GET', session=None) -> List[Dict]:
        """
        Run subdomain discovery.
        For vulnerability scanning compatibility, returns informational findings.
        """
        self.session = session
        self.target = url
        
        # Extract domain from URL
        parsed = urlparse(url)
        domain = parsed.netloc
        if ':' in domain:
            domain = domain.split(':')[0]
        
        if not domain:
            return []
        
        logger.info(f"Starting subdomain discovery for {domain}")
        
        # Run discovery
        engine = SubdomainEngine(domain)
        results = engine.discover_all(sources=self.sources, wordlist=self.wordlist)
        
        # Return as informational vulnerability findings
        vulns = []
        if results:
            active_count = sum(1 for r in results if r.get('alive'))
            vulns.append({
                'type': 'Subdomain Discovery',
                'severity': 'info',
                'url': url,
                'parameter': '',
                'payload': '',
                'description': f"Discovered {len(results)} subdomains ({active_count} active) for {domain}",
                'evidence': f"Active subdomains: {', '.join(r['subdomain'] for r in results[:10] if r.get('alive'))}",
                'remediation': 'Ensure subdomains are properly secured and monitored',
                'confidence': 0.9
            })
        
        return vulns
    
    def discover(self, url: str) -> Dict:
        """
        Full subdomain discovery returning all data.
        
        Returns:
            Dict with discovered and verified subdomains
        """
        parsed = urlparse(url)
        domain = parsed.netloc
        if ':' in domain:
            domain = domain.split(':')[0]
        
        if not domain:
            return {'domain': '', 'discovered': [], 'verified': [], 'summary': {}}
        
        engine = SubdomainEngine(domain)
        verified = engine.discover_all(sources=self.sources, wordlist=self.wordlist)
        
        return {
            'domain': domain,
            'discovered': list(engine.discovered_subdomains),
            'verified': verified,
            'summary': engine.get_summary()
        }
    
    def cleanup(self):
        """Cleanup resources."""
        pass


# Register module
ModuleManager.register_module('subdomain_scanner', SubdomainScanner)
