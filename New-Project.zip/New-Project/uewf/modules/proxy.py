"""
Intercepting proxy module for uEWF.
Allows traffic inspection and modification during testing.
"""

import asyncio
import json
from typing import Dict, Optional, Callable
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import threading

import requests

from ..core.modules import BaseModule, ModuleManager
from ..core.logger import get_logger
from ..core.database import Database

logger = get_logger(__name__)


class ProxyRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the intercepting proxy."""
    
    proxy_server = None  # Will be set by ProxyServer
    
    def do_GET(self):
        self._handle_request('GET')
    
    def do_POST(self):
        self._handle_request('POST')
    
    def do_PUT(self):
        self._handle_request('PUT')
    
    def do_DELETE(self):
        self._handle_request('DELETE')
    
    def do_PATCH(self):
        self._handle_request('PATCH')
    
    def do_HEAD(self):
        self._handle_request('HEAD')
    
    def do_OPTIONS(self):
        self._handle_request('OPTIONS')
    
    def _handle_request(self, method: str):
        """Handle intercepted request."""
        # Parse the target URL
        target_url = self.path
        if not target_url.startswith('http'):
            target_url = f"http://{self.headers.get('Host', 'localhost')}{target_url}"
        
        # Build request data
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else None
        
        request_data = {
            'method': method,
            'url': target_url,
            'headers': dict(self.headers),
            'body': body.decode('utf-8') if body else None,
            'timestamp': datetime.now().isoformat()
        }
        
        # Call interceptor if set
        if self.proxy_server and self.proxy_server.interceptor:
            should_forward, modified_request = self.proxy_server.interceptor(request_data)
            if not should_forward:
                self._send_response(403, "Request blocked by uEWF proxy")
                return
            
            if modified_request:
                request_data = modified_request
        
        # Forward request
        try:
            forwarded_response = self._forward_request(request_data)
            self._send_proxied_response(forwarded_response)
            
            # Log request/response
            if self.proxy_server:
                self.proxy_server.log_request(request_data, forwarded_response)
                
        except Exception as e:
            logger.error(f"Proxy request failed: {e}")
            self._send_response(502, f"Bad Gateway: {e}")
    
    def _forward_request(self, request_data: Dict) -> requests.Response:
        """Forward request to target."""
        method = request_data['method']
        url = request_data['url']
        headers = request_data.get('headers', {})
        body = request_data.get('body')
        
        # Remove hop-by-hop headers
        hop_by_hop = [
            'Connection', 'Keep-Alive', 'Proxy-Authenticate',
            'Proxy-Authorization', 'TE', 'Trailers',
            'Transfer-Encoding', 'Upgrade'
        ]
        for header in hop_by_hop:
            headers.pop(header, None)
        
        # Forward the request
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            data=body,
            timeout=30,
            allow_redirects=False,
            verify=False
        )
        
        return response
    
    def _send_proxied_response(self, response: requests.Response):
        """Send proxied response back to client."""
        # Send status
        self.send_response(response.status_code)
        
        # Send headers
        excluded_headers = ['Transfer-Encoding', 'Connection']
        for key, value in response.headers.items():
            if key not in excluded_headers:
                self.send_header(key, value)
        self.end_headers()
        
        # Send body
        self.wfile.write(response.content)
    
    def _send_response(self, status_code: int, message: str):
        """Send custom response."""
        self.send_response(status_code)
        self.send_header('Content-Type', 'text/html')
        self.send_header('X-Proxy', 'uEWF-Security-Proxy')
        self.end_headers()
        self.wfile.write(f"<html><body><h1>{status_code}</h1><p>{message}</p></body></html>".encode())
    
    def log_message(self, format, *args):
        """Override default logging."""
        logger.debug(f"Proxy: {format % args}")


class ProxyServer(BaseModule):
    """Intercepting proxy server for traffic inspection."""
    
    name = "proxy"
    description = "Intercepting proxy for traffic inspection and modification"
    version = "1.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = [
        "Traffic Interception",
        "Request Modification",
        "Response Analysis",
        "Session Replay"
    ]
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self.host = config.get('host', '127.0.0.1') if config else '127.0.0.1'
        self.port = config.get('port', 8080) if config else 8080
        self.server = None
        self.server_thread = None
        self.running = False
        self.interceptor = None
        self.request_log = []
        self.max_log_entries = 1000
    
    def test(self, url: str, parameters: list = None, method: str = 'GET', session=None) -> list:
        """Start proxy server (returns informational finding)."""
        self.start()
        return []
    
    def start(self):
        """Start the proxy server."""
        if self.running:
            logger.warning("Proxy already running")
            return
        
        try:
            ProxyRequestHandler.proxy_server = self
            self.server = HTTPServer((self.host, self.port), ProxyRequestHandler)
            self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.server_thread.start()
            self.running = True
            
            logger.info(f"Proxy server started on {self.host}:{self.port}")
            print(f"\n[+] uEWF Proxy running on http://{self.host}:{self.port}")
            print("[+] Configure your browser to use this proxy")
            print("[+] Press Ctrl+C to stop\n")
            
        except Exception as e:
            logger.error(f"Failed to start proxy: {e}")
            raise
    
    def stop(self):
        """Stop the proxy server."""
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.running = False
            logger.info("Proxy server stopped")
    
    def set_interceptor(self, callback: Callable):
        """
        Set request interceptor callback.
        
        Callback receives: request_data (dict)
        Should return: (should_forward: bool, modified_request: dict or None)
        """
        self.interceptor = callback
        logger.info("Request interceptor set")
    
    def log_request(self, request_data: Dict, response: requests.Response = None):
        """Log proxied request/response pair."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'request': {
                'method': request_data.get('method'),
                'url': request_data.get('url'),
                'headers': request_data.get('headers'),
                'body': request_data.get('body'),
            },
            'response': {
                'status_code': response.status_code if response else None,
                'headers': dict(response.headers) if response else None,
                'body': response.text[:10000] if response and len(response.text) > 0 else None,
            } if response else None
        }
        
        self.request_log.append(log_entry)
        
        # Trim log if too large
        if len(self.request_log) > self.max_log_entries:
            self.request_log = self.request_log[-self.max_log_entries:]
        
        # Log to console
        method = request_data.get('method', 'GET')
        url = request_data.get('url', '')
        status = response.status_code if response else 'N/A'
        logger.info(f"→ {method} {url} [{status}]")
    
    def get_request_log(self, limit: int = 100) -> list:
        """Get logged requests."""
        return self.request_log[-limit:]
    
    def clear_log(self):
        """Clear request log."""
        self.request_log = []
        logger.info("Request log cleared")
    
    def replay_request(self, index: int = -1):
        """Replay a logged request."""
        if not self.request_log:
            logger.warning("No requests in log")
            return None
        
        entry = self.request_log[index]
        request_data = entry['request']
        
        try:
            response = requests.request(
                method=request_data['method'],
                url=request_data['url'],
                headers=request_data.get('headers', {}),
                data=request_data.get('body'),
                timeout=30
            )
            logger.info(f"Replayed {request_data['method']} {request_data['url']} -> {response.status_code}")
            return response
        except Exception as e:
            logger.error(f"Replay failed: {e}")
            return None
    
    def cleanup(self):
        """Cleanup proxy resources."""
        self.stop()


# Register module
ModuleManager.register_module('proxy', ProxyServer)

