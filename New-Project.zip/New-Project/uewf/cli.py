"""
Command Line Interface for uEWF.
"""

import click
import sys
import os
from pathlib import Path
from typing import Optional, List, Tuple
from datetime import datetime
import json

from .core.config import Config
from .core.auth import AuthorizationManager
from .core.logger import get_logger
from .core.safeties import SafetyManager

logger = get_logger(__name__)

# ===== LEGAL DISCLAIMER =====
LEGAL_DISCLAIMER = """
╔══════════════════════════════════════════════════════════════════╗
║                    LEGAL DISCLAIMER                              ║
║                                                                  ║
║  THIS TOOL IS FOR AUTHORIZED SECURITY TESTING ONLY.              ║
║                                                                  ║
║  You must have EXPLICIT WRITTEN PERMISSION before testing        ║
║  any system that is not your own.                                ║
║                                                                  ║
║  Unauthorized testing of computer systems is ILLEGAL and         ║
║  can result in criminal prosecution and civil liability.         ║
║                                                                  ║
║  By using this tool, you acknowledge:                            ║
║  1. You are testing systems you OWN or have PERMISSION to test   ║
║  2. You accept FULL LEGAL RESPONSIBILITY for your actions        ║
║  3. You will use this tool ETHICALLY and LAWFULLY                ║
║                                                                  ║
║  The authors assume NO LIABILITY for misuse of this tool.        ║
╚══════════════════════════════════════════════════════════════════╝
"""


def show_disclaimer():
    """Display legal disclaimer and require acceptance."""
    click.clear()
    click.secho(LEGAL_DISCLAIMER, fg='red', bold=True)
    
    click.echo("\n" + "="*60)
    if not click.confirm(
        '\n⚠️  I have read and accept the legal disclaimer. I will only test systems I own or have permission to test.',
        default=False
    ):
        click.secho("\n❌ You must accept the terms to use this tool.", fg='red')
        sys.exit(1)
    
    # Save acceptance
    Config.set('disclaimer_accepted', True)
    Config.set('disclaimer_accepted_date', datetime.now().isoformat())
    click.secho("\n✅ Disclaimer accepted. Use responsibly.\n", fg='green')


@click.group()
@click.option('--config', '-c', help='Configuration file path', type=click.Path())
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
@click.option('--quiet', '-q', is_flag=True, help='Quiet mode (errors only)')
@click.option('--no-color', is_flag=True, help='Disable colored output')
@click.version_option(version='1.0.0', prog_name='uEWF')
@click.pass_context
def cli(ctx, config, verbose, quiet, no_color):
    """
    uEWF - Unified Web Exploitation Framework
    
    A comprehensive security testing framework for AUTHORIZED web application
    penetration testing and bug bounty hunting.
    
    \b
    WARNING: Only use on systems you own or have explicit permission to test!
    """
    # Initialize context
    ctx.ensure_object(dict)
    
    # Load configuration
    if config:
        Config.load_file(config)
    else:
        Config.initialize()
    
    # Set verbosity
    if verbose:
        Config.set('verbose', True)
        os.environ['UEWF_VERBOSE'] = '1'
    elif quiet:
        Config.set('quiet', True)
        os.environ['UEWF_QUIET'] = '1'
    
    # Check disclaimer
    if not Config.get('disclaimer_accepted'):
        show_disclaimer()
    
    # Initialize safety manager
    ctx.obj['safety'] = SafetyManager()
    
    # Set up logging
    log_level = 'DEBUG' if verbose else ('ERROR' if quiet else 'INFO')
    logger = get_logger('uewf.cli', level=log_level)
    ctx.obj['logger'] = logger


# ===== INIT COMMAND =====
@cli.command()
@click.option('--force', is_flag=True, help='Force reinitialization')
@click.pass_context
def init(ctx, force):
    """Initialize uEWF configuration and data directories."""
    
    click.echo("\n🔧 Initializing uEWF Framework...\n")
    
    try:
        # Create directory structure
        config_dir = Path.home() / '.uewf'
        directories = [
            config_dir,
            config_dir / 'data',
            config_dir / 'output',
            config_dir / 'logs',
            config_dir / 'sessions',
            config_dir / 'payloads',
            config_dir / 'templates',
            config_dir / 'plugins',
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            click.echo(f"  ✓ Created {directory}")
        
        # Initialize configuration
        Config.initialize()
        click.echo("  ✓ Configuration initialized")
        
        # Initialize database
        from .core.database import Database
        Database.initialize()
        click.echo("  ✓ Database initialized")
        
        # Download default payloads
        from .utils.payloads import PayloadManager
        pm = PayloadManager()
        pm.load_default_payloads()
        click.echo("  ✓ Default payloads loaded")
        
        click.secho("\n✅ uEWF initialized successfully!\n", fg='green')
        click.echo(f"Configuration: {config_dir}")
        click.echo(f"Data directory: {config_dir / 'data'}")
        click.echo(f"Output directory: {config_dir / 'output'}")
        
    except Exception as e:
        click.secho(f"\n❌ Initialization failed: {e}", fg='red')
        sys.exit(1)


# ===== SCAN COMMAND =====
@cli.command()
@click.argument('target')
@click.option('--module', '-m', multiple=True, 
              type=click.Choice(['sqli', 'xss', 'ssrf', 'xxe', 'lfi', 'rce', 'all']),
              help='Specific modules to run')
@click.option('--safe-mode/--no-safe-mode', default=True, 
              help='Enable safe mode (detection only, no exploitation)')
@click.option('--output', '-o', help='Output file for results')
@click.option('--format', '-f', 'output_format',
              type=click.Choice(['json', 'html', 'pdf', 'markdown', 'csv']),
              default='json', help='Output format')
@click.option('--threads', '-t', default=10, help='Number of concurrent threads')
@click.option('--timeout', default=30, help='Request timeout in seconds')
@click.option('--depth', default=3, help='Crawl depth for recon')
@click.option('--proxy', help='Proxy URL (e.g., http://127.0.0.1:8080)')
@click.option('--cookie', help='Session cookie for authenticated testing')
@click.option('--header', '-H', multiple=True, help='Custom headers (format: Key:Value)')
@click.pass_context
def scan(ctx, target, module, safe_mode, output, output_format, threads, 
         timeout, depth, proxy, cookie, header):
    """
    Run vulnerability scan against TARGET URL.
    
    TARGET should be a full URL (e.g., http://example.com/page?id=1)
    """
    
    logger = ctx.obj['logger']
    safety = ctx.obj['safety']
    
    # Validate target
    if not safety.validate_target(target):
        click.secho(f"\n❌ Invalid or unauthorized target: {target}", fg='red')
        click.echo("Please ensure:")
        click.echo("  1. You have permission to test this target")
        click.echo("  2. The URL is valid and properly formatted")
        click.echo(f"  3. Run 'uewf config authorize {target}' to add authorization")
        sys.exit(1)
    
    click.secho(f"\n🔍 Starting security scan", fg='blue', bold=True)
    click.echo(f"Target: {target}")
    click.echo(f"Safe Mode: {'✅ Enabled' if safe_mode else '⚠️  Disabled'}")
    click.echo(f"Modules: {', '.join(module) if module else 'all'}")
    click.echo(f"Threads: {threads}")
    click.echo("="*60)
    
    try:
        from .core.scanner import Scanner
        
        # Prepare scan configuration
        scan_config = {
            'target': target,
            'modules': list(module) if module else ['all'],
            'safe_mode': safe_mode,
            'threads': threads,
            'timeout': timeout,
            'depth': depth,
            'proxy': proxy,
            'cookie': cookie,
            'headers': dict(h.split(':', 1) for h in header) if header else {},
        }
        
        # Initialize scanner
        scanner = Scanner(scan_config)
        
        # Run scan
        with click.progressbar(length=100, label='Scanning') as bar:
            results = scanner.run(callback=lambda p: bar.update(p - bar.pos))
        
        # Display results
        _display_scan_results(results)
        
        # Display subdomain summary
        if results.get('subdomains'):
            subdomains_data = results['subdomains']
            active = [s for s in subdomains_data if s.get('alive')]
            click.echo(f"\n{'='*60}")
            click.secho(f"🌐 SUBDOMAIN DISCOVERY - {len(subdomains_data)} found ({len(active)} active)", fg='blue', bold=True)
            if active:
                for s in active[:20]:
                    status = s.get('status_code', 'N/A') or 'N/A'
                    ip = s.get('ip', '') or ''
                    title = (s.get('title', '') or '')[:60]
                    click.echo(f"  \u2022 {s['subdomain']:40} [{status:>5}] {ip:20} {title}")
                if len(active) > 20:
                    click.echo(f"  ... and {len(active)-20} more active subdomains")
        
        # Save output
        if output:
            from .utils.export import save_results
            output_path = save_results(results, output, output_format)
            click.secho(f"\n📄 Results saved to: {output_path}", fg='green')
        else:
            # Auto-save to default location
            from .utils.export import save_results
            default_output = f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            output_path = save_results(results, default_output, output_format)
            click.secho(f"\n📄 Results auto-saved to: {output_path}", fg='green')
        
    except KeyboardInterrupt:
        click.secho("\n⚠️  Scan interrupted by user", fg='yellow')
    except Exception as e:
        logger.error(f"Scan failed: {e}", exc_info=True)
        click.secho(f"\n❌ Scan failed: {e}", fg='red')


# ===== SQL INJECTION COMMAND =====
@cli.command()
@click.argument('target')
@click.option('--parameter', '-p', help='Test specific parameter')
@click.option('--technique', '-t', multiple=True,
              type=click.Choice(['error', 'boolean', 'time', 'union', 'stacked', 'blind']),
              help='Injection techniques to use')
@click.option('--data', '-d', help='POST data (format: param1=value1&param2=value2)')
@click.option('--cookie', help='Session cookie')
@click.option('--level', type=click.IntRange(1, 5), default=1,
              help='Testing level (1-5, higher = more tests)')
@click.option('--risk', type=click.IntRange(1, 3), default=1,
              help='Risk level (1-3, higher = more dangerous payloads)')
@click.option('--safe/--no-safe', default=True, help='Safe mode (detection only)')
@click.option('--output', '-o', help='Output file')
@click.pass_context
def sqli(ctx, target, parameter, technique, data, cookie, level, risk, safe, output):
    """
    Test for SQL Injection vulnerabilities.
    
    Performs comprehensive SQL injection testing using various techniques.
    """
    
    logger = ctx.obj['logger']
    safety = ctx.obj['safety']
    
    # Validate
    if not safety.validate_target(target):
        click.secho(f"❌ Unauthorized target: {target}", fg='red')
        sys.exit(1)
    
    click.secho(f"\n🎯 SQL Injection Testing", fg='blue', bold=True)
    click.echo(f"Target: {target}")
    click.echo(f"Level: {level} | Risk: {risk}")
    click.echo(f"Safe Mode: {'✅' if safe else '⚠️'}")
    
    try:
        from .modules.sqli import SQLiTester
        
        tester = SQLiTester(
            target=target,
            parameter=parameter,
            data=data,
            cookie=cookie,
            level=level,
            risk=risk,
            safe_mode=safe
        )
        
        techniques_list = list(technique) if technique else None
        results = tester.test(techniques=techniques_list)
        
        _display_sqli_results(results)
        
        if output:
            from .utils.export import save_results
            save_results(results, output, 'json')
            
    except Exception as e:
        logger.error(f"SQLi test failed: {e}")
        click.secho(f"❌ Error: {e}", fg='red')


# ===== XSS COMMAND =====
@cli.command()
@click.argument('target')
@click.option('--parameter', '-p', help='Test specific parameter')
@click.option('--type', '-t', 'xss_type',
              type=click.Choice(['reflected', 'stored', 'dom', 'blind', 'all']),
              default='all', help='XSS type to test')
@click.option('--cookie', help='Session cookie')
@click.option('--safe/--no-safe', default=True, help='Safe mode')
@click.option('--output', '-o', help='Output file')
@click.pass_context
def xss(ctx, target, parameter, xss_type, cookie, safe, output):
    """
    Test for Cross-Site Scripting (XSS) vulnerabilities.
    """
    
    logger = ctx.obj['logger']
    safety = ctx.obj['safety']
    
    if not safety.validate_target(target):
        click.secho(f"❌ Unauthorized target: {target}", fg='red')
        sys.exit(1)
    
    click.secho(f"\n🎯 XSS Testing", fg='blue', bold=True)
    click.echo(f"Target: {target}")
    click.echo(f"Type: {xss_type}")
    
    try:
        from .modules.xss import XSSTester
        
        tester = XSSTester(
            target=target,
            parameter=parameter,
            cookie=cookie,
            safe_mode=safe
        )
        
        results = tester.test(xss_type=xss_type)
        _display_xss_results(results)
        
        if output:
            from .utils.export import save_results
            save_results(results, output, 'json')
            
    except Exception as e:
        logger.error(f"XSS test failed: {e}")
        click.secho(f"❌ Error: {e}", fg='red')


# ===== RECON COMMAND =====
@cli.command()
@click.argument('target')
@click.option('--passive', is_flag=True, help='Passive reconnaissance only')
@click.option('--depth', default=3, help='Crawl depth')
@click.option('--output', '-o', help='Output file')
@click.pass_context
def recon(ctx, target, passive, depth, output):
    """
    Perform reconnaissance on TARGET.
    """
    
    logger = ctx.obj['logger']
    safety = ctx.obj['safety']
    
    if not safety.validate_target(target):
        click.secho(f"❌ Unauthorized target: {target}", fg='red')
        sys.exit(1)
    
    click.secho(f"\n🔎 Reconnaissance", fg='blue', bold=True)
    click.echo(f"Target: {target}")
    click.echo(f"Passive only: {'Yes' if passive else 'No'}")
    
    try:
        from .modules.recon import Reconnaissance
        
        recon_module = Reconnaissance(target)
        results = recon_module.gather(passive_only=passive, depth=depth)
        
        _display_recon_results(results)
        
        if output:
            from .utils.export import save_results
            save_results(results, output, 'json')
            
    except Exception as e:
        logger.error(f"Recon failed: {e}")
        click.secho(f"❌ Error: {e}", fg='red')


# ===== REPORT COMMAND =====
@cli.command()
@click.argument('scan_file', type=click.Path(exists=True))
@click.option('--format', '-f', 'output_format',
              type=click.Choice(['html', 'pdf', 'markdown', 'json', 'sarif']),
              default='html', help='Report format')
@click.option('--output', '-o', help='Output file path')
@click.option('--template', help='Custom report template')
@click.pass_context
def report(ctx, scan_file, output_format, output, template):
    """
    Generate a report from scan results.
    """
    
    click.secho(f"\n📊 Report Generation", fg='blue', bold=True)
    click.echo(f"Input: {scan_file}")
    click.echo(f"Format: {output_format}")
    
    try:
        from .modules.reporting import ReportGenerator
        
        # Load scan data
        with open(scan_file) as f:
            scan_data = json.load(f)
        
        generator = ReportGenerator()
        report_path = generator.generate(
            data=scan_data,
            format=output_format,
            output_path=output,
            template=template
        )
        
        click.secho(f"✅ Report generated: {report_path}", fg='green')
        
    except Exception as e:
        click.secho(f"❌ Error: {e}", fg='red')


# ===== WEB DASHBOARD COMMAND =====
@cli.command()
@click.option('--host', default='127.0.0.1', help='Bind address')
@click.option('--port', default=8080, help='Port number')
@click.option('--debug', is_flag=True, help='Enable debug mode')
@click.pass_context
def web(ctx, host, port, debug):
    """
    Start the uEWF web dashboard.
    """
    
    click.secho(f"\n🌐 uEWF Web Dashboard", fg='blue', bold=True)
    click.echo(f"Starting server on http://{host}:{port}")
    click.echo("Press Ctrl+C to stop\n")
    
    try:
        from .web.dashboard import create_app
        
        app = create_app()
        app.run(host=host, port=port, debug=debug)
        
    except KeyboardInterrupt:
        click.echo("\nShutting down...")
    except Exception as e:
        click.secho(f"❌ Error: {e}", fg='red')


# ===== PROXY COMMAND =====
@cli.group()
def proxy():
    """Proxy management commands."""
    pass


@proxy.command('start')
@click.option('--port', default=8080, help='Proxy port')
@click.option('--host', default='127.0.0.1', help='Bind address')
@click.pass_context
def proxy_start(ctx, port, host):
    """Start intercepting proxy server."""
    
    click.secho(f"\n🔄 Starting proxy on {host}:{port}", fg='blue')
    
    try:
        from .modules.proxy import ProxyServer
        
        proxy_server = ProxyServer(host=host, port=port)
        proxy_server.start()
        
        # Keep running
        import time
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            proxy_server.stop()
            click.echo("\nProxy stopped")
        
    except KeyboardInterrupt:
        click.echo("\nProxy stopped")
    except Exception as e:
        click.secho(f"❌ Error: {e}", fg='red')


# ===== CONFIG COMMANDS =====
@cli.group()
def config():
    """Configuration management commands."""
    pass


@config.command('init')
def config_init():
    """Initialize uEWF configuration."""
    click.echo("See 'uewf init' command")
    ctx = click.get_current_context()
    ctx.invoke(init)


@config.command('authorize')
@click.argument('target')
@click.option('--scope', help='Testing scope description')
@click.option('--duration', default=30, help='Authorization duration in days')
def config_authorize(target, scope, duration):
    """Add authorized target for testing."""
    
    auth_manager = AuthorizationManager()
    auth_manager.add_authorization(target, scope, duration)
    
    click.secho(f"✅ Authorized: {target}", fg='green')
    click.echo(f"Scope: {scope}")
    click.echo(f"Expires: {duration} days")


@config.command('list')
def config_list():
    """List authorized targets."""
    
    auth_manager = AuthorizationManager()
    targets = auth_manager.get_authorizations()
    
    if not targets:
        click.echo("No authorized targets found.")
        return
    
    click.echo("\n📋 Authorized Targets:")
    click.echo("="*60)
    
    for target in targets:
        status = "✅ Active" if target['active'] else "❌ Expired"
        click.echo(f"\n{status}")
        click.echo(f"  URL: {target['url']}")
        click.echo(f"  Scope: {target['scope']}")
        click.echo(f"  Added: {target['added']}")
        click.echo(f"  Expires: {target['expires']}")


@config.command('show')
def config_show():
    """Show current configuration."""
    
    config_data = Config.get_all()
    
    click.echo("\n⚙️  Current Configuration:")
    click.echo("="*60)
    
    for key, value in config_data.items():
        # Mask sensitive values
        if any(s in key.lower() for s in ['password', 'token', 'secret', 'key']):
            value = '********'
        click.echo(f"  {key}: {value}")


# ===== DATABASE COMMANDS =====
@cli.group()
def db():
    """Database management commands."""
    pass


@db.command('init')
def db_init():
    """Initialize database."""
    
    from .core.database import Database
    
    click.echo("Initializing database...")
    Database.initialize()
    click.secho("✅ Database initialized", fg='green')


@db.command('status')
def db_status():
    """Show database statistics."""
    
    from .core.database import Database
    
    stats = Database.get_stats()
    
    click.echo("\n📊 Database Statistics:")
    click.echo("="*30)
    
    for key, value in stats.items():
        click.echo(f"  {key}: {value}")


@db.command('export')
@click.argument('output', type=click.Path())
@click.option('--format', '-f', default='json', help='Export format')
def db_export(output, format):
    """Export database contents."""
    
    from .core.database import Database
    from .utils.export import save_results
    
    data = Database.export_all()
    path = save_results(data, output, format)
    
    click.secho(f"✅ Database exported to: {path}", fg='green')


# ===== MODULES COMMAND =====
@cli.group()
def modules():
    """List and manage uEWF modules."""
    pass


@modules.command('list')
def modules_list():
    """List available modules."""
    
    from .core.modules import ModuleManager
    
    available_modules = ModuleManager.get_modules()
    
    click.echo("\n📦 Available Modules:")
    click.echo("="*50)
    
    for module in available_modules:
        status = "✅" if module['enabled'] else "❌"
        click.echo(f"  {status} {module['name']:20} - {module['description']}")


@modules.command('info')
@click.argument('module_name')
def modules_info(module_name):
    """Show module information."""
    
    from .core.modules import ModuleManager
    
    info = ModuleManager.get_module_info(module_name)
    
    if not info:
        click.secho(f"❌ Module not found: {module_name}", fg='red')
        return
    
    click.echo(f"\n📋 Module: {info['name']}")
    click.echo("="*40)
    click.echo(f"Description: {info['description']}")
    click.echo(f"Version: {info['version']}")
    click.echo(f"Author: {info['author']}")
    click.echo(f"Enabled: {info['enabled']}")
    click.echo(f"\nTechniques:")
    for tech in info['techniques']:
        click.echo(f"  • {tech}")


# ===== HELPER FUNCTIONS =====

def _display_scan_results(results):
    """Display formatted scan results."""
    
    if not results or not results.get('vulnerabilities'):
        click.secho("\n✅ No vulnerabilities found!", fg='green')
        return
    
    vulns = results['vulnerabilities']
    
    click.echo("\n" + "="*70)
    click.secho(f"📊 SCAN RESULTS - {len(vulns)} vulnerabilities found", fg='blue', bold=True)
    click.echo("="*70)
    
    # Group by severity
    severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
    sorted_vulns = sorted(vulns, key=lambda x: severity_order.get(x.get('severity', 'info'), 5))
    
    severity_colors = {
        'critical': 'red',
        'high': 'red',
        'medium': 'yellow',
        'low': 'green',
        'info': 'blue'
    }
    
    for i, vuln in enumerate(sorted_vulns, 1):
        severity = vuln.get('severity', 'info')
        color = severity_colors.get(severity, 'white')
        
        click.echo(f"\n{'─'*70}")
        click.echo(f"[{i}] ", nl=False)
        click.secho(f"{vuln.get('type', 'Unknown')}", bold=True)
        click.echo(f"    Severity: ", nl=False)
        click.secho(f"{severity.upper()}", fg=color, bold=True)
        
        # Show complete URL with parameter
        base_url = vuln.get('url', '')
        param = (vuln.get('parameter') or '')
        full_url = vuln.get('full_url') or vuln.get('full_url_with_params', '')
        
        if full_url and '?' in full_url:
            display_url = full_url
        elif param.strip() and param.lower() != 'n/a':
            display_url = f"{base_url}?{param}=1"
        else:
            display_url = base_url if base_url else 'N/A'
        
        click.echo(f"    URL: {display_url}")
        
        if param.strip() and param.lower() != 'n/a':
            click.echo(f"    Parameter: {param}")
        
        click.echo(f"    Description: {vuln.get('description', 'N/A')}")
        
        if vuln.get('evidence'):
            click.echo(f"    Evidence: {vuln['evidence']}")
    
    click.echo(f"\n{'='*70}")
    
    # Summary
    severity_counts = {}
    for vuln in vulns:
        sev = vuln.get('severity', 'info')
        severity_counts[sev] = severity_counts.get(sev, 0) + 1
    
    click.echo("\n📈 Summary:")
    for sev, count in severity_counts.items():
        color = severity_colors.get(sev, 'white')
        click.echo(f"    ", nl=False)
        click.secho(f"{sev.upper()}: {count}", fg=color)


def _display_sqli_results(results):
    """Display SQL injection results."""
    _display_scan_results({'vulnerabilities': results})


def _display_xss_results(results):
    """Display XSS results."""
    _display_scan_results({'vulnerabilities': results})


def _display_recon_results(results):
    """Display reconnaissance results."""
    
    click.echo("\n" + "="*60)
    click.secho("🔎 RECONNAISSANCE RESULTS", fg='blue', bold=True)
    click.echo("="*60)
    
    if results.get('urls'):
        click.echo(f"\n📎 Discovered URLs: {len(results['urls'])}")
        for url in results['urls'][:20]:
            click.echo(f"   • {url}")
        if len(results['urls']) > 20:
            click.echo(f"   ... and {len(results['urls']) - 20} more")
    
    if results.get('parameters'):
        click.echo(f"\n🔧 Parameters Found: {len(results['parameters'])}")
        for param in results['parameters'][:10]:
            click.echo(f"   • {param}")
    
    if results.get('technologies'):
        click.echo(f"\n🛠️  Technologies Detected:")
        for tech, version in results['technologies'].items():
            click.echo(f"   • {tech}: {version}")
    
    if results.get('endpoints'):
        click.echo(f"\n🔗 Interesting Endpoints:")
        for endpoint in results['endpoints']:
            click.echo(f"   • {endpoint}")


if __name__ == '__main__':
    cli()

